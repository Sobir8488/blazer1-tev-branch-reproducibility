from __future__ import annotations

from pathlib import Path
import math
import itertools
import numpy as np
import pandas as pd
from scipy.stats import rankdata, spearmanr, pearsonr, norm, beta, hypergeom, binomtest, fisher_exact, mannwhitneyu, ks_2samp

ROOT = Path(__file__).resolve().parents[1]
PROCESSED = ROOT / "data" / "processed"
TABLES = ROOT / "tables"
FIGURES = ROOT / "figures"
DOCS = ROOT / "docs"
METADATA = ROOT / "metadata"
EXTERNAL = ROOT / "data" / "external"
for p in (PROCESSED, TABLES, FIGURES, DOCS, METADATA, EXTERNAL):
    p.mkdir(parents=True, exist_ok=True)

ACTIVE_COMPONENTS = {
    "xray_brightness": ("S_X", +1.0, 1.00, "X-ray brightness"),
    "gamma_hardness": ("S_gamma_hard", +1.0, 1.00, "Gamma hardness"),
    "gamma_variability": ("S_gamma_var", +1.0, 0.35, "Gamma variability"),
    "wise_hsp_locus": ("S_IR", +1.0, 0.75, "WISE/HSP locus"),
    "synchrotron_peak_proxy": ("S_nu_peak", +1.0, 1.00, "Synchrotron peak proxy"),
    "compton_dominance_penalty": ("S_CD_penalty", -1.0, 0.60, "Compton-dominance penalty"),
    "ebl_penalty": ("S_EBL_proxy", -1.0, 0.80, "Redshift/EBL penalty"),
}
ALL_COMPONENTS_WITH_INACTIVE_RADIO = {
    **dict(list(ACTIVE_COMPONENTS.items())[:4]),
    "radio_compactness": ("S_R", +1.0, 0.75, "Radio compactness (inactive)"),
    **dict(list(ACTIVE_COMPONENTS.items())[4:]),
}
TIER_ORDER = {"Low-priority": 0, "Bronze": 1, "Silver": 2, "Gold": 3}
STAGE_ORDER = ["FSRQ/QSO-like", "BCU/uncertain", "BL Lac-like", "HSP-like"]


def numeric(s: pd.Series) -> pd.Series:
    return pd.to_numeric(s, errors="coerce").replace([np.inf, -np.inf], np.nan)


def as_bool(s: pd.Series) -> pd.Series:
    if s.dtype == bool:
        return s.fillna(False)
    return s.astype(str).str.strip().str.lower().isin({"1", "true", "t", "yes", "y"})


def source_name(df: pd.DataFrame) -> pd.Series:
    cols = ["SRC_NAME", "IAUNAME", "COMMON_SRC_NAME", "FGL_SRC_NAME", "HSP_SRC_NAME"]
    out = pd.Series(pd.NA, index=df.index, dtype="object")
    for c in cols:
        if c in df:
            x = df[c].astype("string").str.strip()
            good = x.notna() & x.ne("") & x.str.lower().ne("nan")
            out.loc[out.isna() & good] = x.loc[out.isna() & good]
    out = out.fillna(pd.Series([f"row_{i}" for i in df.index], index=df.index))
    return out.astype(str)


def load_active_catalogue(require_interpretability: bool = False) -> tuple[pd.DataFrame, Path]:
    candidates = [
        PROCESSED / "tev_evolution_score_catalog_v0_4_4_active_interpretability.csv",
        PROCESSED / "tev_evolution_score_catalog_v0_4_4_active_primary.csv",
        PROCESSED / "tev_evolution_score_catalog_v0_4_3_score_architecture_augmented.csv",
    ]
    for path in candidates:
        if path.exists():
            df = pd.read_csv(path, low_memory=False)
            if "is_known_tev" not in df:
                if "tevcat_matched" in df:
                    df["is_known_tev"] = as_bool(df["tevcat_matched"])
                else:
                    raise KeyError("No TeV validation label found.")
            else:
                df["is_known_tev"] = as_bool(df["is_known_tev"])
            if "row_id_v044" not in df:
                df["row_id_v044"] = np.arange(len(df), dtype=int)
            if "source_name_v044" not in df:
                df["source_name_v044"] = source_name(df)
            if require_interpretability and "PC1_active_v0_4_4" not in df:
                continue
            return df, path
    raise FileNotFoundError(
        "Missing v0.4.3 augmented catalogue. Run v0.4.3 before v0.4.4."
    )


def assign_tier(score: pd.Series) -> pd.Series:
    s = numeric(score)
    valid = s.dropna()
    out = pd.Series("Low-priority", index=s.index, dtype="object")
    if valid.empty:
        return out
    q70, q85, q95 = np.nanpercentile(valid, [70, 85, 95])
    out.loc[s >= q70] = "Bronze"
    out.loc[s >= q85] = "Silver"
    out.loc[s >= q95] = "Gold"
    out.loc[s.isna()] = "unavailable"
    return out


def percentile_rank(score: pd.Series) -> pd.Series:
    return numeric(score).rank(method="average", pct=True) * 100.0


def auc_rank(y: np.ndarray, score: np.ndarray) -> float:
    y = np.asarray(y, dtype=bool)
    score = np.asarray(score, dtype=float)
    m = np.isfinite(score)
    y, score = y[m], score[m]
    n1, n0 = int(y.sum()), int((~y).sum())
    if n1 == 0 or n0 == 0:
        return np.nan
    r = rankdata(score, method="average")
    u = r[y].sum() - n1 * (n1 + 1) / 2.0
    return float(u / (n1 * n0))


def wilson_interval(k: int, n: int, alpha: float = 0.05) -> tuple[float, float]:
    if n <= 0:
        return np.nan, np.nan
    z = norm.ppf(1 - alpha / 2)
    p = k / n
    den = 1 + z*z/n
    centre = (p + z*z/(2*n)) / den
    half = z * math.sqrt(p*(1-p)/n + z*z/(4*n*n)) / den
    return max(0.0, centre-half), min(1.0, centre+half)


def jeffreys_interval(k: int, n: int, alpha: float = 0.05) -> tuple[float, float]:
    if n <= 0:
        return np.nan, np.nan
    return float(beta.ppf(alpha/2, k+0.5, n-k+0.5)), float(beta.ppf(1-alpha/2, k+0.5, n-k+0.5))


def hypergeom_p(N: int, K: int, n: int, k: int) -> float:
    return float(hypergeom.sf(k-1, N, K, n)) if N and K and n >= 0 else np.nan


def score_from_components(df: pd.DataFrame, peak_override: pd.Series | None = None, exclude: set[str] | None = None, weight_override: dict[str, float] | None = None) -> pd.Series:
    exclude = exclude or set()
    total = pd.Series(0.0, index=df.index, dtype=float)
    den = pd.Series(0.0, index=df.index, dtype=float)
    for key, (col, sign, weight, _) in ACTIVE_COMPONENTS.items():
        if key in exclude:
            continue
        w = float(weight_override.get(key, weight) if weight_override else weight)
        if key == "synchrotron_peak_proxy" and peak_override is not None:
            x = numeric(peak_override)
        elif col in df:
            x = numeric(df[col])
        else:
            continue
        good = x.notna()
        total.loc[good] += sign * w * x.loc[good]
        den.loc[good] += abs(w)
    return total / den.replace(0, np.nan)


def robust_zscore(s: pd.Series) -> pd.Series:
    x = numeric(s)
    med = x.median(skipna=True)
    mad = (x-med).abs().median(skipna=True)
    if pd.isna(mad) or mad == 0:
        return (x-med) * 0.0
    return (x-med)/(1.4826*mad)


def safe_spearman(x: pd.Series, y: pd.Series) -> tuple[float, float, int]:
    d = pd.DataFrame({"x": numeric(x), "y": numeric(y)}).dropna()
    if len(d) < 3:
        return np.nan, np.nan, len(d)
    r, p = spearmanr(d["x"], d["y"])
    return float(r), float(p), len(d)


def partial_spearman(x: pd.Series, y: pd.Series, z: pd.Series) -> tuple[float, float, int]:
    d = pd.DataFrame({"x": numeric(x), "y": numeric(y), "z": numeric(z)}).dropna()
    if len(d) < 10:
        return np.nan, np.nan, len(d)
    for c in d:
        d[c] = rankdata(d[c].to_numpy(), method="average")
    A = np.column_stack([np.ones(len(d)), d["z"].to_numpy()])
    bx, *_ = np.linalg.lstsq(A, d["x"].to_numpy(), rcond=None)
    by, *_ = np.linalg.lstsq(A, d["y"].to_numpy(), rcond=None)
    rx = d["x"].to_numpy() - A @ bx
    ry = d["y"].to_numpy() - A @ by
    r, p = pearsonr(rx, ry)
    return float(r), float(p), len(d)


def paired_stratified_bootstrap(y: np.ndarray, scores: dict[str, np.ndarray], comparisons: list[tuple[str, str]], n_boot: int, seed: int) -> tuple[pd.DataFrame, pd.DataFrame]:
    y = np.asarray(y, dtype=bool)
    arrs = {k: np.asarray(v, dtype=float) for k, v in scores.items()}
    common = np.ones(len(y), dtype=bool)
    for v in arrs.values():
        common &= np.isfinite(v)
    y = y[common]
    arrs = {k: v[common] for k, v in arrs.items()}
    pos, neg = np.flatnonzero(y), np.flatnonzero(~y)
    rng = np.random.default_rng(seed)
    rows = []
    for b in range(n_boot):
        idx = np.concatenate([rng.choice(pos, len(pos), replace=True), rng.choice(neg, len(neg), replace=True)])
        yy = y[idx]
        aucs = {k: auc_rank(yy, v[idx]) for k, v in arrs.items()}
        row = {"draw": b, **{f"auc_{k}": val for k, val in aucs.items()}}
        for a, c in comparisons:
            row[f"delta_{a}_minus_{c}"] = aucs[a] - aucs[c]
        rows.append(row)
    draws = pd.DataFrame(rows)
    summary = []
    for k, v in arrs.items():
        vals = draws[f"auc_{k}"].to_numpy()
        summary.append({"quantity": f"AUROC {k}", "estimate": auc_rank(y, v), "bootstrap_median": float(np.median(vals)), "ci95_low": float(np.percentile(vals,2.5)), "ci95_high": float(np.percentile(vals,97.5)), "p_two_sided": np.nan, "N": len(y), "N_pos": int(y.sum()), "n_boot": n_boot})
    for a,c in comparisons:
        vals = draws[f"delta_{a}_minus_{c}"].to_numpy()
        plo = (np.sum(vals <= 0)+1)/(len(vals)+1)
        phi = (np.sum(vals >= 0)+1)/(len(vals)+1)
        summary.append({"quantity": f"Delta AUROC {a} - {c}", "estimate": auc_rank(y,arrs[a])-auc_rank(y,arrs[c]), "bootstrap_median": float(np.median(vals)), "ci95_low": float(np.percentile(vals,2.5)), "ci95_high": float(np.percentile(vals,97.5)), "p_two_sided": float(min(1,2*min(plo,phi))), "N": len(y), "N_pos": int(y.sum()), "n_boot": n_boot})
    return draws, pd.DataFrame(summary)


def _midrank(x: np.ndarray) -> np.ndarray:
    order = np.argsort(x)
    xs = x[order]
    out = np.empty(len(x), dtype=float)
    i=0
    while i < len(x):
        j=i
        while j < len(x) and xs[j] == xs[i]: j += 1
        out[i:j] = 0.5*(i+j-1)+1
        i=j
    ans=np.empty(len(x),dtype=float); ans[order]=out
    return ans


def delong_pair(y: np.ndarray, a: np.ndarray, b: np.ndarray) -> dict:
    y=np.asarray(y,dtype=bool); a=np.asarray(a,float); b=np.asarray(b,float)
    m=np.isfinite(a)&np.isfinite(b); y,a,b=y[m],a[m],b[m]
    order=np.argsort(~y); pred=np.vstack([a[order],b[order]]); npos=int(y.sum()); nneg=len(y)-npos
    if npos<2 or nneg<2: return {"auc_a":np.nan,"auc_b":np.nan,"delta_auc":np.nan,"p_two_sided":np.nan,"N":len(y),"N_pos":npos}
    pos=pred[:,:npos]; neg=pred[:,npos:]; tx=np.vstack([_midrank(r) for r in pos]); ty=np.vstack([_midrank(r) for r in neg]); tz=np.vstack([_midrank(r) for r in pred])
    aucs=tz[:,:npos].sum(axis=1)/(npos*nneg)-(npos+1)/(2*nneg)
    v01=(tz[:,:npos]-tx)/nneg; v10=1-(tz[:,npos:]-ty)/npos
    cov=np.atleast_2d(np.cov(v01,bias=False))/npos + np.atleast_2d(np.cov(v10,bias=False))/nneg
    c=np.array([1.,-1.]); var=float(c@cov@c.T); se=math.sqrt(max(var,0)); delta=float(aucs[0]-aucs[1]); z=delta/se if se>0 else np.nan; p=2*norm.sf(abs(z)) if np.isfinite(z) else np.nan
    return {"auc_a":float(aucs[0]),"auc_b":float(aucs[1]),"delta_auc":delta,"se_delta":se,"z":z,"p_two_sided":float(p),"N":len(y),"N_pos":npos}


def angular_separation_arcsec(ra1: float, dec1: float, ra2: np.ndarray, dec2: np.ndarray) -> np.ndarray:
    r1,d1=math.radians(float(ra1)),math.radians(float(dec1)); r2=np.deg2rad(np.asarray(ra2,float)); d2=np.deg2rad(np.asarray(dec2,float))
    c=np.sin(d1)*np.sin(d2)+np.cos(d1)*np.cos(d2)*np.cos(r1-r2)
    return np.rad2deg(np.arccos(np.clip(c,-1,1)))*3600


def coordinate_crossmatch(events: pd.DataFrame, cat: pd.DataFrame, radius_arcsec: float=180.) -> pd.DataFrame:
    ra=numeric(cat.get("ra_deg",cat.get("RAJ2000"))).to_numpy(); dec=numeric(cat.get("dec_deg",cat.get("DECJ2000"))).to_numpy(); good=np.isfinite(ra)&np.isfinite(dec); ids=np.flatnonzero(good)
    rows=[]
    for _,e in events.iterrows():
        rec=e.to_dict(); era=pd.to_numeric(pd.Series([e.get("ra_deg")]),errors="coerce").iloc[0]; edec=pd.to_numeric(pd.Series([e.get("dec_deg")]),errors="coerce").iloc[0]
        rec.update({"catalogue_matched":False,"catalogue_row_id":np.nan,"match_separation_arcsec":np.nan})
        if np.isfinite(era) and np.isfinite(edec) and len(ids):
            sep=angular_separation_arcsec(era,edec,ra[ids],dec[ids]); jloc=int(np.nanargmin(sep)); j=int(ids[jloc]); rec["match_separation_arcsec"]=float(sep[jloc])
            if sep[jloc] <= radius_arcsec: rec["catalogue_matched"]=True; rec["catalogue_row_id"]=j
        rows.append(rec)
    return pd.DataFrame(rows)


def exact_permutation_auc(y: np.ndarray, score: np.ndarray, max_exact: int=200000, seed: int=8488) -> dict:
    y=np.asarray(y,bool); score=np.asarray(score,float); m=np.isfinite(score); y,score=y[m],score[m]; n=len(y); k=int(y.sum()); obs=auc_rank(y,score)
    if n<3 or k==0 or k==n: return {"auc":obs,"p_two_sided":np.nan,"n_permutations":0,"exact":False}
    total=math.comb(n,k); vals=[]
    if total<=max_exact:
        for comb in itertools.combinations(range(n),k):
            yy=np.zeros(n,bool); yy[list(comb)]=True; vals.append(auc_rank(yy,score))
        exact=True
    else:
        rng=np.random.default_rng(seed)
        for _ in range(max_exact):
            yy=np.zeros(n,bool); yy[rng.choice(n,k,replace=False)]=True; vals.append(auc_rank(yy,score))
        exact=False
    vals=np.asarray(vals); p=(np.sum(np.abs(vals-.5)>=abs(obs-.5))+1)/(len(vals)+1)
    return {"auc":obs,"p_two_sided":float(p),"n_permutations":len(vals),"exact":exact}


def add_primary_columns(df: pd.DataFrame) -> pd.DataFrame:
    out=df.copy()
    if "S_arch_active_available_v0_4_3" not in out:
        raise KeyError("Missing active score from v0.4.3.")
    out["S_TeV_branch_active_v0_4_4"] = numeric(out["S_arch_active_available_v0_4_3"])
    out["percentile_active_v0_4_4"] = percentile_rank(out["S_TeV_branch_active_v0_4_4"])
    out["tier_active_v0_4_4"] = assign_tier(out["S_TeV_branch_active_v0_4_4"])
    out["tier_rank_active_v0_4_4"] = out["tier_active_v0_4_4"].map(TIER_ORDER)
    out["is_gold_active_v0_4_4"] = out["tier_active_v0_4_4"].eq("Gold")
    out["is_gold_silver_active_v0_4_4"] = out["tier_active_v0_4_4"].isin(["Gold","Silver"])
    return out
