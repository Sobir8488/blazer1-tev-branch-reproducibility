from __future__ import annotations

import os
import sys
from pathlib import Path
sys.path.append(str(Path(__file__).resolve().parent))

import numpy as np
import pandas as pd

from _v043_helpers import (
    PROCESSED, TABLES, METADATA, COMPONENTS, load_frozen_catalogue, numeric,
    compute_architecture_scores, availability_pattern, component_count,
    available_weight, fixed_fraction_tiers, percentile_rank, auroc,
    safe_spearman, top_n_non_tev_names, jaccard, delong_pair,
    paired_bootstrap_deltas, source_name,
)


def main() -> None:
    df, source = load_frozen_catalogue()
    for meta in COMPONENTS:
        df[meta["column"]] = numeric(df[meta["column"]])

    n_boot = int(os.environ.get("BLAZER_V043_N_BOOT", "5000"))
    seed = int(os.environ.get("BLAZER_V043_SEED", "8488"))

    scores, activity = compute_architecture_scores(df)
    known = df["is_known_tev"].astype(bool)
    patterns = availability_pattern(df)
    ncomp = component_count(df)
    aw_all = available_weight(df, active_only=False, activity=activity)
    aw_active = available_weight(df, active_only=True, activity=activity)

    activity.to_csv(TABLES / "table_score_component_activity_v0_4_3.csv", index=False)

    primary_variants = [
        "published_available", "radio_free_available", "active_available",
        "fixed_all_weight", "fixed_active_weight",
    ]
    baseline_tier = fixed_fraction_tiers(scores["published_available"])
    baseline_gold = set(df.index[baseline_tier.eq("Gold")])
    baseline_top30 = top_n_non_tev_names(df, scores["published_available"], 30)

    rows = []
    for name in primary_variants:
        s = numeric(scores[name])
        tier = fixed_fraction_tiers(s)
        pct = percentile_rank(s)
        gold = tier.eq("Gold")
        gs = tier.isin(["Gold", "Silver"])
        valid = s.notna()
        y = known[valid]
        rho_base, p_base, n_base = safe_spearman(scores["published_available"], s)
        rho_count, p_count, n_count = safe_spearman(s, ncomp)
        rho_weight, p_weight, n_weight = safe_spearman(s, aw_all)
        gold_set = set(df.index[gold])
        top30 = top_n_non_tev_names(df, s, 30)
        rows.append({
            "score_variant": name,
            "analysis_N": int(valid.sum()),
            "known_TeV_N": int(y.sum()),
            "AUROC": auroc(y, s[valid]),
            "Gold_N": int(gold.sum()),
            "Gold_known_TeV_N": int((gold & known).sum()),
            "Gold_recovery": float((gold & known).sum()/known.sum()),
            "Gold_Silver_N": int(gs.sum()),
            "Gold_Silver_known_TeV_N": int((gs & known).sum()),
            "Gold_Silver_recovery": float((gs & known).sum()/known.sum()),
            "spearman_vs_published": rho_base,
            "spearman_vs_published_p": p_base,
            "spearman_vs_published_N": n_base,
            "Gold_Jaccard_vs_published": jaccard(gold_set, baseline_gold),
            "Gold_overlap_N": len(gold_set & baseline_gold),
            "top30_nonTeV_overlap_N": len(top30 & baseline_top30),
            "spearman_score_vs_component_count": rho_count,
            "spearman_score_vs_component_count_p": p_count,
            "spearman_score_vs_available_weight": rho_weight,
            "spearman_score_vs_available_weight_p": p_weight,
        })
        df[f"S_arch_{name}_v0_4_3"] = s
        df[f"percentile_arch_{name}_v0_4_3"] = pct
        df[f"tier_arch_{name}_v0_4_3"] = tier

    summary = pd.DataFrame(rows)
    summary.to_csv(TABLES / "table_score_architecture_variants_v0_4_3.csv", index=False)

    comparisons = [
        ("active_available", "published_available"),
        ("fixed_active_weight", "published_available"),
        ("active_available", "fixed_active_weight"),
    ]
    selected_scores = {k: scores[k] for k in {x for pair in comparisons for x in pair}}
    draws, boot = paired_bootstrap_deltas(known, selected_scores, comparisons, n_boot=n_boot, seed=seed)
    draws.to_csv(TABLES / "table_score_architecture_bootstrap_draws_v0_4_3.csv", index=False)

    pair_rows = []
    for a, b in comparisons:
        d = delong_pair(known, scores[a], scores[b])
        pair_rows.append({"model_a": a, "model_b": b, **d})
    pairwise = pd.DataFrame(pair_rows).merge(boot, on=["model_a", "model_b"], how="left", suffixes=("_delong", "_bootstrap"))
    pairwise.to_csv(TABLES / "table_score_architecture_pairwise_v0_4_3.csv", index=False)

    # Radio denominator effect: S_R is numerically zero where available, so only denominator changes.
    radio_available = df["S_R"].notna()
    delta = numeric(scores["active_available"] - scores["published_available"])
    radio_rows = []
    for label, mask in [
        ("radio_available", radio_available),
        ("radio_missing", ~radio_available),
        ("known_TeV_radio_available", radio_available & known),
        ("nonTeV_radio_available", radio_available & ~known),
    ]:
        x = delta[mask].dropna()
        radio_rows.append({
            "group": label,
            "N": len(x),
            "median_active_minus_published": float(x.median()) if len(x) else np.nan,
            "mean_active_minus_published": float(x.mean()) if len(x) else np.nan,
            "p16": float(x.quantile(0.16)) if len(x) else np.nan,
            "p84": float(x.quantile(0.84)) if len(x) else np.nan,
            "median_abs_delta": float(x.abs().median()) if len(x) else np.nan,
            "max_abs_delta": float(x.abs().max()) if len(x) else np.nan,
        })
    radio_effect = pd.DataFrame(radio_rows)
    radio_effect.to_csv(TABLES / "table_radio_denominator_effect_v0_4_3.csv", index=False)

    transition_rows = []
    for variant in ["active_available", "fixed_active_weight"]:
        new_tier = df[f"tier_arch_{variant}_v0_4_3"]
        ct = pd.crosstab(baseline_tier, new_tier)
        for old in ["Low", "Bronze", "Silver", "Gold"]:
            for new in ["Low", "Bronze", "Silver", "Gold"]:
                transition_rows.append({
                    "comparison_variant": variant,
                    "published_tier": old,
                    "variant_tier": new,
                    "N": int(ct.loc[old, new]) if old in ct.index and new in ct.columns else 0,
                })
    transitions = pd.DataFrame(transition_rows)
    transitions.to_csv(TABLES / "table_score_architecture_tier_transitions_v0_4_3.csv", index=False)

    # Architecture decision is based on numerical definition, not TeVCat performance.
    inactive = activity.loc[~activity["active_for_denominator"], "component_key"].tolist()
    active_equals_radiofree = bool(np.nanmax(np.abs(numeric(scores["active_available"] - scores["radio_free_available"]))) < 1e-12)
    decision = pd.DataFrame([
        {
            "candidate_architecture": "published_available",
            "decision": "retain_as_frozen_legacy_reference",
            "reason": "exactly reconstructs the released score, but a zero-variance radio term can change the denominator when radio metadata are present",
            "label_performance_used_for_decision": False,
        },
        {
            "candidate_architecture": "active_available",
            "decision": "recommended_corrected_primary_branch_coordinate",
            "reason": "excludes globally zero-variance components from numerator and denominator while preserving available-component normalization",
            "label_performance_used_for_decision": False,
        },
        {
            "candidate_architecture": "fixed_active_weight",
            "decision": "retain_as_coverage_penalizing_sensitivity_only",
            "reason": "treats missing standardized components as neutral zero but couples rank strongly to characterization completeness",
            "label_performance_used_for_decision": False,
        },
    ])
    decision["inactive_components"] = ",".join(inactive)
    decision["active_equals_radio_free"] = active_equals_radiofree
    decision.to_csv(TABLES / "table_primary_score_decision_v0_4_3.csv", index=False)

    keep = pd.DataFrame({
        "row_id": np.arange(len(df), dtype=int),
        "source_name": source_name(df),
        "is_known_tev": known,
        "availability_pattern": patterns,
        "component_count": ncomp,
        "available_weight_all": aw_all,
        "available_weight_active": aw_active,
        "radio_component_available": radio_available,
    })
    for name in primary_variants:
        keep[f"score_{name}"] = df[f"S_arch_{name}_v0_4_3"]
        keep[f"percentile_{name}"] = df[f"percentile_arch_{name}_v0_4_3"]
        keep[f"tier_{name}"] = df[f"tier_arch_{name}_v0_4_3"]
    keep.to_csv(TABLES / "table_score_architecture_variant_assignments_v0_4_3.csv", index=False)

    out_path = PROCESSED / "tev_evolution_score_catalog_v0_4_3_score_architecture_augmented.csv"
    df["availability_pattern_v0_4_3"] = patterns
    df["component_count_v0_4_3"] = ncomp
    df["available_weight_active_v0_4_3"] = aw_active
    df.to_csv(out_path, index=False)

    meta = {
        "frozen_input": str(source),
        "n_boot": n_boot,
        "seed": seed,
        "inactive_components": inactive,
        "recommended_primary_score_column": "S_arch_active_available_v0_4_3",
        "legacy_score_column": "S_TeV_evo",
        "decision_basis": "numerical score architecture before TeVCat comparison",
    }
    (METADATA / "score_architecture_decision_v0_4_3.json").write_text(pd.Series(meta).to_json(indent=2), encoding="utf-8")

    print("v0.4.3 score-architecture variants complete.")
    print(f"Frozen catalogue: {source}")
    print(f"Inactive components: {inactive}")
    print(summary.to_string(index=False))
    print("\nPrimary architecture decision:")
    print(decision.to_string(index=False))
    print(f"\nAugmented catalogue: {out_path}")


if __name__ == "__main__":
    main()
