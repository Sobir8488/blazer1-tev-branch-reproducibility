from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

ROOT = Path('.')
SCORE_PATH = ROOT / 'data' / 'processed' / 'tev_evolution_score_catalog.csv'
FIGDIR = ROOT / 'figures'
FIGDIR.mkdir(exist_ok=True, parents=True)


def main():
    score = pd.read_csv(SCORE_PATH, low_memory=False)
    if 'tevcat_matched' in score.columns:
        score['is_known_tev'] = score['tevcat_matched'].fillna(False).astype(bool)
    else:
        score['is_known_tev'] = score.get('tevcat_name', pd.Series([np.nan]*len(score))).notna()
    score = score.dropna(subset=['S_TeV_evo']).copy()

    known = score.loc[score['is_known_tev'], 'S_TeV_evo'].astype(float)
    other = score.loc[~score['is_known_tev'], 'S_TeV_evo'].astype(float)

    plt.figure(figsize=(6.2, 4.2))
    bins = np.linspace(score['S_TeV_evo'].quantile(0.005), score['S_TeV_evo'].quantile(0.995), 40)
    plt.hist(other, bins=bins, alpha=0.55, density=True, label='Other BlazEr1 sources')
    plt.hist(known, bins=bins, alpha=0.75, density=True, label='Known TeV matches')
    plt.xlabel(r'$S_{\rm TeV,evo}$')
    plt.ylabel('Density')
    plt.legend(frameon=False)
    plt.tight_layout()
    plt.savefig(FIGDIR / 'fig_score_distribution_known_tev.png', dpi=300)
    plt.savefig(FIGDIR / 'fig_score_distribution_known_tev.pdf')
    plt.close()

    ranked = score.sort_values('S_TeV_evo', ascending=False).reset_index(drop=True)
    ranked['rank_fraction'] = (np.arange(len(ranked)) + 1) / len(ranked)
    total_known = ranked['is_known_tev'].sum()
    ranked['known_recovery_fraction'] = ranked['is_known_tev'].cumsum() / total_known if total_known else np.nan

    plt.figure(figsize=(6.2, 4.2))
    plt.plot(ranked['rank_fraction'], ranked['known_recovery_fraction'], label='Known TeV recovery')
    plt.plot([0, 1], [0, 1], linestyle='--', label='Random expectation')
    plt.xlabel('Fraction of ranked catalogue inspected')
    plt.ylabel('Fraction of known TeV matches recovered')
    plt.legend(frameon=False)
    plt.tight_layout()
    plt.savefig(FIGDIR / 'fig_known_tev_recovery_curve.png', dpi=300)
    plt.savefig(FIGDIR / 'fig_known_tev_recovery_curve.pdf')
    plt.close()

    print('Saved figures:')
    print('figures/fig_score_distribution_known_tev.png/.pdf')
    print('figures/fig_known_tev_recovery_curve.png/.pdf')


if __name__ == '__main__':
    main()
