from __future__ import annotations

import sys
from pathlib import Path
sys.path.append(str(Path(__file__).resolve().parent))

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from _v030_helpers import TABLES, FIGURES, DOCS


def fig_harmonized_auc() -> None:
    p = TABLES / "table_harmonized_auc_summary_v0_3_1.csv"
    if not p.exists():
        return
    df = pd.read_csv(p)
    d = df[df["quantity"].str.startswith("AUROC ")].copy()
    labels = d["quantity"].str.replace("AUROC ", "", regex=False).tolist()
    x = np.arange(len(d))
    y = d["estimate"].to_numpy()
    lo = y - d["ci95_low"].to_numpy()
    hi = d["ci95_high"].to_numpy() - y
    fig, ax = plt.subplots(figsize=(6.4, 4.1))
    ax.errorbar(x, y, yerr=np.vstack([lo, hi]), fmt="o", capsize=4)
    ax.set_xticks(x, labels, rotation=20, ha="right")
    ax.set_ylim(0.80, 1.01)
    ax.set_ylabel("AUROC with 95% paired-bootstrap interval")
    ax.set_title("Harmonized known-TeV discrimination")
    ax.grid(axis="y", alpha=0.3)
    fig.tight_layout()
    fig.savefig(FIGURES / "Fig_harmonized_auc_comparison_v0_3_1.pdf")
    fig.savefig(FIGURES / "Fig_harmonized_auc_comparison_v0_3_1.png", dpi=220)
    plt.close(fig)


def fig_time_split() -> None:
    p = TABLES / "table_time_split_iact_source_rows_v0_3_2.csv"
    if not p.exists():
        return
    df = pd.read_csv(p, low_memory=False)
    d = df[(df["date_axis"] == "public_report_date") & (df["freeze_date"] == "2020-12-31") & df["catalogue_matched"].astype(bool)].copy()
    if d.empty:
        return
    d = d.drop_duplicates(subset=["source_name"]).sort_values("matched_full_percentile_v031")
    fig, ax = plt.subplots(figsize=(7.0, max(3.5, 0.45 * len(d) + 1.7)))
    y = np.arange(len(d))
    ax.scatter(d["matched_full_percentile_v031"], y, label="Full branch score")
    ax.scatter(d["matched_xray_only_percentile_v031"], y, marker="s", label="X-ray only")
    ax.axvline(85, linestyle="--", linewidth=1, label="Gold+Silver boundary")
    ax.axvline(95, linestyle=":", linewidth=1, label="Gold boundary")
    ax.set_yticks(y, d["source_name"])
    ax.set_xlim(0, 101)
    ax.set_xlabel("Frozen-catalogue percentile")
    ax.set_title("Post-2020 IACT report-date label split")
    ax.legend(fontsize=8)
    ax.grid(axis="x", alpha=0.3)
    fig.tight_layout()
    fig.savefig(FIGURES / "Fig_time_split_iact_validation_v0_3_2.pdf")
    fig.savefig(FIGURES / "Fig_time_split_iact_validation_v0_3_2.png", dpi=220)
    plt.close(fig)


def fig_observed_control() -> None:
    p = TABLES / "table_iact_observed_control_unique_sources_v0_3_3.csv"
    if not p.exists():
        return
    df = pd.read_csv(p, low_memory=False)
    if df.empty:
        return
    fig, ax = plt.subplots(figsize=(6.8, 4.5))
    groups = [
        pd.to_numeric(df.loc[df["firm_detection"].astype(bool), "matched_full_score_v031"], errors="coerce").dropna(),
        pd.to_numeric(df.loc[~df["firm_detection"].astype(bool), "matched_full_score_v031"], errors="coerce").dropna(),
    ]
    if all(len(g) for g in groups):
        ax.boxplot(groups, tick_labels=["Firm detection", "Observed non-firm"], showmeans=True)
        for i, g in enumerate(groups, start=1):
            ax.scatter(np.full(len(g), i), g, zorder=3)
        ax.set_ylabel("Full branch-coordinate score")
        ax.set_title("Matched MAGIC programme pilot")
        ax.grid(axis="y", alpha=0.3)
        fig.tight_layout()
        fig.savefig(FIGURES / "Fig_iact_observed_control_v0_3_3.pdf")
        fig.savefig(FIGURES / "Fig_iact_observed_control_v0_3_3.png", dpi=220)
    plt.close(fig)


def make_latex() -> None:
    text = r"""
% v0.3.1--v0.3.3 selection-history audit: conservative integration draft
\subsection{Harmonized uncertainty and AUROC comparison}
All AUROC variants were recomputed on one common complete-case population, and paired bootstrap intervals and correlated DeLong tests were evaluated on exactly the same rows. This harmonization removes sample-definition differences between the full, X-ray-only, and no-X-ray comparisons. Recovery fractions are accompanied by Wilson and Jeffreys intervals because the positive validation sample remains small.

\subsection{Hardened follow-up populations}
The former ``high-confidence'' label is not retained. We instead release two claim-gated products: an X-ray-prioritized list and an HSP-branch-frontier list. Each is divided into a secure low-redshift core, an unknown-redshift subset, a high-redshift attenuation-caution subset, and proxy/redshift-quality caution subsets. These strata are prioritization products rather than calibrated TeV-detection probabilities.

\subsection{Time-split IACT label audit}
We cross-matched a curated history of firm IACT detections against the frozen BlazEr1 catalogue and evaluated score tiers after report-date cuts at the ends of 2018 and 2020. This is described as a quasi-prospective label-time split rather than a strict temporally blind validation, because the score is frozen but historical snapshots of every input feature catalogue were not reconstructed. Unmatched detections are retained explicitly and reduce the effective validation sample.

\subsection{IACT-observed control pilot}
As a selection-history control, we compiled source-level outcomes from two homogeneous MAGIC extreme-blazar programmes and compared firm detections with programme targets yielding hints or upper limits. Historically established VHE sources were excluded from the primary candidate-outcome comparison. The BlazEr1 overlap is small; consequently, exact Fisher and permutation tests are reported and the result is treated as exploratory rather than as a definitive exposure-conditioned detection model.
"""
    (DOCS / "latex_selection_history_audit_v0_3_1_to_v0_3_3.tex").write_text(text.strip()+"\n", encoding="utf-8")


def main() -> None:
    fig_harmonized_auc()
    fig_time_split()
    fig_observed_control()
    make_latex()
    print("Saved v0.3.1--v0.3.3 figures and conservative LaTeX integration draft.")


if __name__ == "__main__":
    main()
