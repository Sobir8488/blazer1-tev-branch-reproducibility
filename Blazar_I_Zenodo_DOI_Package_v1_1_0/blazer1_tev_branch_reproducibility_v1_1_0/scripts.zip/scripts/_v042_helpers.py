from __future__ import annotations

from pathlib import Path
import json
import math
import os
from typing import Iterable

import numpy as np
import pandas as pd
from scipy.spatial import cKDTree
from scipy.stats import mannwhitneyu, spearmanr, ks_2samp

ROOT = Path(__file__).resolve().parents[1]
TABLES = ROOT / "tables"
FIGURES = ROOT / "figures"
DOCS = ROOT / "docs"
METADATA = ROOT / "metadata"
INTERIM = ROOT / "data" / "interim"
PROCESSED = ROOT / "data" / "processed"
for _p in (TABLES, FIGURES, DOCS, METADATA, INTERIM, PROCESSED):
    _p.mkdir(parents=True, exist_ok=True)

COMPONENTS = [
    {"key": "xray_brightness", "column": "S_X", "label": "X-ray brightness", "weight": 1.00, "sign": +1},
    {"key": "gamma_hardness", "column": "S_gamma_hard", "label": "Gamma-ray hardness", "weight": 1.00, "sign": +1},
    {"key": "gamma_variability", "column": "S_gamma_var", "label": "Gamma-ray variability", "weight": 0.35, "sign": +1},
    {"key": "wise_hsp_locus", "column": "S_IR", "label": "WISE/HSP-locus proxy", "weight": 0.75, "sign": +1},
    {"key": "radio_compactness", "column": "S_R", "label": "Radio-compactness proxy", "weight": 0.75, "sign": +1},
    {"key": "synchrotron_peak_proxy", "column": "S_nu_peak", "label": "Synchrotron-peak proxy", "weight": 1.00, "sign": +1},
    {"key": "compton_dominance_penalty", "column": "S_CD_penalty", "label": "Compton-dominance penalty", "weight": 0.60, "sign": -1},
    {"key": "ebl_penalty", "column": "S_EBL_proxy", "label": "Redshift/EBL penalty", "weight": 0.80, "sign": -1},
]


def numeric(s: pd.Series) -> pd.Series:
    return pd.to_numeric(s, errors="coerce").replace([np.inf, -np.inf], np.nan)


def boolean(s: pd.Series) -> pd.Series:
    if s.dtype == bool:
        return s.fillna(False)
    return s.astype(str).str.strip().str.lower().isin(["true", "1", "yes", "y", "t"])


def load_frozen_catalogue() -> pd.DataFrame:
    candidates = [
        PROCESSED / "tev_evolution_score_catalog_v0_1_8_xray_control_augmented.csv",
        PROCESSED / "tev_evolution_score_catalog_v0_1_8_interpretability_augmented.csv",
        PROCESSED / "tev_evolution_score_catalog_v0_1_6_branch_augmented.csv",
    ]
    for path in candidates:
        if path.exists():
            df = pd.read_csv(path, low_memory=False)
            df.attrs["source_path"] = str(path)
            if "is_known_tev" not in df.columns:
                if "tevcat_matched" in df.columns:
                    df["is_known_tev"] = boolean(df["tevcat_matched"])
                else:
                    df["is_known_tev"] = False
            else:
                df["is_known_tev"] = boolean(df["is_known_tev"])
            return df
    raise FileNotFoundError(
        "Missing frozen score catalogue. Run scripts/23_component_contribution_analysis.py "
        "and scripts/24_xray_matched_validation.py first."
    )


def robust_location_scale(x: pd.Series) -> tuple[float, float, float, int]:
    x = numeric(x)
    med = float(x.median()) if x.notna().any() else np.nan
    mad = float((x - med).abs().median()) if x.notna().any() else np.nan
    scale = float(1.4826 * mad) if np.isfinite(mad) else np.nan
    return med, mad, scale, int(x.notna().sum())


def resolve_first_existing(columns: Iterable[str], candidates: Iterable[str]) -> str | None:
    columns = list(columns)
    lower = {c.lower(): c for c in columns}
    for candidate in candidates:
        if candidate in columns:
            return candidate
        if candidate.lower() in lower:
            return lower[candidate.lower()]
    return None


def auroc(y_true: pd.Series | np.ndarray, scores: pd.Series | np.ndarray) -> float:
    y = np.asarray(y_true).astype(bool)
    s = np.asarray(scores, dtype=float)
    valid = np.isfinite(s)
    y, s = y[valid], s[valid]
    n_pos, n_neg = int(y.sum()), int((~y).sum())
    if n_pos == 0 or n_neg == 0:
        return np.nan
    u = mannwhitneyu(s[y], s[~y], alternative="greater").statistic
    return float(u / (n_pos * n_neg))


def fixed_fraction_tiers(scores: pd.Series) -> pd.Series:
    s = numeric(scores)
    out = pd.Series("Low", index=s.index, dtype="object")
    valid = s.dropna()
    if valid.empty:
        return out
    q95, q85, q70 = np.nanpercentile(valid, [95, 85, 70])
    out.loc[s >= q70] = "Bronze"
    out.loc[s >= q85] = "Silver"
    out.loc[s >= q95] = "Gold"
    return out


def unit_vectors(ra_deg: np.ndarray, dec_deg: np.ndarray) -> np.ndarray:
    ra = np.deg2rad(np.asarray(ra_deg, dtype=float))
    dec = np.deg2rad(np.asarray(dec_deg, dtype=float))
    return np.column_stack((np.cos(dec) * np.cos(ra), np.cos(dec) * np.sin(ra), np.sin(dec)))


def chord_to_arcsec(chord: np.ndarray) -> np.ndarray:
    angle_rad = 2.0 * np.arcsin(np.clip(np.asarray(chord, dtype=float) / 2.0, 0.0, 1.0))
    return np.rad2deg(angle_rad) * 3600.0


def nearest_sky_match(left_ra, left_dec, right_ra, right_dec) -> tuple[np.ndarray, np.ndarray]:
    left_xyz = unit_vectors(left_ra, left_dec)
    right_xyz = unit_vectors(right_ra, right_dec)
    tree = cKDTree(right_xyz)
    chord, idx = tree.query(left_xyz, k=1)
    return np.asarray(idx, dtype=int), chord_to_arcsec(chord)


def spherical_offset(ra_deg, dec_deg, distance_deg, bearing_rad) -> tuple[np.ndarray, np.ndarray]:
    lon = np.deg2rad(np.asarray(ra_deg, dtype=float))
    lat = np.deg2rad(np.asarray(dec_deg, dtype=float))
    distance = np.deg2rad(np.asarray(distance_deg, dtype=float))
    bearing = np.asarray(bearing_rad, dtype=float)
    lat2 = np.arcsin(
        np.sin(lat) * np.cos(distance)
        + np.cos(lat) * np.sin(distance) * np.cos(bearing)
    )
    lon2 = lon + np.arctan2(
        np.sin(bearing) * np.sin(distance) * np.cos(lat),
        np.cos(distance) - np.sin(lat) * np.sin(lat2),
    )
    return np.mod(np.rad2deg(lon2), 360.0), np.rad2deg(lat2)


def standardized_mean_difference(a: pd.Series, b: pd.Series) -> float:
    a, b = numeric(a).dropna(), numeric(b).dropna()
    if len(a) < 2 or len(b) < 2:
        return np.nan
    pooled = math.sqrt(
        ((len(a) - 1) * a.var(ddof=1) + (len(b) - 1) * b.var(ddof=1))
        / (len(a) + len(b) - 2)
    )
    if not np.isfinite(pooled) or pooled == 0:
        return np.nan
    return float((a.mean() - b.mean()) / pooled)


def comparison_stats(a: pd.Series, b: pd.Series) -> dict:
    a, b = numeric(a).dropna(), numeric(b).dropna()
    result = {
        "group_a_N": len(a),
        "group_b_N": len(b),
        "group_a_median": float(a.median()) if len(a) else np.nan,
        "group_b_median": float(b.median()) if len(b) else np.nan,
        "group_a_mean": float(a.mean()) if len(a) else np.nan,
        "group_b_mean": float(b.mean()) if len(b) else np.nan,
        "standardized_mean_difference": standardized_mean_difference(a, b),
        "ks_p_two_sided": np.nan,
        "mannwhitney_p_two_sided": np.nan,
    }
    if len(a) and len(b):
        result["ks_p_two_sided"] = float(ks_2samp(a, b, alternative="two-sided").pvalue)
        result["mannwhitney_p_two_sided"] = float(
            mannwhitneyu(a, b, alternative="two-sided").pvalue
        )
    return result


def safe_spearman(a: pd.Series, b: pd.Series) -> tuple[float, float, int]:
    a, b = numeric(a), numeric(b)
    valid = a.notna() & b.notna()
    if int(valid.sum()) < 3:
        return np.nan, np.nan, int(valid.sum())
    rho, p = spearmanr(a[valid], b[valid])
    return float(rho), float(p), int(valid.sum())


def write_json(path: Path, obj: object) -> None:
    path.write_text(json.dumps(obj, indent=2, ensure_ascii=False), encoding="utf-8")
