#!/usr/bin/env python
"""
Build a compact v0.1.7 review-defence report from radius sensitivity,
proxy-scope audit, and claim-gating tables.
"""
from pathlib import Path
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
TABLES = ROOT / "tables"
DOCS = ROOT / "docs"


def read(path):
    if not path.exists():
        return None
    return pd.read_csv(path)


def csv_block(df, max_rows=50):
    if df is None:
        return "MISSING"
    return df.head(max_rows).to_string(index=False)


def main():
    DOCS.mkdir(exist_ok=True, parents=True)
    radius = read(TABLES / "table_tevcat_radius_sensitivity_v0_1_7.csv")
    radio = read(TABLES / "table_radio_proxy_scope_audit_v0_1_7.csv")
    nupeak = read(TABLES / "table_nu_peak_proxy_method_counts_v0_1_7.csv")
    claim = read(TABLES / "table_score_claim_gate_v0_1_7.csv")

    lines = []
    lines.append("# v0.1.7 reviewer-defence report")
    lines.append("")
    lines.append("This report addresses four remaining manuscript risks:")
    lines.append("1. VLASS morphology overclaim -> radio-compactness proxy language.")
    lines.append("2. Mixed-source synchrotron-peak proxy -> explicit limitation and method-count table.")
    lines.append("3. TeVCat match-radius sensitivity -> validation repeated at 60, 90, 120, 180 arcsec.")
    lines.append("4. Human-designed score weights -> score described as an empirical diagnostic, not a calibrated physical probability.")
    lines.append("")

    if radius is not None:
        lines.append("## TeVCat radius sensitivity")
        lines.append("")
        for tier in ["Gold", "Gold+Silver"]:
            sub = radius[radius["tier_set"] == tier]
            if len(sub):
                r60 = sub[sub["radius_arcsec"] == 60]
                r180 = sub[sub["radius_arcsec"] == 180]
                if len(r60) and len(r180):
                    lines.append(f"- {tier}: recovery {r60.iloc[0]['known_TeV_recovery_fraction']:.3f} at 60 arcsec and {r180.iloc[0]['known_TeV_recovery_fraction']:.3f} at 180 arcsec; enrichment {r60.iloc[0]['enrichment_vs_random']:.2f}x to {r180.iloc[0]['enrichment_vs_random']:.2f}x.")
        lines.append("")
        lines.append("```text")
        lines.append(csv_block(radius))
        lines.append("```")
        lines.append("")

    lines.append("## Radio/VLASS scope audit")
    lines.append("")
    lines.append("```text")
    lines.append(csv_block(radio))
    lines.append("```")
    lines.append("")

    lines.append("## Synchrotron-peak proxy methods")
    lines.append("")
    lines.append("```text")
    lines.append(csv_block(nupeak))
    lines.append("```")
    lines.append("")

    lines.append("## Claim gate")
    lines.append("")
    lines.append("```text")
    lines.append(csv_block(claim))
    lines.append("```")
    lines.append("")

    lines.append("## Recommended manuscript wording")
    lines.append("")
    lines.append("Use: empirical, physically interpretable TeV-favourability diagnostic score.")
    lines.append("Avoid: calibrated TeV probability.")
    lines.append("Use: population-level ordered branch or demographic sequence.")
    lines.append("Avoid: direct temporal evolution of individual blazars.")
    lines.append("Use: radio-compactness proxy.")
    lines.append("Avoid: homogeneous VLASS morphology, unless a real VLASS layer is added.")
    lines.append("Use: mixed-source synchrotron-peak proxy.")
    lines.append("Avoid: uniform direct peak-frequency measurement for all sources.")

    out = DOCS / "review_defence_report_v0_1_7.md"
    out.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(f"Wrote {out}")


if __name__ == "__main__":
    main()
