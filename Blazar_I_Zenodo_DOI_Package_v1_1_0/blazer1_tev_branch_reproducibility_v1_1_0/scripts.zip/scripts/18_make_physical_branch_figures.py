#!/usr/bin/env python
"""Make manuscript figures for v0.1.6 physical-branch tests."""
from __future__ import annotations

from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

ROOT = Path('.')
FIG = ROOT / 'figures'
TABLES = ROOT / 'tables'
FIG.mkdir(parents=True, exist_ok=True)

CAT = ROOT / 'data/processed/tev_evolution_score_catalog_v0_1_6_branch_augmented.csv'
if not CAT.exists():
    CAT = ROOT / 'data/processed/tev_evolution_score_catalog_v0_1_5_augmented.csv'

STAGE_ORDER = ['FSRQ/QSO-like', 'BCU/uncertain', 'BL Lac-like', 'HSP-like']


def load_df() -> pd.DataFrame:
    df = pd.read_csv(CAT, low_memory=False)
    if 'branch_stage' not in df.columns:
        stage = df.get('broad_class', pd.Series('BCU/uncertain', index=df.index)).astype(str)
        stage = stage.where(stage.isin(STAGE_ORDER[:-1]), 'BCU/uncertain')
        if 'sed_class_proxy' in df.columns:
            stage = stage.where(df['sed_class_proxy'].astype(str).ne('HSP-like'), 'HSP-like')
        df['branch_stage'] = stage
    if 'is_known_tev_clean' not in df.columns:
        known = pd.Series(False, index=df.index)
        for c in ['is_known_tev', 'tevcat_matched']:
            if c in df.columns:
                known = known | df[c].astype(str).str.lower().isin(['true', '1', 'yes'])
        df['is_known_tev_clean'] = known
    if 'redshift_clean' not in df.columns:
        df['redshift_clean'] = pd.to_numeric(df.get('redshift_adopted_clean', df.get('redshift_adopted')), errors='coerce')
    return df


def fig_ordered_branch(df: pd.DataFrame) -> None:
    data = []
    labels = []
    for st in STAGE_ORDER:
        sub = df[df['branch_stage'].astype(str).eq(st)]
        data.append(pd.to_numeric(sub['S_TeV_evo'], errors='coerce').dropna().to_numpy())
        labels.append(f'{st}\nN={len(sub)}')
    plt.figure(figsize=(8.2, 5.2))
    bp = plt.boxplot(data, tick_labels=labels, showfliers=False)
    # Known-TeV points overlay.
    rng = np.random.default_rng(8488)
    for i, st in enumerate(STAGE_ORDER, start=1):
        sub = df[df['branch_stage'].astype(str).eq(st) & df['is_known_tev_clean'].astype(bool)]
        y = pd.to_numeric(sub['S_TeV_evo'], errors='coerce').dropna().to_numpy()
        if len(y):
            x = i + rng.normal(0, 0.045, size=len(y))
            plt.scatter(x, y, marker='x', label='Known TeV' if i == 1 else None, zorder=3)
    plt.axhline(0, lw=0.7, alpha=0.6)
    plt.ylabel(r'$S_{\rm TeV,evo}$')
    plt.xlabel('Ordered population branch proxy')
    plt.title('Ordered TeV-favourable branch sequence')
    plt.legend(frameon=False)
    plt.tight_layout()
    for ext in ['pdf','png']:
        plt.savefig(FIG / f'Fig_ordered_branch_sequence_v0_1_6.{ext}', dpi=250)
    plt.close()


def fig_partial_plane(df: pd.DataFrame) -> None:
    d = df.copy()
    d['score'] = pd.to_numeric(d['S_TeV_evo'], errors='coerce')
    d['nu'] = pd.to_numeric(d['log_nu_peak_proxy'], errors='coerce')
    d['z'] = pd.to_numeric(d['redshift_clean'], errors='coerce')
    d = d[d[['score','nu','z']].notna().all(axis=1)]
    plt.figure(figsize=(7.8, 5.3))
    other = d[~d['is_known_tev_clean'].astype(bool)]
    known = d[d['is_known_tev_clean'].astype(bool)]
    sc = plt.scatter(other['nu'], other['score'], c=other['z'], s=9, alpha=0.25, label='Other BlazEr1 sources')
    plt.scatter(known['nu'], known['score'], c=known['z'], marker='x', s=45, label='Known TeV matches')
    cbar = plt.colorbar(sc)
    cbar.set_label('Adopted redshift')
    plt.xlabel(r'$\log_{10}\nu_{\rm peak}$ proxy')
    plt.ylabel(r'$S_{\rm TeV,evo}$')
    plt.title('Score--synchrotron-peak plane coloured by redshift')
    plt.legend(frameon=False)
    plt.tight_layout()
    for ext in ['pdf','png']:
        plt.savefig(FIG / f'Fig_score_nupeak_redshift_plane_v0_1_6.{ext}', dpi=250)
    plt.close()


def fig_redshift_bins() -> None:
    p = TABLES / 'table_redshift_bin_evolutionary_branch_v0_1_6.csv'
    if not p.exists():
        return
    t = pd.read_csv(p)
    x = np.arange(len(t))
    plt.figure(figsize=(9.0, 5.0))
    plt.plot(x, t['median_score'], marker='o', label='Median score')
    plt.ylabel(r'Median $S_{\rm TeV,evo}$')
    plt.xlabel('Redshift bin')
    plt.xticks(x, t['z_bin'], rotation=45, ha='right')
    ax2 = plt.gca().twinx()
    ax2.plot(x, t['gold_fraction'], marker='s', linestyle='--', label='Gold fraction')
    ax2.plot(x, t['known_TeV_fraction'], marker='^', linestyle=':', label='Known-TeV fraction')
    ax2.set_ylabel('Fraction')
    lines1, labels1 = plt.gca().get_legend_handles_labels()
    lines2, labels2 = ax2.get_legend_handles_labels()
    plt.legend(lines1 + lines2, labels1 + labels2, frameon=False, loc='upper right')
    plt.title('Redshift-bin evolution of TeV-favourable branch diagnostics')
    plt.tight_layout()
    for ext in ['pdf','png']:
        plt.savefig(FIG / f'Fig_redshift_bin_branch_diagnostics_v0_1_6.{ext}', dpi=250)
    plt.close()


def fig_weight_sensitivity() -> None:
    p = TABLES / 'table_weight_sensitivity_random_draws_v0_1_6.csv'
    if not p.exists():
        return
    d = pd.read_csv(p)
    cols = ['gold_known_TeV_fraction', 'gold_silver_known_TeV_fraction', 'AUROC_knownTeV_vs_other', 'gold_overlap_with_baseline_fraction']
    data = [pd.to_numeric(d[c], errors='coerce').dropna().to_numpy() for c in cols]
    labels = ['Gold\nrecovery', 'Gold+Silver\nrecovery', 'AUROC', 'Gold overlap\nwith baseline']
    plt.figure(figsize=(8.4, 4.8))
    plt.boxplot(data, tick_labels=labels, showfliers=False)
    plt.ylim(0, 1.05)
    plt.ylabel('Metric value under ±30% random weight perturbations')
    plt.title('Score-weight sensitivity')
    plt.tight_layout()
    for ext in ['pdf','png']:
        plt.savefig(FIG / f'Fig_weight_sensitivity_v0_1_6.{ext}', dpi=250)
    plt.close()


def main() -> None:
    df = load_df()
    fig_ordered_branch(df)
    fig_partial_plane(df)
    fig_redshift_bins()
    fig_weight_sensitivity()
    print('Saved v0.1.6 figures:')
    for f in sorted(FIG.glob('*v0_1_6.pdf')):
        print(f)


if __name__ == '__main__':
    main()
