#!/usr/bin/env python
from __future__ import annotations

from pathlib import Path
import hashlib
import json
import re
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
TABLES = ROOT / "tables"
FIGURES = ROOT / "figures"
DOCS = ROOT / "docs"
METADATA = ROOT / "metadata"
PROCESSED = ROOT / "data" / "processed"
METADATA.mkdir(parents=True, exist_ok=True)

EXPECTED = [
    PROCESSED / "tev_evolution_score_catalog_v0_4_4_active_final.csv",
    TABLES / "table_active_primary_validation_v0_4_4.csv",
    TABLES / "table_active_harmonized_auc_v0_4_4.csv",
    TABLES / "table_active_harmonized_delong_v0_4_4.csv",
    TABLES / "table_active_ordered_branch_summary_v0_4_4.csv",
    TABLES / "table_active_partial_correlation_v0_4_4.csv",
    TABLES / "table_active_selection_stress_v0_4_4.csv",
    TABLES / "table_active_component_contributions_v0_4_4.csv",
    TABLES / "table_active_hsp_circularity_v0_4_4.csv",
    TABLES / "table_active_candidate_list_summary_v0_4_4.csv",
    TABLES / "candidate_list_A_xray_prioritized_active_primary_all_v0_4_4.csv",
    TABLES / "candidate_list_B_HSP_branch_frontier_active_primary_all_v0_4_4.csv",
    TABLES / "table_active_time_split_iact_v0_4_4.csv",
    TABLES / "table_active_iact_observed_metrics_v0_4_4.csv",
    FIGURES / "Fig_active_harmonized_auc_v0_4_4.pdf",
    FIGURES / "Fig_active_TeVCat_validation_v0_4_4.pdf",
    FIGURES / "Fig_active_hsp_circularity_v0_4_4.pdf",
    FIGURES / "Fig_active_ordered_branch_v0_4_4.pdf",
    FIGURES / "Fig_active_component_contributions_v0_4_4.pdf",
    FIGURES / "Fig_active_followup_lists_v0_4_4.pdf",
    FIGURES / "Fig_active_iact_audits_v0_4_4.pdf",
    ROOT / "Blazar_I_active_score_v0_4_4.tex",
    ROOT / "appendix_active_score_v0_4_4.tex",
    DOCS / "active_score_propagation_report_v0_4_4.md",
]

FORBIDDEN_TEX_PATTERNS = {
    r"S_\{\\rm TeV,evo\}": "old TeV-evolution score symbol",
    r"TeV-evolution score": "old evolution terminology",
    r"X-ray-confirmed": "overclaiming candidate label",
    r"\\input\{appendix_v0_4_1\}": "old Appendix input",
}


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def main() -> None:
    missing = [str(p.relative_to(ROOT)) for p in EXPECTED if not p.exists()]
    manuscript = ROOT / "Blazar_I_active_score_v0_4_4.tex"
    tex_findings = []
    if manuscript.exists():
        text = manuscript.read_text(encoding="utf-8", errors="replace")
        for pattern, meaning in FORBIDDEN_TEX_PATTERNS.items():
            if re.search(pattern, text, flags=re.I):
                tex_findings.append({"pattern": pattern, "meaning": meaning})
        if "S_{\\rm TeV,branch}" not in text and "S_{{\\rm TeV,branch}" not in text:
            tex_findings.append({"pattern": "missing_active_symbol", "meaning": "active branch symbol not found"})
        if "appendix_active_score_v0_4_4" not in text:
            tex_findings.append({"pattern": "missing_active_appendix", "meaning": "active Appendix input not found"})

    science_checks = []
    try:
        val = pd.read_csv(TABLES / "table_active_primary_validation_v0_4_4.csv")
        gold = val[(val.score_variant == "active_primary") & (val.tier_set == "Gold")].iloc[0]
        gs = val[(val.score_variant == "active_primary") & (val.tier_set == "Gold+Silver")].iloc[0]
        science_checks += [
            {"check": "parent_N", "value": int(gold.analysis_N), "pass": int(gold.analysis_N) == 5865},
            {"check": "known_TeV_N", "value": int(gold.known_TeV_N), "pass": int(gold.known_TeV_N) == 34},
            {"check": "Gold_N", "value": int(gold.tier_N), "pass": int(gold.tier_N) == 294},
            {"check": "Gold_Silver_N", "value": int(gs.tier_N), "pass": int(gs.tier_N) == 880},
        ]
        auc = pd.read_csv(TABLES / "table_active_harmonized_auc_v0_4_4.csv").set_index("quantity")
        ax = float(auc.loc["AUROC xray_only", "estimate"])
        full = float(auc.loc["AUROC active_full", "estimate"])
        nox = float(auc.loc["AUROC no_xray", "estimate"])
        science_checks.append({"check": "Xray_gt_active_gt_noX", "value": [ax, full, nox], "pass": bool(ax > full > nox)})
        cand = pd.read_csv(TABLES / "table_active_candidate_list_summary_v0_4_4.csv")
        list_a = int(cand.loc[cand.followup_list == "A_xray_prioritized", "N"].sum())
        list_b = int(cand.loc[cand.followup_list == "B_HSP_branch_frontier", "N"].sum())
        science_checks += [
            {"check": "List_A_N_positive", "value": list_a, "pass": list_a > 0},
            {"check": "List_B_N_positive", "value": list_b, "pass": list_b > 0},
        ]
    except Exception as exc:
        science_checks.append({"check": "science_table_read", "value": repr(exc), "pass": False})

    files = []
    for path in EXPECTED:
        if path.exists():
            files.append({
                "path": str(path.relative_to(ROOT)).replace("\\", "/"),
                "bytes": path.stat().st_size,
                "sha256": sha256(path),
            })

    ok = not missing and not tex_findings and all(bool(x["pass"]) for x in science_checks)
    report = {
        "release": "v0.4.4",
        "status": "PASS" if ok else "FAIL",
        "missing_files": missing,
        "tex_findings": tex_findings,
        "science_checks": science_checks,
        "files": files,
    }
    (METADATA / "active_release_validation_v0_4_4.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    pd.DataFrame(files).to_csv(METADATA / "active_release_checksums_v0_4_4.csv", index=False)

    print(f"v0.4.4 active-release validation: {report['status']}")
    if missing:
        print("Missing files:")
        for item in missing:
            print(" -", item)
    if tex_findings:
        print("TeX findings:")
        for item in tex_findings:
            print(" -", item)
    print("Science checks:")
    for item in science_checks:
        print(f" - {item['check']}: {item['value']} -> {'PASS' if item['pass'] else 'FAIL'}")
    if not ok:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
