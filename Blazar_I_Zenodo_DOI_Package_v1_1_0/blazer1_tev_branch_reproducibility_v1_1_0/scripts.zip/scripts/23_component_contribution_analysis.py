from __future__ import annotations

import sys
from pathlib import Path
sys.path.append(str(Path(__file__).resolve().parent))

import numpy as np
import pandas as pd
from _v018_helpers import ROOT, TABLES, DOCS, PROCESSED, COMPONENTS, clean_numeric, load_score_catalogue, compute_score_from_components


def add_contributions(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    denom = pd.Series(0.0, index=out.index, dtype=float)
    for key, meta in COMPONENTS.items():
        col = meta['col']
        if col not in out.columns:
            continue
        x = clean_numeric(out[col])
        denom.loc[x.notna()] += abs(meta['weight'])
    for key, meta in COMPONENTS.items():
        col = meta['col']
        ccol = f"C_{key}"
        if col not in out.columns:
            out[ccol] = np.nan
            continue
        x = clean_numeric(out[col])
        out[ccol] = meta['sign'] * meta['weight'] * x / denom.replace(0, np.nan)
    out['S_TeV_evo_reconstructed_v0_1_8'] = out[[f"C_{k}" for k in COMPONENTS]].sum(axis=1, min_count=1)
    return out


def group_masks(df: pd.DataFrame) -> dict[str, pd.Series]:
    tier = df.get('tev_priority_tier', pd.Series('', index=df.index)).astype(str)
    branch = df.get('branch_stage', df.get('broad_class', pd.Series('', index=df.index))).astype(str)
    sed = df.get('sed_class_proxy', pd.Series('', index=df.index)).astype(str)
    known = df['is_known_tev'].astype(bool)
    return {
        'all_sources': pd.Series(True, index=df.index),
        'known_TeV': known,
        'non_known_TeV': ~known,
        'Gold_all': tier.eq('Gold'),
        'Gold_non_TeV': tier.eq('Gold') & (~known),
        'Gold_known_TeV': tier.eq('Gold') & known,
        'GoldPlusSilver_all': tier.isin(['Gold','Silver']),
        'BL_Lac_like': branch.str.contains('BL Lac', case=False, na=False),
        'HSP_like': branch.str.contains('HSP', case=False, na=False) | sed.str.contains('HSP', case=False, na=False),
    }


def contribution_summary(df: pd.DataFrame) -> pd.DataFrame:
    rows = []
    masks = group_masks(df)
    for gname, m in masks.items():
        d = df.loc[m].copy()
        if len(d) == 0:
            continue
        mean_abs_total = 0.0
        abs_means = {}
        for key in COMPONENTS:
            c = clean_numeric(d[f'C_{key}'])
            abs_mean = float(c.abs().mean()) if c.notna().any() else np.nan
            abs_means[key] = abs_mean
            if np.isfinite(abs_mean):
                mean_abs_total += abs_mean
        for key, meta in COMPONENTS.items():
            c = clean_numeric(d[f'C_{key}'])
            valid = c.notna()
            rows.append({
                'sample': gname,
                'N': int(len(d)),
                'component': key,
                'component_label': meta['label'],
                'input_column': meta['col'],
                'weight': meta['weight'],
                'sign': meta['sign'],
                'available_N': int(valid.sum()),
                'available_fraction': float(valid.mean()) if len(d) else np.nan,
                'mean_signed_contribution': float(c.mean()) if valid.any() else np.nan,
                'median_signed_contribution': float(c.median()) if valid.any() else np.nan,
                'mean_abs_contribution': abs_means[key],
                'fraction_of_abs_contribution': abs_means[key] / mean_abs_total if mean_abs_total > 0 and np.isfinite(abs_means[key]) else np.nan,
                'positive_contribution_fraction': float((c > 0).mean()) if valid.any() else np.nan,
            })
    return pd.DataFrame(rows)


def compact_table(summary: pd.DataFrame) -> pd.DataFrame:
    keep_samples = ['known_TeV', 'Gold_all', 'Gold_non_TeV', 'BL_Lac_like', 'HSP_like']
    d = summary[summary['sample'].isin(keep_samples)].copy()
    d = d[['sample','component_label','available_fraction','mean_signed_contribution','fraction_of_abs_contribution']]
    d['contribution_percent'] = 100 * d['fraction_of_abs_contribution']
    return d.sort_values(['sample','contribution_percent'], ascending=[True,False])


def main():
    df = load_score_catalogue()
    df = add_contributions(df)
    outcat = PROCESSED / 'tev_evolution_score_catalog_v0_1_8_interpretability_augmented.csv'
    df.to_csv(outcat, index=False)

    summary = contribution_summary(df)
    summary.to_csv(TABLES / 'table_component_contributions_v0_1_8.csv', index=False)
    compact = compact_table(summary)
    compact.to_csv(TABLES / 'table_component_contributions_compact_v0_1_8.csv', index=False)

    # Reconstructed-score check
    check = df[['S_TeV_evo','S_TeV_evo_reconstructed_v0_1_8']].dropna()
    max_abs_delta = float((check['S_TeV_evo'] - check['S_TeV_evo_reconstructed_v0_1_8']).abs().max()) if len(check) else np.nan
    meta = pd.DataFrame([{
        'catalogue_source': df.attrs.get('source_path','unknown'),
        'N': len(df),
        'reconstructed_score_check_N': len(check),
        'max_abs_delta_original_minus_reconstructed': max_abs_delta,
        'interpretation': 'Component contributions are normalized signed terms of the empirical additive score.'
    }])
    meta.to_csv(TABLES / 'table_component_contribution_reconstruction_check_v0_1_8.csv', index=False)

    snippet = r'''
% v0.1.8 component-contribution result
The score was decomposed into its signed, weight-normalized component contributions. This is not a machine-learning SHAP value but an exact additive decomposition of the empirical score. The decomposition is used to test whether the TeV recovery is reducible to a single term, especially X-ray brightness. The X-ray term is expected to be important for HSP-like TeV emitters, but a multi-component contribution pattern indicates that the branch also depends on synchrotron-peak state, redshift/EBL transparency, gamma-ray hardness, and compact-jet proxies.
'''
    (DOCS / 'latex_snippet_component_contributions_v0_1_8.tex').write_text(snippet, encoding='utf-8')

    print('v0.1.8 component-contribution analysis complete.')
    print('Augmented catalogue:', outcat)
    print('\nCompact contribution table:')
    show = compact[compact['sample'].isin(['known_TeV','Gold_all'])].copy()
    print(show.to_string(index=False))
    print('\nReconstruction check:')
    print(meta.to_string(index=False))

if __name__ == '__main__':
    main()
