from __future__ import annotations

from pathlib import Path
import itertools
import math
import numpy as np
import pandas as pd
from scipy.stats import binomtest, fisher_exact, rankdata

from _v030_helpers import (
    ROOT, PROCESSED, TABLES, FIGURES, DOCS, numeric, as_bool,
    source_name, auc_rank, assign_tier, percentile_rank,
    wilson_interval, jeffreys_interval, delong_pair,
    paired_stratified_bootstrap,
)

EXTERNAL = ROOT / "data" / "external"
EXTERNAL.mkdir(parents=True, exist_ok=True)


def load_frozen() -> tuple[pd.DataFrame, Path]:
    path = PROCESSED / "tev_evolution_score_catalog_v0_1_8_xray_control_augmented.csv"
    if not path.exists():
        raise FileNotFoundError(
            f"Missing {path}. Run the v0.1.8 X-ray-control patch first."
        )
    df = pd.read_csv(path, low_memory=False)
    if "is_known_tev" not in df.columns:
        raise KeyError("Frozen catalogue has no is_known_tev validation label.")
    df["is_known_tev"] = as_bool(df["is_known_tev"])
    df["row_id"] = np.arange(len(df), dtype=int)
    df["source_name_v031"] = source_name(df)
    return df, path


def choose_score_columns(df: pd.DataFrame) -> dict[str, str]:
    candidates = {
        "full": ["S_full_recomputed_v0_1_8", "S_TeV_evo"],
        "xray_only": ["S_xray_only_v0_1_8", "S_X"],
        "no_xray": ["S_no_xray_v0_1_8"],
    }
    out: dict[str, str] = {}
    for name, cols in candidates.items():
        for col in cols:
            if col in df.columns:
                out[name] = col
                break
        if name not in out:
            raise KeyError(f"No score column found for {name}: {cols}")
    return out


def angular_separation_arcsec(ra1: float, dec1: float, ra2: np.ndarray, dec2: np.ndarray) -> np.ndarray:
    """Great-circle separation in arcsec; input coordinates are degrees."""
    r1 = math.radians(float(ra1))
    d1 = math.radians(float(dec1))
    r2 = np.deg2rad(np.asarray(ra2, dtype=float))
    d2 = np.deg2rad(np.asarray(dec2, dtype=float))
    cosang = np.sin(d1) * np.sin(d2) + np.cos(d1) * np.cos(d2) * np.cos(r1 - r2)
    cosang = np.clip(cosang, -1.0, 1.0)
    return np.rad2deg(np.arccos(cosang)) * 3600.0


def coordinate_crossmatch(events: pd.DataFrame, catalogue: pd.DataFrame, radius_arcsec: float = 180.0) -> pd.DataFrame:
    ra = numeric(catalogue["ra_deg"]).to_numpy()
    dec = numeric(catalogue["dec_deg"]).to_numpy()
    valid_cat = np.isfinite(ra) & np.isfinite(dec)
    valid_idx = np.flatnonzero(valid_cat)
    rows = []
    for _, event in events.iterrows():
        rec = event.to_dict()
        era = pd.to_numeric(pd.Series([event.get("ra_deg")]), errors="coerce").iloc[0]
        edec = pd.to_numeric(pd.Series([event.get("dec_deg")]), errors="coerce").iloc[0]
        rec.update({
            "catalogue_matched": False,
            "catalogue_row_id": np.nan,
            "match_separation_arcsec": np.nan,
        })
        if np.isfinite(era) and np.isfinite(edec) and len(valid_idx):
            sep = angular_separation_arcsec(era, edec, ra[valid_idx], dec[valid_idx])
            j_local = int(np.nanargmin(sep))
            j = int(valid_idx[j_local])
            rec["match_separation_arcsec"] = float(sep[j_local])
            if sep[j_local] <= radius_arcsec:
                rec["catalogue_matched"] = True
                rec["catalogue_row_id"] = j
        rows.append(rec)
    return pd.DataFrame(rows)


def attach_catalogue_fields(matches: pd.DataFrame, catalogue: pd.DataFrame) -> pd.DataFrame:
    score_cols = choose_score_columns(catalogue)
    cat = catalogue.copy()
    for label, col in score_cols.items():
        cat[f"{label}_score_v031"] = numeric(cat[col])
        cat[f"{label}_percentile_v031"] = percentile_rank(cat[col])
        cat[f"{label}_tier_v031"] = assign_tier(cat[col])

    hsp_path = TABLES / "table_hsp_circularity_variant_assignments_v0_3_0.csv"
    if hsp_path.exists():
        hsp = pd.read_csv(hsp_path, low_memory=False)
        keep = [c for c in [
            "row_id", "score_continuous_peak_only", "tier_continuous_peak_only",
            "percentile_continuous_peak_only",
        ] if c in hsp.columns]
        cat = cat.merge(hsp[keep], on="row_id", how="left")
    else:
        cat["score_continuous_peak_only"] = np.nan
        cat["tier_continuous_peak_only"] = "unavailable"
        cat["percentile_continuous_peak_only"] = np.nan

    fields = [
        "row_id", "source_name_v031", "ra_deg", "dec_deg", "is_known_tev",
        "branch_stage", "redshift_adopted_clean", "redshift_secure",
        "log_nu_peak_proxy", "log_nu_peak_proxy_method", "S_X",
        "full_score_v031", "full_percentile_v031", "full_tier_v031",
        "xray_only_score_v031", "xray_only_percentile_v031", "xray_only_tier_v031",
        "no_xray_score_v031", "no_xray_percentile_v031", "no_xray_tier_v031",
        "score_continuous_peak_only", "tier_continuous_peak_only",
        "percentile_continuous_peak_only",
    ]
    fields = [c for c in fields if c in cat.columns]
    lookup = cat[fields].set_index("row_id")

    out = matches.copy()
    # Series.map preserves object/string columns and avoids dtype-coercion warnings.
    for c in fields:
        if c == "row_id":
            continue
        mapping = lookup[c]
        out[f"matched_{c}"] = out["catalogue_row_id"].map(mapping)
    return out


def exact_random_tier_test(k: int, n: int, expected_fraction: float) -> float:
    if n <= 0:
        return float("nan")
    return float(binomtest(k, n, expected_fraction, alternative="greater").pvalue)


def exact_permutation_auc(y: np.ndarray, score: np.ndarray, max_exact_combinations: int = 200000, seed: int = 8488) -> dict:
    y = np.asarray(y, dtype=bool)
    score = np.asarray(score, dtype=float)
    mask = np.isfinite(score)
    y, score = y[mask], score[mask]
    n = len(y)
    k = int(y.sum())
    obs = auc_rank(y, score)
    if n < 3 or k == 0 or k == n:
        return {"auc": obs, "p_two_sided": np.nan, "n_permutations": 0, "exact": False}
    total = math.comb(n, k)
    vals = []
    if total <= max_exact_combinations:
        for comb in itertools.combinations(range(n), k):
            yy = np.zeros(n, dtype=bool)
            yy[list(comb)] = True
            vals.append(auc_rank(yy, score))
        exact = True
    else:
        rng = np.random.default_rng(seed)
        for _ in range(max_exact_combinations):
            yy = np.zeros(n, dtype=bool)
            yy[rng.choice(n, size=k, replace=False)] = True
            vals.append(auc_rank(yy, score))
        exact = False
    vals = np.asarray(vals, dtype=float)
    p = (np.sum(np.abs(vals - 0.5) >= abs(obs - 0.5)) + 1) / (len(vals) + 1)
    return {"auc": obs, "p_two_sided": float(p), "n_permutations": len(vals), "exact": exact}


def to_bool_value(value) -> bool:
    return str(value).strip().lower() in {"1", "true", "t", "yes", "y"}
