#!/usr/bin/env python
from __future__ import annotations

import argparse
from pathlib import Path
import yaml
import pandas as pd
from blazar_input.io import read_catalog, standardize_position_columns


def standardize_one(path: Path, out: Path) -> None:
    df = read_catalog(path)
    df = standardize_position_columns(df)
    out.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(out, index=False)
    print(f"[OK] {path} -> {out} rows={len(df)} cols={len(df.columns)}")


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--config", default="configs/config.yaml")
    p.add_argument("--manifest", default="metadata/DATA_MANIFEST.yaml")
    args = p.parse_args()
    manifest = yaml.safe_load(Path(args.manifest).read_text())
    for key, item in manifest["catalogues"].items():
        raw = Path(item.get("expected_local_path", ""))
        if raw.exists():
            out = Path("data/interim") / f"{key}_standardized.csv"
            try:
                standardize_one(raw, out)
            except Exception as exc:
                print(f"[WARN] Could not standardize {key}: {exc}")
        else:
            print(f"[MISS] {key}: expected {raw}")


if __name__ == "__main__":
    main()
