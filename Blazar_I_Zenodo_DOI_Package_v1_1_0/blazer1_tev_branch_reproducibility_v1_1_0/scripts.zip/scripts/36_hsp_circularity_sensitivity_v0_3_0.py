#!/usr/bin/env python
from __future__ import annotations

import numpy as np
import pandas as pd
from scipy.stats import spearmanr

from _v030_helpers import (
    TABLES, DOCS, load_v018_catalogue, numeric, score_from_components,
    assign_tier, percentile_rank, auc_rank, partial_spearman, source_name, robust_zscore,
)


def tier_metrics(df: pd.DataFrame, score_col: str, tier_col: str, label: str, baseline_gold: pd.Series, baseline_top30: set[str]) -> dict:
    valid = numeric(df[score_col]).notna()
    d = df.loc[valid]
    y = d["is_known_tev"].astype(bool)
    gold = d[tier_col].eq("Gold")
    gs = d[tier_col].isin(["Gold", "Silver"])
    names = source_name(d)
    nontev = ~y
    top30_names = set(names[nontev].loc[numeric(d.loc[nontev, score_col]).sort_values(ascending=False).head(30).index])
    gold_index = set(d.index[gold])
    base_index = set(df.index[baseline_gold])
    overlap = len(gold_index & base_index) / max(1, len(gold_index | base_index))
    aa = numeric(d[score_col]); bb = numeric(d["S_TeV_evo"]); mm = aa.notna() & bb.notna()
    rho, p = spearmanr(aa[mm], bb[mm]) if mm.sum() >= 3 else (np.nan, np.nan)
    prho, pp, pn = partial_spearman(d[score_col], d["log_nu_peak_proxy"], d["redshift_adopted"])
    return {
        "score_variant": label, "N_score": len(d), "known_TeV_N": int(y.sum()),
        "Gold_N": int(gold.sum()), "Gold_known_TeV_N": int((gold & y).sum()),
        "Gold_recovery": float((gold & y).sum()/y.sum()),
        "Gold_Silver_N": int(gs.sum()), "Gold_Silver_known_TeV_N": int((gs & y).sum()),
        "Gold_Silver_recovery": float((gs & y).sum()/y.sum()),
        "AUROC": auc_rank(y.to_numpy(), numeric(d[score_col]).to_numpy()),
        "spearman_vs_baseline": float(rho), "spearman_p": float(p),
        "Gold_Jaccard_vs_baseline": overlap,
        "top30_nonTeV_overlap_N": len(top30_names & baseline_top30),
        "partial_rho_score_peak_control_z": prho, "partial_rho_p": pp, "partial_rho_N": pn,
    }


def main() -> None:
    df, source = load_v018_catalogue()
    method = df.get("log_nu_peak_proxy_method", pd.Series(pd.NA, index=df.index)).astype(str)
    lognu = numeric(df["log_nu_peak_proxy"])
    peak = robust_zscore(lognu)

    # Re-standardize each alternative on its own permitted input population.
    # This prevents removed categorical values from influencing the continuous-only scaling.
    lognu_no_catalogue_flag = lognu.where(~method.eq("HSP_CATALOGUE_FLAG"))
    peak_no_catalogue_flag = robust_zscore(lognu_no_catalogue_flag)
    continuous_method = method.isin(["LAC_LE_FREQ", "ALPHA_RX_PROXY"])
    lognu_continuous = lognu.where(continuous_method)
    peak_continuous = robust_zscore(lognu_continuous)

    df["S_branch_no_hsp_catalogue_flag_v0_3_0"] = score_from_components(df, peak_override=peak_no_catalogue_flag)
    df["S_branch_continuous_peak_only_v0_3_0"] = score_from_components(df, peak_override=peak_continuous)
    df["S_branch_no_peak_v0_3_0"] = score_from_components(df, exclude={"synchrotron_peak_proxy"})

    variants = {
        "baseline_full": "S_TeV_evo",
        "no_HSP_catalogue_flag": "S_branch_no_hsp_catalogue_flag_v0_3_0",
        "continuous_peak_only": "S_branch_continuous_peak_only_v0_3_0",
        "no_peak_component": "S_branch_no_peak_v0_3_0",
    }
    for label, score_col in variants.items():
        df[f"tier_{label}_v0_3_0"] = assign_tier(df[score_col])
        df[f"percentile_{label}_v0_3_0"] = percentile_rank(df[score_col])

    baseline_gold = df["tier_baseline_full_v0_3_0"].eq("Gold")
    names = source_name(df)
    baseline_top30 = set(names[(~df["is_known_tev"])].loc[numeric(df.loc[~df["is_known_tev"], "S_TeV_evo"]).sort_values(ascending=False).head(30).index])

    rows = []
    for label, score_col in variants.items():
        rows.append(tier_metrics(df, score_col, f"tier_{label}_v0_3_0", label, baseline_gold, baseline_top30))
    summary = pd.DataFrame(rows)
    summary.to_csv(TABLES / "table_hsp_circularity_sensitivity_summary_v0_3_0.csv", index=False)

    coverage = pd.DataFrame({
        "peak_variant": ["baseline mixed peak", "no HSP catalogue flag", "continuous only"],
        "available_N": [int(peak.notna().sum()), int(peak_no_catalogue_flag.notna().sum()), int(peak_continuous.notna().sum())],
        "available_fraction": [float(peak.notna().mean()), float(peak_no_catalogue_flag.notna().mean()), float(peak_continuous.notna().mean())],
    })
    coverage.to_csv(TABLES / "table_hsp_circularity_peak_coverage_v0_3_0.csv", index=False)

    keep = pd.DataFrame({
        "row_id": df.index,
        "source_name": names,
        "is_known_tev": df["is_known_tev"],
        "peak_proxy_method": method,
        "S_TeV_branch_baseline": numeric(df["S_TeV_evo"]),
    })
    for label, score_col in variants.items():
        keep[f"score_{label}"] = numeric(df[score_col])
        keep[f"tier_{label}"] = df[f"tier_{label}_v0_3_0"]
        keep[f"percentile_{label}"] = df[f"percentile_{label}_v0_3_0"]
    keep.to_csv(TABLES / "table_hsp_circularity_variant_assignments_v0_3_0.csv", index=False)

    lines = [
        "# v0.3.0 HSP-circularity sensitivity", "", f"Frozen catalogue: `{source}`", "",
        "The continuous-only peak score retains only `LAC_LE_FREQ` and `ALPHA_RX_PROXY`. Categorical SED/HSP catalogue flags are excluded from that peak term.", "",
        "## Coverage", "", coverage.to_markdown(index=False), "", "## Validation and list stability", "", summary.to_markdown(index=False),
    ]
    (DOCS / "hsp_circularity_sensitivity_report_v0_3_0.md").write_text("\n".join(lines), encoding="utf-8")

    print("v0.3.0 HSP-circularity sensitivity complete.")
    print(f"Frozen catalogue: {source}")
    print("\nPeak coverage:")
    print(coverage.to_string(index=False))
    print("\nVariant summary:")
    print(summary.to_string(index=False))


if __name__ == "__main__":
    main()
