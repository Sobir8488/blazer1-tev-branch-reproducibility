from __future__ import annotations

import os
import sys
from pathlib import Path
sys.path.append(str(Path(__file__).resolve().parent))

import numpy as np
import pandas as pd

from _v042_helpers import (
    TABLES, DOCS, load_frozen_catalogue, numeric, comparison_stats, auroc,
)


def _source_name(df: pd.DataFrame) -> pd.Series:
    for col in ["SRC_NAME", "source_name_v031", "IAUNAME", "FGL_SRC_NAME"]:
        if col in df.columns:
            return df[col].astype(str)
    return pd.Series(df.index.astype(str), index=df.index)


def _cluster_bootstrap_and_signflip(pair_values: pd.DataFrame, seed: int, n_boot: int = 5000, n_perm: int = 20000) -> dict:
    # pair_values columns: known_index, win_value. Each known source is one cluster.
    cluster = pair_values.groupby("known_index")["win_value"].mean().dropna()
    if cluster.empty:
        return {"cluster_N": 0, "estimate": np.nan, "ci95_low": np.nan, "ci95_high": np.nan, "signflip_p_two_sided": np.nan}
    rng = np.random.default_rng(seed)
    values = cluster.to_numpy(float)
    draws = np.empty(n_boot, dtype=float)
    for i in range(n_boot):
        draws[i] = rng.choice(values, size=len(values), replace=True).mean()
    observed = float(values.mean())
    centered = values - 0.5
    null_stats = np.empty(n_perm, dtype=float)
    for i in range(n_perm):
        signs = rng.choice([-1.0, 1.0], size=len(centered), replace=True)
        null_stats[i] = abs(np.mean(signs * centered))
    obs_stat = abs(observed - 0.5)
    p = float((1 + np.count_nonzero(null_stats >= obs_stat)) / (n_perm + 1))
    return {
        "cluster_N": int(len(values)),
        "estimate": observed,
        "ci95_low": float(np.quantile(draws, 0.025)),
        "ci95_high": float(np.quantile(draws, 0.975)),
        "signflip_p_two_sided": p,
    }


def main() -> None:
    df = load_frozen_catalogue().copy()
    df["source_name_v0_4_2"] = _source_name(df)
    df["S_X_clean_v0_4_2"] = numeric(df["S_X"])
    df = df[df["S_X_clean_v0_4_2"].notna()].copy()
    known = df[df["is_known_tev"].astype(bool)].copy()
    controls = df[~df["is_known_tev"].astype(bool)].copy()
    if len(known) == 0 or len(controls) == 0:
        raise RuntimeError("No known-TeV or non-TeV sources available for matching.")

    k = 5
    pair_rows = []
    for known_index, row in known.iterrows():
        distance = (controls["S_X_clean_v0_4_2"] - row["S_X_clean_v0_4_2"]).abs()
        nearest_indices = distance.nsmallest(k).index
        for rank, control_index in enumerate(nearest_indices, start=1):
            pair_rows.append({
                "known_index": int(known_index),
                "known_source_name": row["source_name_v0_4_2"],
                "known_S_X": float(row["S_X_clean_v0_4_2"]),
                "control_index": int(control_index),
                "control_source_name": controls.loc[control_index, "source_name_v0_4_2"],
                "control_S_X": float(controls.loc[control_index, "S_X_clean_v0_4_2"]),
                "nearest_rank": rank,
                "abs_delta_S_X": float(distance.loc[control_index]),
            })
    pairs = pd.DataFrame(pair_rows)

    score_columns = [
        ("S_TeV_evo", "full"),
        ("S_xray_only_v0_1_8", "xray_only"),
        ("S_no_xray_v0_1_8", "no_xray"),
        ("S_full_residual_after_xray_v0_1_8", "full_residual_after_xray"),
    ]
    for col, label in score_columns:
        if col not in df.columns:
            continue
        known_scores = numeric(df.loc[pairs["known_index"], col]).to_numpy()
        control_scores = numeric(df.loc[pairs["control_index"], col]).to_numpy()
        valid = np.isfinite(known_scores) & np.isfinite(control_scores)
        win = np.full(len(pairs), np.nan)
        win[valid] = (known_scores[valid] > control_scores[valid]).astype(float) + 0.5 * (known_scores[valid] == control_scores[valid])
        pairs[f"known_minus_control_{label}"] = known_scores - control_scores
        pairs[f"win_{label}"] = win
    pairs.to_csv(TABLES / "table_xray_matched_pairs_v0_4_2.csv", index=False)

    reuse = pairs.groupby("control_index").size().sort_values(ascending=False)
    unique_control_indices = pd.Index(pairs["control_index"].unique())
    unique_controls = controls.loc[unique_control_indices].copy()
    unique_sample = pd.concat([known, unique_controls], axis=0).copy()
    unique_sample["matched_role_v0_4_2"] = np.where(unique_sample["is_known_tev"], "known_TeV", "unique_nonTeV_control")
    unique_sample.to_csv(TABLES / "table_xray_matched_unique_sample_v0_4_2.csv", index=False)

    # Pair-expanded balance: each known object and its control are represented once per matched pair.
    feature_candidates = [
        ("S_X", "X-ray component"),
        ("redshift_adopted_clean", "Adopted redshift"),
        ("redshift_adopted", "Adopted redshift"),
        ("log_nu_peak_clean", "Synchrotron-peak proxy"),
        ("log_nu_peak_proxy", "Synchrotron-peak proxy"),
        ("S_TeV_evo", "Full branch score"),
        ("S_xray_only_v0_1_8", "X-ray-only score"),
        ("S_no_xray_v0_1_8", "No-X-ray score"),
        ("n_score_components_available", "Component count"),
    ]
    selected = []
    used = set()
    for col, label in feature_candidates:
        if col in df.columns and label not in used:
            selected.append((col, label))
            used.add(label)

    pair_balance_rows = []
    unique_balance_rows = []
    known_mask_unique = unique_sample["is_known_tev"].astype(bool)
    for col, label in selected:
        pair_known = pd.Series(numeric(df.loc[pairs["known_index"], col]).to_numpy())
        pair_control = pd.Series(numeric(df.loc[pairs["control_index"], col]).to_numpy())
        pair_balance_rows.append({"feature_column": col, "feature_label": label, **comparison_stats(pair_known, pair_control)})
        unique_balance_rows.append({
            "feature_column": col,
            "feature_label": label,
            **comparison_stats(unique_sample.loc[known_mask_unique, col], unique_sample.loc[~known_mask_unique, col]),
        })
    pair_balance = pd.DataFrame(pair_balance_rows)
    unique_balance = pd.DataFrame(unique_balance_rows)
    pair_balance.to_csv(TABLES / "table_xray_matched_balance_v0_4_2.csv", index=False)
    pair_balance.to_csv(TABLES / "table_xray_matched_balance_pair_weighted_v0_4_2.csv", index=False)
    unique_balance.to_csv(TABLES / "table_xray_matched_balance_unique_control_v0_4_2.csv", index=False)

    # Descriptive AUROCs under the original pair-weighted and unique-control representations.
    metric_rows = []
    for col, label in score_columns:
        if col not in df.columns:
            continue
        repeated_control_scores = numeric(df.loc[pairs["control_index"], col]).reset_index(drop=True)
        known_scores_once = numeric(known[col]).reset_index(drop=True)
        y_pair_weighted = pd.Series([True] * len(known_scores_once) + [False] * len(repeated_control_scores))
        s_pair_weighted = pd.concat([known_scores_once, repeated_control_scores], ignore_index=True)
        metric_rows.append({
            "control_representation": "pair_weighted_with_replacement",
            "score_variant": label,
            "analysis_N": len(s_pair_weighted),
            "known_TeV_N": len(known_scores_once),
            "control_rows_N": len(repeated_control_scores),
            "unique_control_sources_N": len(unique_control_indices),
            "AUROC_known_vs_control": auroc(y_pair_weighted, s_pair_weighted),
            "median_known": float(known_scores_once.median()),
            "median_control": float(repeated_control_scores.median()),
        })
        metric_rows.append({
            "control_representation": "unique_control_sensitivity",
            "score_variant": label,
            "analysis_N": len(unique_sample),
            "known_TeV_N": int(known_mask_unique.sum()),
            "control_rows_N": int((~known_mask_unique).sum()),
            "unique_control_sources_N": int((~known_mask_unique).sum()),
            "AUROC_known_vs_control": auroc(known_mask_unique, numeric(unique_sample[col])),
            "median_known": float(numeric(unique_sample.loc[known_mask_unique, col]).median()),
            "median_control": float(numeric(unique_sample.loc[~known_mask_unique, col]).median()),
        })
    metrics = pd.DataFrame(metric_rows)
    metrics.to_csv(TABLES / "table_xray_matched_score_metrics_v0_4_2.csv", index=False)

    seed = int(os.environ.get("BLAZER_V042_SEED", "8488"))
    win_rows = []
    for _, label in score_columns:
        col = f"win_{label}"
        if col not in pairs.columns:
            continue
        pv = pairs[["known_index", col]].rename(columns={col: "win_value"}).dropna()
        result = _cluster_bootstrap_and_signflip(pv, seed=seed + len(win_rows))
        win_rows.append({
            "score_variant": label,
            "matched_pair_rows_N": len(pv),
            "pairwise_win_fraction": float(pv["win_value"].mean()),
            **result,
            "null_value": 0.5,
            "interpretation": "fraction of within-match pairs in which the known-TeV score exceeds the control score; clusters are known sources",
        })
    win_table = pd.DataFrame(win_rows)
    win_table.to_csv(TABLES / "table_xray_matched_pairwise_win_v0_4_2.csv", index=False)

    audit = pd.DataFrame([{
        "known_TeV_N": len(known),
        "requested_controls_per_known": k,
        "matched_control_rows_N": len(pairs),
        "unique_controls_N": len(unique_control_indices),
        "controls_reused_N": int((reuse > 1).sum()),
        "maximum_reuse_count": int(reuse.max()),
        "median_abs_delta_S_X": float(pairs["abs_delta_S_X"].median()),
        "p95_abs_delta_S_X": float(pairs["abs_delta_S_X"].quantile(0.95)),
        "matching_replacement_rule": "nearest-neighbour matching with replacement; repeated control rows are retained in the original pair-weighted representation",
        "caliper": "none",
        "tie_rule": "pandas nsmallest index order",
    }])
    audit.to_csv(TABLES / "table_xray_matching_algorithm_audit_v0_4_2.csv", index=False)

    compact = pair_balance[[
        "feature_label", "group_a_N", "group_b_N", "group_a_median", "group_b_median",
        "standardized_mean_difference", "ks_p_two_sided",
    ]].copy()
    latex = compact.to_latex(
        index=False,
        escape=True,
        float_format=lambda x: f"{x:.3g}",
        caption=("Pair-weighted balance diagnostics for the X-ray-matched controls. Each known source "
                 "contributes five matched pairs and control reuse is allowed. Non-X-ray variables are "
                 "reported to document residual imbalance; they are not matching targets."),
        label="tab:xray_matched_balance_v042",
    )
    (DOCS / "latex_xray_matched_balance_v0_4_2.tex").write_text(latex, encoding="utf-8")

    print("v0.4.2 X-ray matched-control balance audit complete.")
    print(audit.to_string(index=False))
    print("\nPair-weighted balance:")
    print(compact.to_string(index=False))
    print("\nMatched-score metrics:")
    print(metrics.to_string(index=False))
    print("\nWithin-pair win analysis:")
    print(win_table.to_string(index=False))


if __name__ == "__main__":
    main()
