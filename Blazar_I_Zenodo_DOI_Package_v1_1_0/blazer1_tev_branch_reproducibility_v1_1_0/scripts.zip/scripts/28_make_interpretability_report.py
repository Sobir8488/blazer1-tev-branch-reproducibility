from __future__ import annotations

import sys
from pathlib import Path
sys.path.append(str(Path(__file__).resolve().parent))

import pandas as pd
import numpy as np
from _v018_helpers import TABLES, DOCS


def read_csv(name):
    p = TABLES / name
    return pd.read_csv(p) if p.exists() else pd.DataFrame()


def md_table(df: pd.DataFrame, n=20) -> str:
    if df.empty:
        return '_Missing table._'
    # Avoid requiring tabulate.
    d = df.head(n).copy()
    return d.to_string(index=False)


def main():
    comp = read_csv('table_component_contributions_compact_v0_1_8.csv')
    metrics = read_csv('table_xray_only_vs_full_score_v0_1_8.csv')
    xmatch = read_csv('table_xray_matched_validation_v0_1_8.csv')
    pca = read_csv('table_pca_branch_axis_validation_v0_1_8.csv')
    load = read_csv('table_pca_branch_axis_loadings_v0_1_8.csv')
    sim = read_csv('table_gold_nonTeV_vs_knownTeV_similarity_v0_1_8.csv')
    nn = read_csv('table_gold_nonTeV_nearest_knownTeV_distance_summary_v0_1_8.csv')

    lines = []
    lines.append('# v0.1.8 interpretability and X-ray-control report')
    lines.append('')
    lines.append('## Purpose')
    lines.append('This diagnostic layer addresses the main reviewer-level concern that the TeV-evolution score may simply rediscover X-ray-bright HSPs. It adds exact component-contribution decomposition, X-ray-only/no-X-ray comparisons, X-ray-matched controls, an unsupervised PCA TeV-branch axis, and Gold-candidate similarity tests against independently known TeV blazars.')
    lines.append('')
    lines.append('## Component-contribution summary')
    lines.append(md_table(comp[['sample','component_label','available_fraction','mean_signed_contribution','contribution_percent']] if not comp.empty else comp, n=40))
    lines.append('')
    lines.append('## X-ray-only vs full-score validation')
    key_cols = [c for c in ['score_variant','N','known_TeV_N','Gold_known_TeV_fraction','Gold_enrichment','Gold_Silver_known_TeV_fraction','Gold_Silver_enrichment','AUROC_knownTeV_vs_other'] if c in metrics.columns]
    lines.append(md_table(metrics[key_cols] if key_cols else metrics, n=20))
    lines.append('')
    lines.append('## X-ray-matched validation')
    lines.append(md_table(xmatch, n=20))
    lines.append('')
    lines.append('## PCA latent branch-axis validation')
    lines.append(md_table(pca, n=20))
    lines.append('')
    lines.append('## PCA loadings')
    if not load.empty:
        lines.append(md_table(load.sort_values('PC1_loading', key=lambda s: s.abs(), ascending=False), n=20))
    else:
        lines.append('_Missing table._')
    lines.append('')
    lines.append('## Gold non-TeV vs known-TeV similarity')
    show_cols = [c for c in ['feature_label','known_TeV_N','Gold_nonTeV_N','known_TeV_median','Gold_nonTeV_median','KS_p_two_sided','overlap_interpretation'] if c in sim.columns]
    lines.append(md_table(sim[show_cols] if show_cols else sim, n=30))
    lines.append('')
    lines.append('## Nearest-known-TeV distance summary')
    lines.append(md_table(nn, n=20))
    lines.append('')
    lines.append('## Manuscript-ready interpretation')
    lines.append('The X-ray component is allowed to be a major contributor because X-ray brightness is physically expected for HSP-like TeV blazars. However, the score should not be described as an X-ray-only selector unless the X-ray-only control performs equivalently to the full score and the no-X-ray/residual controls lose all separation. The v0.1.8 diagnostics are designed to quantify this distinction. A safe claim is that the high-score branch is X-ray anchored but multiwavelength: synchrotron-peak state, redshift/EBL transparency, gamma-ray hardness, and compact-jet proxies contribute to the same TeV-favourable locus.')

    report = '\n'.join(lines)
    (TABLES / 'interpretability_report_v0_1_8.md').write_text(report, encoding='utf-8')

    latex = r'''
\subsection{Interpretability and X-ray-control diagnostics}
A potential concern is that the score might simply rediscover X-ray-bright HSP sources. We therefore decomposed the empirical score into its signed, weight-normalized component contributions and compared the published score with X-ray-only, no-X-ray, and X-ray-residualized variants. We also constructed X-ray-matched non-TeV control samples for the known-TeV validation set. These diagnostics are not used to redefine the score; they test whether the TeV-enriched branch is reducible to a single X-ray term.

The X-ray component is expected to be important for TeV-favourable HSP-like blazars. The relevant question is whether X-ray brightness alone explains the TeVCat recovery. The v0.1.8 control layer therefore reports the AUROC, Gold recovery, Gold+Silver recovery, and matched-control separation for the full score, an X-ray-only score, and scores with the X-ray component removed or regressed out. A residual separation at fixed X-ray brightness supports a multiwavelength interpretation of the branch.

We also computed an unsupervised PCA axis from sign-aligned score components. PC1 is oriented to increase with the published score and is used only as a consistency diagnostic. If PC1 correlates with the ordered branch stage, synchrotron-peak proxy, and known-TeV labels, this indicates that the TeV-favourable branch appears as a latent axis of the multiwavelength feature space, not only as an imposed tier ranking.
'''
    (DOCS / 'latex_section_interpretability_v0_1_8.tex').write_text(latex, encoding='utf-8')

    print('Wrote tables/interpretability_report_v0_1_8.md')
    print('Wrote docs/latex_section_interpretability_v0_1_8.tex')

if __name__ == '__main__':
    main()
