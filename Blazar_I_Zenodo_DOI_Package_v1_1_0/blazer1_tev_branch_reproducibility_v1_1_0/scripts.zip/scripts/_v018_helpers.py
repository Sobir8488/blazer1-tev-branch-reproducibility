from __future__ import annotations

from pathlib import Path
import math
import numpy as np
import pandas as pd

try:
    from scipy.stats import mannwhitneyu, ks_2samp, spearmanr
except Exception:  # pragma: no cover
    mannwhitneyu = None
    ks_2samp = None
    spearmanr = None

ROOT = Path(__file__).resolve().parents[1]
TABLES = ROOT / "tables"
FIGURES = ROOT / "figures"
DOCS = ROOT / "docs"
PROCESSED = ROOT / "data" / "processed"
for p in [TABLES, FIGURES, DOCS, PROCESSED]:
    p.mkdir(parents=True, exist_ok=True)

COMPONENTS = {
    "xray_brightness": {"col": "S_X", "sign": +1, "weight": 1.00, "label": "X-ray brightness"},
    "gamma_hardness": {"col": "S_gamma_hard", "sign": +1, "weight": 1.00, "label": "Gamma hardness"},
    "gamma_variability": {"col": "S_gamma_var", "sign": +1, "weight": 0.35, "label": "Gamma variability"},
    "wise_hsp_locus": {"col": "S_IR", "sign": +1, "weight": 0.75, "label": "WISE/HSP locus"},
    "radio_compactness": {"col": "S_R", "sign": +1, "weight": 0.75, "label": "Radio compactness"},
    "synchrotron_peak_proxy": {"col": "S_nu_peak", "sign": +1, "weight": 1.00, "label": "Synchrotron peak proxy"},
    "compton_dominance_penalty": {"col": "S_CD_penalty", "sign": -1, "weight": 0.60, "label": "Compton-dominance penalty"},
    "ebl_penalty": {"col": "S_EBL_proxy", "sign": -1, "weight": 0.80, "label": "Redshift/EBL penalty"},
}


def clean_numeric(s):
    return pd.to_numeric(s, errors="coerce").replace([np.inf, -np.inf], np.nan)


def bool_series(df: pd.DataFrame, col: str) -> pd.Series:
    if col not in df.columns:
        return pd.Series(False, index=df.index)
    s = df[col]
    if s.dtype == bool:
        return s.fillna(False)
    return s.astype(str).str.strip().str.lower().isin(["true", "1", "yes", "y", "t"])


def load_score_catalogue() -> pd.DataFrame:
    candidates = [
        PROCESSED / "tev_evolution_score_catalog_v0_1_7_review_defence_augmented.csv",
        PROCESSED / "tev_evolution_score_catalog_v0_1_6_branch_augmented.csv",
        PROCESSED / "tev_evolution_score_catalog_v0_1_5_augmented.csv",
        PROCESSED / "tev_evolution_score_catalog.csv",
        PROCESSED / "tev_evolution_score_catalog_v0_1_8_interpretability_augmented.csv",
    ]
    for p in candidates:
        if p.exists():
            df = pd.read_csv(p, low_memory=False)
            df.attrs["source_path"] = str(p)
            return standardize_df(df)
    raise FileNotFoundError("No score catalogue found under data/processed.")


def standardize_df(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    for c in ["S_TeV_evo", "S_X", "S_gamma_hard", "S_gamma_var", "S_IR", "S_R", "S_nu_peak", "S_CD_penalty", "S_EBL_proxy", "log_fx", "log_nu_peak_proxy", "log_nu_peak_clean", "redshift_adopted", "redshift_adopted_clean"]:
        if c in out.columns:
            out[c] = clean_numeric(out[c])
    if "is_known_tev" not in out.columns:
        if "tevcat_matched" in out.columns:
            out["is_known_tev"] = bool_series(out, "tevcat_matched")
        elif "tevcat_name" in out.columns:
            out["is_known_tev"] = out["tevcat_name"].notna() & out["tevcat_name"].astype(str).str.len().gt(0)
        else:
            out["is_known_tev"] = False
    else:
        out["is_known_tev"] = bool_series(out, "is_known_tev")
    if "fermi_matched_clean" not in out.columns:
        out["fermi_matched_clean"] = bool_series(out, "fermi_matched") if "fermi_matched" in out.columns else False
    if "redshift_adopted_clean" not in out.columns:
        zcol = "redshift_adopted" if "redshift_adopted" in out.columns else None
        out["redshift_adopted_clean"] = clean_numeric(out[zcol]) if zcol else np.nan
    if "log_nu_peak_clean" not in out.columns:
        nu_col = "log_nu_peak_proxy" if "log_nu_peak_proxy" in out.columns else None
        out["log_nu_peak_clean"] = clean_numeric(out[nu_col]) if nu_col else np.nan
    if "tev_priority_tier" not in out.columns:
        out = assign_tiers(out, "S_TeV_evo", prefix="tev_priority")
    if "branch_stage" not in out.columns:
        if "broad_class" in out.columns:
            out["branch_stage"] = out["broad_class"].astype(str)
        else:
            out["branch_stage"] = "Unknown"
    return out


def compute_score_from_components(df: pd.DataFrame, weights=None, exclude=None, only=None, name="score") -> pd.Series:
    if weights is None:
        weights = {k: v["weight"] for k, v in COMPONENTS.items()}
    exclude = set(exclude or [])
    only = set(only or COMPONENTS.keys())
    total = pd.Series(0.0, index=df.index, dtype=float)
    available_weight = pd.Series(0.0, index=df.index, dtype=float)
    for key, meta in COMPONENTS.items():
        if key in exclude or key not in only:
            continue
        col = meta["col"]
        if col not in df.columns:
            continue
        w = float(weights.get(key, meta["weight"]))
        if w == 0:
            continue
        x = clean_numeric(df[col])
        valid = x.notna()
        total.loc[valid] += meta["sign"] * w * x.loc[valid]
        available_weight.loc[valid] += abs(w)
    return total / available_weight.replace(0, np.nan)


def assign_tiers(df: pd.DataFrame, score_col: str, prefix: str = "tmp") -> pd.DataFrame:
    out = df.copy()
    s = clean_numeric(out[score_col])
    out[f"{prefix}_tier"] = "Low-priority"
    valid = s.dropna()
    if len(valid) == 0:
        return out
    q_gold = np.nanpercentile(valid, 95)
    q_silver = np.nanpercentile(valid, 85)
    q_bronze = np.nanpercentile(valid, 70)
    out.loc[s >= q_bronze, f"{prefix}_tier"] = "Bronze"
    out.loc[s >= q_silver, f"{prefix}_tier"] = "Silver"
    out.loc[s >= q_gold, f"{prefix}_tier"] = "Gold"
    return out


def tier_mask(tier_series: pd.Series, tier_set: str) -> pd.Series:
    tier = tier_series.astype(str)
    if tier_set == "Gold":
        return tier.eq("Gold")
    if tier_set == "Gold+Silver":
        return tier.isin(["Gold", "Silver"])
    if tier_set == "Gold+Silver+Bronze":
        return tier.isin(["Gold", "Silver", "Bronze"])
    raise ValueError(tier_set)


def auroc_from_scores(y_true, scores):
    y = np.asarray(y_true).astype(bool)
    s = np.asarray(scores, dtype=float)
    mask = np.isfinite(s)
    y = y[mask]; s = s[mask]
    n_pos = int(y.sum()); n_neg = int((~y).sum())
    if n_pos == 0 or n_neg == 0:
        return np.nan, np.nan
    if mannwhitneyu is None:
        return np.nan, np.nan
    u, p = mannwhitneyu(s[y], s[~y], alternative="greater")
    return float(u / (n_pos * n_neg)), float(p)


def metrics_for_score(df: pd.DataFrame, score_col: str, tier_col: str | None = None, label: str = "score") -> dict:
    d = df.copy()
    d[score_col] = clean_numeric(d[score_col])
    d = d[d[score_col].notna()].copy()
    if tier_col is None or tier_col not in d.columns:
        d = assign_tiers(d, score_col, prefix="metric")
        tier_col = "metric_tier"
    known = d["is_known_tev"].astype(bool)
    auroc, mwp = auroc_from_scores(known.values, d[score_col].values)
    out = {"score_variant": label, "N": len(d), "known_TeV_N": int(known.sum()), "AUROC_knownTeV_vs_other": auroc, "mannwhitney_p_greater": mwp}
    for tier_set in ["Gold", "Gold+Silver", "Gold+Silver+Bronze"]:
        m = tier_mask(d[tier_col], tier_set)
        tier_size = int(m.sum())
        k = int((m & known).sum())
        total_k = int(known.sum())
        out[f"{tier_set.replace('+','_').replace(' ','_')}_size_N"] = tier_size
        out[f"{tier_set.replace('+','_').replace(' ','_')}_known_TeV_N"] = k
        out[f"{tier_set.replace('+','_').replace(' ','_')}_known_TeV_fraction"] = k / total_k if total_k else np.nan
        out[f"{tier_set.replace('+','_').replace(' ','_')}_fraction_all"] = tier_size / len(d) if len(d) else np.nan
        frac = out[f"{tier_set.replace('+','_').replace(' ','_')}_fraction_all"]
        rec = out[f"{tier_set.replace('+','_').replace(' ','_')}_known_TeV_fraction"]
        out[f"{tier_set.replace('+','_').replace(' ','_')}_enrichment"] = rec / frac if frac and np.isfinite(frac) else np.nan
    return out


def safe_spearman(x, y):
    x = clean_numeric(pd.Series(x)); y = clean_numeric(pd.Series(y))
    m = x.notna() & y.notna()
    if m.sum() < 3 or spearmanr is None:
        return np.nan, np.nan, int(m.sum())
    r, p = spearmanr(x[m], y[m])
    return float(r), float(p), int(m.sum())


def residualize(y, controls: pd.DataFrame) -> pd.Series:
    y = clean_numeric(pd.Series(y))
    X = controls.copy()
    X = X.apply(clean_numeric)
    data = pd.concat([y.rename("y"), X], axis=1).replace([np.inf, -np.inf], np.nan).dropna()
    resid = pd.Series(np.nan, index=y.index, dtype=float)
    if len(data) < max(5, X.shape[1] + 2):
        return resid
    A = np.column_stack([np.ones(len(data)), data[X.columns].values])
    coef, *_ = np.linalg.lstsq(A, data["y"].values, rcond=None)
    pred = A @ coef
    resid.loc[data.index] = data["y"].values - pred
    return resid


def bootstrap_median_diff(a, b, n=1000, seed=8488):
    rng = np.random.default_rng(seed)
    a = np.asarray(pd.Series(a).dropna(), dtype=float)
    b = np.asarray(pd.Series(b).dropna(), dtype=float)
    if len(a) < 2 or len(b) < 2:
        return np.nan, np.nan, np.nan
    diffs = []
    for _ in range(n):
        aa = rng.choice(a, size=len(a), replace=True)
        bb = rng.choice(b, size=len(b), replace=True)
        diffs.append(np.nanmedian(aa) - np.nanmedian(bb))
    return float(np.nanmedian(diffs)), float(np.nanpercentile(diffs, 16)), float(np.nanpercentile(diffs, 84))


def to_latex_table(df: pd.DataFrame, path: Path, caption: str, label: str, float_format="%.3f"):
    tex = df.to_latex(index=False, escape=False, float_format=lambda x: float_format % x if pd.notna(x) else "--")
    tex = tex.replace("\\begin{table}", "\\begin{table*}")
    tex = tex.replace("\\end{table}", "\\end{table*}")
    tex = tex.replace("\\toprule", f"\\caption{{{caption}}}\\label{{{label}}}\\\\\n\\toprule", 1)
    path.write_text(tex, encoding="utf-8")
