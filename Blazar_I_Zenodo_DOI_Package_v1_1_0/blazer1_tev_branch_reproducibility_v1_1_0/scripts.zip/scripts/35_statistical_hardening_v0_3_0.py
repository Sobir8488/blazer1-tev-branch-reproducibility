#!/usr/bin/env python
from __future__ import annotations

import os
import numpy as np
import pandas as pd

from _v030_helpers import (
    TABLES, DOCS, load_v018_catalogue, numeric, auc_rank,
    wilson_interval, jeffreys_interval, delong_pair,
    paired_stratified_bootstrap,
)


def add_recovery_intervals(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    rows = []
    for _, r in out.iterrows():
        k = int(r["known_TeV_in_tier_N"])
        n = int(r["known_TeV_N"])
        wlo, whi = wilson_interval(k, n)
        jlo, jhi = jeffreys_interval(k, n)
        rr = r.to_dict()
        rr.update({
            "recovery_wilson95_low": wlo,
            "recovery_wilson95_high": whi,
            "recovery_jeffreys95_low": jlo,
            "recovery_jeffreys95_high": jhi,
        })
        rows.append(rr)
    return pd.DataFrame(rows)


def score_variant_recovery(df: pd.DataFrame) -> pd.DataFrame:
    variants = {
        "published_full": ("S_TeV_evo", "tev_priority_tier"),
        "full_recomputed": ("S_full_recomputed_v0_1_8", "full_recomputed_tier"),
        "xray_only": ("S_xray_only_v0_1_8", "xray_only_tier"),
        "no_xray": ("S_no_xray_v0_1_8", "no_xray_tier"),
    }
    rows = []
    for name, (score_col, tier_col) in variants.items():
        if score_col not in df or tier_col not in df:
            continue
        valid = numeric(df[score_col]).notna()
        d = df.loc[valid].copy()
        y = d["is_known_tev"].astype(bool)
        for tier_set, allowed in (("Gold", {"Gold"}), ("Gold+Silver", {"Gold", "Silver"})):
            m = d[tier_col].astype(str).isin(allowed)
            k, n = int((m & y).sum()), int(y.sum())
            wlo, whi = wilson_interval(k, n)
            jlo, jhi = jeffreys_interval(k, n)
            rows.append({
                "score_variant": name, "tier_set": tier_set, "N": len(d), "known_TeV_N": n,
                "tier_N": int(m.sum()), "known_TeV_in_tier_N": k,
                "recovery_fraction": k/n if n else np.nan,
                "recovery_wilson95_low": wlo, "recovery_wilson95_high": whi,
                "recovery_jeffreys95_low": jlo, "recovery_jeffreys95_high": jhi,
                "AUROC": auc_rank(y.to_numpy(), numeric(d[score_col]).to_numpy()),
            })
    return pd.DataFrame(rows)


def main() -> None:
    df, source = load_v018_catalogue()
    required = ["S_TeV_evo", "S_full_recomputed_v0_1_8", "S_xray_only_v0_1_8", "S_no_xray_v0_1_8"]
    missing = [c for c in required if c not in df]
    if missing:
        raise KeyError(f"Missing v0.1.8 score variants: {missing}. Run scripts 23-24 first.")

    n_boot = int(os.getenv("BLAZER_V030_N_BOOT", "5000"))
    y = df["is_known_tev"].astype(bool).to_numpy()
    scores = {
        "full": numeric(df["S_full_recomputed_v0_1_8"]).to_numpy(),
        "xray_only": numeric(df["S_xray_only_v0_1_8"]).to_numpy(),
        "no_xray": numeric(df["S_no_xray_v0_1_8"]).to_numpy(),
    }
    comparisons = [("xray_only", "full"), ("full", "no_xray"), ("xray_only", "no_xray")]
    draws, boot_summary = paired_stratified_bootstrap(y, scores, comparisons, n_boot=n_boot, seed=8488)
    draws.to_csv(TABLES / "table_paired_auc_bootstrap_draws_v0_3_0.csv", index=False)
    boot_summary.to_csv(TABLES / "table_auc_bootstrap_summary_v0_3_0.csv", index=False)

    delong_rows = []
    for a, b in comparisons:
        result = delong_pair(y, scores[a], scores[b])
        result.update({"model_a": a, "model_b": b})
        delong_rows.append(result)
    delong = pd.DataFrame(delong_rows)
    delong.to_csv(TABLES / "table_auc_delong_pairwise_v0_3_0.csv", index=False)

    stress_path = TABLES / "table_selection_stress_tests_v0_1_5.csv"
    if stress_path.exists():
        stress = add_recovery_intervals(pd.read_csv(stress_path))
        stress.to_csv(TABLES / "table_selection_stress_tests_with_intervals_v0_3_0.csv", index=False)
    else:
        stress = pd.DataFrame()

    variant_rec = score_variant_recovery(df)
    variant_rec.to_csv(TABLES / "table_xray_score_variants_with_intervals_v0_3_0.csv", index=False)

    lines = [
        "# v0.3.0 statistical hardening", "",
        f"Frozen catalogue: `{source}`", f"Paired stratified bootstrap draws: {n_boot}", "",
        "## Paired bootstrap AUROC results", "", boot_summary.to_markdown(index=False), "",
        "## Correlated AUROC comparison (DeLong)", "", delong.to_markdown(index=False), "",
        "## Recovery intervals", "",
        "Wilson and Jeffreys 95% intervals were added to the full score-variant and selection-stress tables.",
    ]
    (DOCS / "statistical_hardening_report_v0_3_0.md").write_text("\n".join(lines), encoding="utf-8")

    print("v0.3.0 statistical hardening complete.")
    print(f"Frozen catalogue: {source}")
    print("\nPaired bootstrap summary:")
    print(boot_summary.to_string(index=False))
    print("\nDeLong pairwise tests:")
    print(delong[["model_a", "model_b", "auc_a", "auc_b", "delta_auc", "p_two_sided", "N", "N_pos"]].to_string(index=False))


if __name__ == "__main__":
    main()
