from __future__ import annotations

import os
import sys
from pathlib import Path
sys.path.append(str(Path(__file__).resolve().parent))

import numpy as np
import pandas as pd

from _v042_helpers import (
    ROOT, TABLES, DOCS, INTERIM, nearest_sky_match, spherical_offset,
)

RADII_ARCSEC = [60.0, 90.0, 120.0, 180.0]


def _clean_positions(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    out["ra_deg"] = pd.to_numeric(out["ra_deg"], errors="coerce")
    out["dec_deg"] = pd.to_numeric(out["dec_deg"], errors="coerce")
    return out.loc[
        out["ra_deg"].between(0, 360, inclusive="left")
        & out["dec_deg"].between(-90, 90, inclusive="both")
    ].reset_index(drop=True)


def main() -> None:
    parent_path = INTERIM / "blazer1_standardized.csv"
    tevcat_path = INTERIM / "tevcat_standardized.csv"
    if not parent_path.exists() or not tevcat_path.exists():
        raise FileNotFoundError(
            "Missing data/interim/blazer1_standardized.csv or tevcat_standardized.csv. "
            "Run the standardisation and TeVCat-fetch stages first."
        )

    parent = _clean_positions(pd.read_csv(parent_path, low_memory=False))
    tevcat = _clean_positions(pd.read_csv(tevcat_path, low_memory=False))

    n_shift = int(os.environ.get("BLAZER_V042_N_SHIFT", "1000"))
    min_offset_deg = float(os.environ.get("BLAZER_V042_SHIFT_MIN_DEG", "0.5"))
    max_offset_deg = float(os.environ.get("BLAZER_V042_SHIFT_MAX_DEG", "2.0"))
    seed = int(os.environ.get("BLAZER_V042_SEED", "8488"))
    if n_shift < 100 and os.environ.get("BLAZER_V042_SMOKE_MODE", "0") != "1":
        raise ValueError("BLAZER_V042_N_SHIFT must be at least 100 for a production audit.")
    if not (0 < min_offset_deg < max_offset_deg):
        raise ValueError("Require 0 < SHIFT_MIN_DEG < SHIFT_MAX_DEG.")

    actual_idx, actual_sep = nearest_sky_match(
        parent["ra_deg"].to_numpy(), parent["dec_deg"].to_numpy(),
        tevcat["ra_deg"].to_numpy(), tevcat["dec_deg"].to_numpy(),
    )

    rng = np.random.default_rng(seed)
    random_counts = {radius: np.empty(n_shift, dtype=int) for radius in RADII_ARCSEC}
    random_unique_right = {radius: np.empty(n_shift, dtype=int) for radius in RADII_ARCSEC}

    tev_ra = tevcat["ra_deg"].to_numpy()
    tev_dec = tevcat["dec_deg"].to_numpy()
    par_ra = parent["ra_deg"].to_numpy()
    par_dec = parent["dec_deg"].to_numpy()

    for draw in range(n_shift):
        offsets = rng.uniform(min_offset_deg, max_offset_deg, size=len(tevcat))
        bearings = rng.uniform(0.0, 2.0 * np.pi, size=len(tevcat))
        shifted_ra, shifted_dec = spherical_offset(tev_ra, tev_dec, offsets, bearings)
        idx, sep = nearest_sky_match(par_ra, par_dec, shifted_ra, shifted_dec)
        for radius in RADII_ARCSEC:
            matched = sep <= radius
            random_counts[radius][draw] = int(matched.sum())
            random_unique_right[radius][draw] = int(np.unique(idx[matched]).size)

    summary_rows = []
    draw_rows = []
    for draw in range(n_shift):
        row = {"draw": draw + 1}
        for radius in RADII_ARCSEC:
            row[f"matches_r{int(radius)}"] = int(random_counts[radius][draw])
            row[f"unique_shifted_tevcat_r{int(radius)}"] = int(random_unique_right[radius][draw])
        draw_rows.append(row)

    for radius in RADII_ARCSEC:
        actual_mask = actual_sep <= radius
        observed = int(actual_mask.sum())
        observed_unique = int(np.unique(actual_idx[actual_mask]).size)
        counts = random_counts[radius]
        empirical_p = float((1 + np.count_nonzero(counts >= observed)) / (n_shift + 1))
        q95 = float(np.quantile(counts, 0.95, method="higher"))
        q975 = float(np.quantile(counts, 0.975, method="higher"))
        q99 = float(np.quantile(counts, 0.99, method="higher"))
        summary_rows.append({
            "radius_arcsec": radius,
            "parent_N": len(parent),
            "tevcat_N": len(tevcat),
            "observed_parent_matches": observed,
            "observed_unique_tevcat_matches": observed_unique,
            "duplicate_parent_associations_N": observed - observed_unique,
            "random_draws_N": n_shift,
            "random_median_matches": float(np.median(counts)),
            "random_mean_matches": float(np.mean(counts)),
            "random_q95_matches": q95,
            "random_q97p5_matches": q975,
            "random_q99_matches": q99,
            "random_max_matches": int(np.max(counts)),
            "empirical_p_random_ge_observed": empirical_p,
            "median_expected_contamination_fraction": float(np.median(counts) / observed) if observed else np.nan,
            "q97p5_contamination_fraction": float(q975 / observed) if observed else np.nan,
            "shift_min_deg": min_offset_deg,
            "shift_max_deg": max_offset_deg,
            "seed": seed,
        })

    summary = pd.DataFrame(summary_rows)
    draws = pd.DataFrame(draw_rows)
    summary.to_csv(TABLES / "table_random_shift_crossmatch_summary_v0_4_2.csv", index=False)
    draws.to_csv(TABLES / "table_random_shift_crossmatch_draws_v0_4_2.csv", index=False)

    # Source-level actual associations at the adopted radius.
    adopted_radius = 180.0
    actual_mask = actual_sep <= adopted_radius
    parent_name_col = "SRC_NAME" if "SRC_NAME" in parent.columns else None
    tev_name_col = "name" if "name" in tevcat.columns else None
    association_rows = []
    for left_i in np.flatnonzero(actual_mask):
        right_i = int(actual_idx[left_i])
        association_rows.append({
            "parent_row": int(left_i),
            "parent_source_name": parent.loc[left_i, parent_name_col] if parent_name_col else "",
            "parent_ra_deg": float(parent.loc[left_i, "ra_deg"]),
            "parent_dec_deg": float(parent.loc[left_i, "dec_deg"]),
            "tevcat_row": right_i,
            "tevcat_name": tevcat.loc[right_i, tev_name_col] if tev_name_col else "",
            "tevcat_ra_deg": float(tevcat.loc[right_i, "ra_deg"]),
            "tevcat_dec_deg": float(tevcat.loc[right_i, "dec_deg"]),
            "separation_arcsec": float(actual_sep[left_i]),
        })
    associations = pd.DataFrame(association_rows).sort_values("separation_arcsec")
    associations.to_csv(TABLES / "table_tevcat_actual_associations_v0_4_2.csv", index=False)

    compact = summary[[
        "radius_arcsec", "observed_parent_matches", "observed_unique_tevcat_matches",
        "random_median_matches", "random_q97p5_matches", "random_max_matches",
        "q97p5_contamination_fraction", "empirical_p_random_ge_observed",
    ]].copy()
    latex = compact.to_latex(
        index=False,
        escape=True,
        float_format=lambda x: f"{x:.4g}",
        caption=("Random-position-shift audit of the TeVCat cross-match. Each TeVCat position "
                 "is displaced by a random 0.5--2.0 degree angular offset before nearest-neighbour "
                 "matching. The branch catalogue and observed coordinates are otherwise unchanged."),
        label="tab:random_shift_crossmatch_v042",
    )
    (DOCS / "latex_random_shift_crossmatch_v0_4_2.tex").write_text(latex, encoding="utf-8")

    print("v0.4.2 random-shift cross-match audit complete.")
    print(f"Random draws={n_shift}; offset range={min_offset_deg:.2f}--{max_offset_deg:.2f} deg; seed={seed}")
    print(compact.to_string(index=False))


if __name__ == "__main__":
    main()
