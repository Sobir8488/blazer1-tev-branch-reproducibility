#!/usr/bin/env python
from __future__ import annotations
import numpy as np
import pandas as pd
import matplotlib as mpl
mpl.use("Agg")
import matplotlib.pyplot as plt
from _v044_helpers import *

mpl.rcParams.update({
    "pdf.fonttype":42,"ps.fonttype":42,"font.family":"serif","font.size":9,
    "axes.labelsize":9,"xtick.labelsize":8,"ytick.labelsize":8,"legend.fontsize":8,
    "figure.dpi":150,"savefig.bbox":"tight",
})

def save(fig,name):
    fig.savefig(FIGURES/f"{name}.pdf"); fig.savefig(FIGURES/f"{name}.png",dpi=250); plt.close(fig)


def fig_auc():
    t=pd.read_csv(TABLES/"table_active_harmonized_auc_v0_4_4.csv")
    rows=t[t["quantity"].str.startswith("AUROC")].copy(); labels=rows["quantity"].str.replace("AUROC ","",regex=False).map({"active_full":"Active branch","xray_only":"X-ray only","no_xray":"No X-ray"}).fillna(rows["quantity"])
    x=np.arange(len(rows)); y=rows["estimate"].to_numpy(); lo=y-rows["ci95_low"].to_numpy(); hi=rows["ci95_high"].to_numpy()-y
    fig,ax=plt.subplots(figsize=(5.5,3.2)); ax.errorbar(x,y,yerr=[lo,hi],fmt="o",capsize=4); ax.set_xticks(x,labels); ax.set_ylabel("AUROC with 95% paired-bootstrap interval"); ax.set_ylim(.75,1.01); ax.axhline(.5,ls="--",lw=.8); save(fig,"Fig_active_harmonized_auc_v0_4_4")


def fig_validation():
    df,_=load_active_catalogue(); df=add_primary_columns(df); d=df[numeric(df["S_TeV_branch_active_v0_4_4"]).notna()].copy().sort_values("S_TeV_branch_active_v0_4_4",ascending=False); y=d["is_known_tev"].to_numpy(bool); frac=np.arange(1,len(d)+1)/len(d); rec=np.cumsum(y)/max(1,y.sum())
    fig,axs=plt.subplots(1,2,figsize=(8.8,3.3)); axs[0].plot(frac,rec,label="Known TeV recovery"); axs[0].plot([0,1],[0,1],ls="--",label="Random expectation"); axs[0].set_xlabel("Fraction of ranked catalogue inspected"); axs[0].set_ylabel("Fraction of known TeV matches recovered"); axs[0].legend()
    a=numeric(d.loc[d["is_known_tev"],"S_TeV_branch_active_v0_4_4"]); b=numeric(d.loc[~d["is_known_tev"],"S_TeV_branch_active_v0_4_4"]); axs[1].hist(b.dropna(),bins=35,density=True,alpha=.55,label="Other BlazEr1 sources"); axs[1].hist(a.dropna(),bins=14,density=True,alpha=.55,label="Known TeV matches"); axs[1].set_xlabel(r"$S_{\rm TeV,branch}$ (active)"); axs[1].set_ylabel("Density"); axs[1].legend(); save(fig,"Fig_active_TeVCat_validation_v0_4_4")


def fig_hsp():
    t=pd.read_csv(TABLES/"table_active_hsp_circularity_v0_4_4.csv"); labels=["Baseline active","No HSP flag","Continuous peak","No peak"]
    fig,axs=plt.subplots(1,2,figsize=(8.8,3.3)); x=np.arange(len(t)); w=.25
    for i,c in enumerate(["AUROC","Gold_recovery","Gold_Silver_recovery"]): axs[0].bar(x+(i-1)*w,t[c],width=w,label=c.replace("_"," "))
    axs[0].set_xticks(x,labels,rotation=20,ha="right"); axs[0].set_ylim(0,1.05); axs[0].set_ylabel("Validation metric"); axs[0].legend()
    axs[1].bar(x-.16,t["Gold_Jaccard_vs_active"],width=.32,label="Gold Jaccard"); axs[1].bar(x+.16,t["top30_nonTeV_overlap_N"]/30,width=.32,label="Top-30 overlap fraction"); axs[1].set_xticks(x,labels,rotation=20,ha="right"); axs[1].set_ylim(0,1.05); axs[1].set_ylabel("Candidate-identity stability"); axs[1].legend(); save(fig,"Fig_active_hsp_circularity_v0_4_4")


def fig_branch():
    t=pd.read_csv(TABLES/"table_active_ordered_branch_summary_v0_4_4.csv"); x=np.arange(len(t));
    fig,axs=plt.subplots(1,3,figsize=(9.2,3.2)); axs[0].bar(x,t["median_active_score"]); axs[0].set_ylabel(r"Median $S_{\rm TeV,branch}$"); axs[1].bar(x,t["median_z"]); axs[1].set_ylabel("Median redshift"); axs[2].bar(x,t["median_log_nu_peak"]); axs[2].set_ylabel(r"Median $\log\nu_{\rm peak}$ proxy")
    for ax in axs: ax.set_xticks(x,[s.replace("-like","") for s in t["branch_stage"]],rotation=25,ha="right")
    save(fig,"Fig_active_ordered_branch_v0_4_4")


def fig_contributions():
    t=pd.read_csv(TABLES/"table_active_component_contributions_v0_4_4.csv"); groups=[g for g in ["known_TeV","Gold_non_TeV","Gold_all","HSP_like"] if g in set(t["sample"])]; comps=list(ACTIVE_COMPONENTS.keys()); fig,ax=plt.subplots(figsize=(7.2,3.8)); left=np.zeros(len(groups)); y=np.arange(len(groups))
    for c in comps:
        vals=[]
        for g in groups:
            q=t[(t["sample"].eq(g))&(t["component_key"].eq(c))]["contribution_percent"]; vals.append(float(q.iloc[0]) if len(q) else 0)
        ax.barh(y,vals,left=left,label=ACTIVE_COMPONENTS[c][3]); left+=np.asarray(vals)
    ax.set_yticks(y,[g.replace("_"," ") for g in groups]); ax.set_xlabel("Fraction of total absolute contribution (%)"); ax.set_xlim(0,100); ax.legend(ncol=2,loc="upper center",bbox_to_anchor=(.5,-.18)); save(fig,"Fig_active_component_contributions_v0_4_4")


def fig_candidates():
    t=pd.read_csv(TABLES/"table_active_candidate_list_summary_v0_4_4.csv"); core=t[t["evidence_stratum"].eq("core_low_z_stable")].copy(); labels=core["followup_list"].map({"A_xray_prioritized":"List A\nX-ray-prioritized","B_HSP_branch_frontier":"List B\nHSP frontier"}); x=np.arange(len(core)); fig,ax=plt.subplots(figsize=(5.2,3.3)); ax.bar(x-.18,core["median_full_percentile"],width=.36,label="Active full percentile"); ax.bar(x+.18,core["median_xray_percentile"],width=.36,label="X-ray percentile"); ax.set_xticks(x,labels); ax.set_ylim(0,100); ax.set_ylabel("Median parent-sample percentile"); ax.legend(); save(fig,"Fig_active_followup_lists_v0_4_4")


def fig_iact():
    hist=pd.read_csv(TABLES/"table_active_iact_discovery_crossmatch_v0_4_4.csv"); obs=pd.read_csv(TABLES/"table_active_iact_observed_unique_v0_4_4.csv")
    fig,axs=plt.subplots(1,2,figsize=(8.8,3.3)); m=hist[hist["catalogue_matched"].astype(bool)].copy(); x=np.arange(len(m)); axs[0].scatter(x,m["matched_percentile_active_v0_4_4"],label="Active branch"); axs[0].scatter(x,m["matched_xray_percentile_active_v0_4_4"],marker="s",label="X-ray only"); axs[0].axhline(85,ls="--",lw=.8); axs[0].axhline(95,ls=":",lw=.8); axs[0].set_xticks(x,m["source_name"].astype(str),rotation=25,ha="right"); axs[0].set_ylabel("Frozen-catalogue percentile"); axs[0].legend()
    if len(obs):
        firm=obs["firm_detection"].astype(bool); xx=np.arange(len(obs)); axs[1].scatter(xx[firm],obs.loc[firm,"matched_S_TeV_branch_active_v0_4_4"],marker="o",label="Firm detection"); axs[1].scatter(xx[~firm],obs.loc[~firm,"matched_S_TeV_branch_active_v0_4_4"],marker="x",label="Observed non-firm"); axs[1].set_xticks(xx,obs["source_name"].astype(str),rotation=25,ha="right"); axs[1].set_ylabel(r"Active $S_{\rm TeV,branch}$"); axs[1].legend()
    save(fig,"Fig_active_iact_audits_v0_4_4")


def fig_radius():
    t=pd.read_csv(TABLES/"table_active_tevcat_radius_sensitivity_v0_4_4.csv"); fig,ax=plt.subplots(figsize=(5.3,3.3));
    for ts,g in t.groupby("tier_set"): ax.plot(g["radius_arcsec"],g["recovery_fraction"],marker="o",label=f"{ts} recovery")
    ax.set_xlabel("TeVCat match radius (arcsec)"); ax.set_ylabel("Known-TeV recovery fraction"); ax.set_ylim(0,1.05); ax.legend(); save(fig,"Fig_active_tevcat_radius_sensitivity_v0_4_4")


def fig_coverage_architecture():
    t=pd.read_csv(TABLES/"table_pattern_conditioned_validation_v0_4_3.csv"); keep=t[t["score_variant"].isin(["active_available","xray_only","no_xray"])].copy(); labels=keep["score_variant"].map({"active_available":"Active branch","xray_only":"X-ray only","no_xray":"No X-ray"}); x=np.arange(len(keep)); fig,ax=plt.subplots(figsize=(5.5,3.3)); ax.bar(x-.18,keep["unrestricted_AUROC"],width=.36,label="Unrestricted"); ax.bar(x+.18,keep["within_pattern_percentile_AUROC"],width=.36,label="Exact-pattern conditioned"); ax.set_xticks(x,labels); ax.set_ylim(.7,1); ax.set_ylabel("AUROC"); ax.legend(); save(fig,"Fig_active_coverage_conditioning_v0_4_4")


def main():
    fig_auc(); fig_validation(); fig_hsp(); fig_branch(); fig_contributions(); fig_candidates(); fig_iact(); fig_radius(); fig_coverage_architecture()
    print("Saved v0.4.4 active-score figures under figures/.")

if __name__=="__main__": main()
