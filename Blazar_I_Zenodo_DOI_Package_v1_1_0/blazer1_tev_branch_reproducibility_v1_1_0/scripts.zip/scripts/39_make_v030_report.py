#!/usr/bin/env python
from __future__ import annotations

import pandas as pd
from _v030_helpers import TABLES, DOCS


def fmt(x, digits=3):
    return "--" if pd.isna(x) else f"{x:.{digits}f}"


def main() -> None:
    boot = pd.read_csv(TABLES / "table_auc_bootstrap_summary_v0_3_0.csv")
    de = pd.read_csv(TABLES / "table_auc_delong_pairwise_v0_3_0.csv")
    hsp = pd.read_csv(TABLES / "table_hsp_circularity_sensitivity_summary_v0_3_0.csv")
    dual = pd.read_csv(TABLES / "table_dual_followup_list_summary_v0_3_0.csv")

    bmap = {r["quantity"]: r for _, r in boot.iterrows()}
    dx = de[(de.model_a == "xray_only") & (de.model_b == "full")].iloc[0]
    full = hsp[hsp.score_variant == "baseline_full"].iloc[0]
    cont = hsp[hsp.score_variant == "continuous_peak_only"].iloc[0]

    tex = rf"""\subsection{{Formal uncertainty and HSP-circularity audits}}
\label{{sec:formal_uncertainty_hsp_audit}}

We quantified uncertainty in the known-TeV recovery statistics using a paired, class-stratified bootstrap and a correlated DeLong comparison. The full branch score has AUROC={fmt(bmap['AUROC full']['estimate'])} with a 95 per cent bootstrap interval of {fmt(bmap['AUROC full']['ci95_low'])}--{fmt(bmap['AUROC full']['ci95_high'])}, whereas the X-ray-only diagnostic has AUROC={fmt(bmap['AUROC xray_only']['estimate'])} ({fmt(bmap['AUROC xray_only']['ci95_low'])}--{fmt(bmap['AUROC xray_only']['ci95_high'])}). The paired difference, $\Delta\mathrm{{AUROC}}_{{X-full}}={fmt(dx['delta_auc'])}$, has DeLong $p={dx['p_two_sided']:.3g}$. These intervals explicitly account for the limited 34-source positive validation sample and replace interpretation based on point estimates alone.

To test whether the branch is manufactured by imported HSP catalogue flags, we recomputed the score using only continuous synchrotron-peak information from 4LAC peak frequency and $\alpha_{{RX}}$. The continuous-only variant has AUROC={fmt(cont['AUROC'])}, Gold recovery={fmt(cont['Gold_recovery'])}, and Gold+Silver recovery={fmt(cont['Gold_Silver_recovery'])}; the corresponding baseline values are {fmt(full['AUROC'])}, {fmt(full['Gold_recovery'])}, and {fmt(full['Gold_Silver_recovery'])}. Its Gold-tier Jaccard overlap with the baseline is {fmt(cont['Gold_Jaccard_vs_baseline'])}. This audit distinguishes genuine continuous peak/X-ray structure from categorical HSP-label inheritance.

\subsection{{Component-asymmetric follow-up products}}
\label{{sec:dual_followup_products}}

The known-TeV and Gold populations weight the physical branch differently, so we release two non-probabilistic follow-up lists. List~A contains {int(dual.iloc[0]['N'])} non-TeV sources that are Gold or Silver in the full branch score and Gold in the X-ray-only ranking; it is the conservative X-ray-confirmed list. List~B contains {int(dual.iloc[1]['N'])} non-TeV Gold sources that do not enter the X-ray-only Gold tier; it isolates the high-peak branch frontier. The split operationalizes the component asymmetry without claiming that either list represents a calibrated TeV-detection probability.
"""
    (DOCS / "latex_section_new_direction_v0_3_0.tex").write_text(tex, encoding="utf-8")

    report = [
        "# v0.3.0 new-direction result synthesis", "",
        "## Formal AUROC uncertainty", "", boot.to_markdown(index=False), "",
        "## DeLong pairwise tests", "", de.to_markdown(index=False), "",
        "## HSP circularity", "", hsp.to_markdown(index=False), "",
        "## Dual follow-up lists", "", dual.to_markdown(index=False), "",
        "A manuscript-ready LaTeX section was written to `docs/latex_section_new_direction_v0_3_0.tex`.",
    ]
    (DOCS / "new_direction_results_report_v0_3_0.md").write_text("\n".join(report), encoding="utf-8")
    print("Wrote v0.3.0 result synthesis and LaTeX snippet.")


if __name__ == "__main__":
    main()
