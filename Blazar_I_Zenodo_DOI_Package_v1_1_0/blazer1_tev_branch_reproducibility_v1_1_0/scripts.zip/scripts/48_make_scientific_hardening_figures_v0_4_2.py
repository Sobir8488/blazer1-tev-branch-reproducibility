from __future__ import annotations

import sys
from pathlib import Path
sys.path.append(str(Path(__file__).resolve().parent))

import numpy as np
import pandas as pd
import matplotlib as mpl
import matplotlib.pyplot as plt

from _v042_helpers import TABLES, FIGURES, load_frozen_catalogue

mpl.rcParams["pdf.fonttype"] = 42
mpl.rcParams["ps.fonttype"] = 42
mpl.rcParams["font.family"] = "serif"
mpl.rcParams["font.size"] = 9


def save(fig, stem: str) -> None:
    fig.tight_layout()
    fig.savefig(FIGURES / f"{stem}.pdf", bbox_inches="tight")
    fig.savefig(FIGURES / f"{stem}.png", dpi=220, bbox_inches="tight")
    plt.close(fig)


def random_shift_figure() -> None:
    draws = pd.read_csv(TABLES / "table_random_shift_crossmatch_draws_v0_4_2.csv")
    summary = pd.read_csv(TABLES / "table_random_shift_crossmatch_summary_v0_4_2.csv")
    radii = summary["radius_arcsec"].astype(int).tolist()
    data = [draws[f"matches_r{r}"].to_numpy() for r in radii]
    observed = summary["observed_parent_matches"].to_numpy()

    fig, ax = plt.subplots(figsize=(5.2, 3.3))
    ax.boxplot(data, tick_labels=[str(r) for r in radii], showfliers=True)
    ax.scatter(np.arange(1, len(radii) + 1), observed, marker="D", label="Observed")
    ax.set_xlabel("TeVCat match radius (arcsec)")
    ax.set_ylabel("Number of BlazEr1 matches")
    ax.set_title("Random-position-shift cross-match audit")
    ax.legend(frameon=False)
    save(fig, "Fig_random_shift_crossmatch_audit_v0_4_2")


def coverage_distribution_figure() -> None:
    df = load_frozen_catalogue()
    comp_cols = ["S_X", "S_gamma_hard", "S_gamma_var", "S_IR", "S_R", "S_nu_peak", "S_CD_penalty", "S_EBL_proxy"]
    ncomp = df[comp_cols].notna().sum(axis=1)
    known = df["is_known_tev"].astype(bool)
    bins = np.arange(0.5, 9.5, 1.0)

    fig, ax = plt.subplots(figsize=(5.2, 3.3))
    ax.hist(ncomp[~known], bins=bins, density=True, histtype="step", linewidth=1.5, label="Non-TeV parent")
    ax.hist(ncomp[known], bins=bins, density=True, histtype="step", linewidth=1.5, label="Known TeV")
    ax.set_xticks(range(1, 9))
    ax.set_xlabel("Available score components")
    ax.set_ylabel("Normalized source fraction")
    ax.set_title("Multiwavelength coverage and TeVCat membership")
    ax.legend(frameon=False)
    save(fig, "Fig_component_coverage_distribution_v0_4_2")


def coverage_sensitivity_figure() -> None:
    tab = pd.read_csv(TABLES / "table_minimum_component_sensitivity_v0_4_2.csv")
    fig, ax = plt.subplots(figsize=(5.2, 3.3))
    labels = {"full": "Full branch", "xray_only": "X-ray only", "no_xray": "No X-ray"}
    for variant in ["full", "xray_only", "no_xray"]:
        g = tab[tab["score_variant"] == variant].sort_values("minimum_components_required")
        ax.plot(g["minimum_components_required"], g["AUROC"], marker="o", label=labels[variant])
    ax.set_xticks(range(1, 9))
    ax.set_ylim(0.75, 1.0)
    ax.set_xlabel("Minimum available components required")
    ax.set_ylabel("Known-TeV AUROC")
    ax.set_title("Score performance under coverage restrictions")
    ax.legend(frameon=False)
    save(fig, "Fig_component_coverage_sensitivity_v0_4_2")


def matched_balance_figure() -> None:
    tab = pd.read_csv(TABLES / "table_xray_matched_balance_v0_4_2.csv")
    tab = tab.dropna(subset=["standardized_mean_difference"]).copy()
    tab = tab.sort_values("standardized_mean_difference")
    fig, ax = plt.subplots(figsize=(5.2, 3.7))
    y = np.arange(len(tab))
    ax.barh(y, tab["standardized_mean_difference"])
    ax.axvline(0.0, linewidth=0.8)
    ax.axvline(-0.1, linestyle="--", linewidth=0.8)
    ax.axvline(0.1, linestyle="--", linewidth=0.8)
    ax.set_yticks(y, tab["feature_label"])
    ax.set_xlabel("Standardized mean difference (known TeV minus control)")
    ax.set_title("Balance after matching only on X-ray brightness")
    save(fig, "Fig_xray_matched_control_balance_v0_4_2")


def main() -> None:
    required = [
        TABLES / "table_random_shift_crossmatch_draws_v0_4_2.csv",
        TABLES / "table_random_shift_crossmatch_summary_v0_4_2.csv",
        TABLES / "table_minimum_component_sensitivity_v0_4_2.csv",
        TABLES / "table_xray_matched_balance_v0_4_2.csv",
    ]
    missing = [str(p) for p in required if not p.exists()]
    if missing:
        raise FileNotFoundError("Run scripts 44--47 first. Missing: " + ", ".join(missing))
    random_shift_figure()
    coverage_distribution_figure()
    coverage_sensitivity_figure()
    matched_balance_figure()
    print("Saved v0.4.2 scientific-hardening figures under figures/.")


if __name__ == "__main__":
    main()
