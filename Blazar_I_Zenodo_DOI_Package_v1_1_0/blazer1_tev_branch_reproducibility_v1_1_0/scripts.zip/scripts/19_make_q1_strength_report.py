#!/usr/bin/env python
"""Create a compact v0.1.6 Q1-strength report and manuscript snippets."""
from __future__ import annotations
from pathlib import Path
import pandas as pd

TABLES = Path('tables')
DOCS = Path('docs')
DOCS.mkdir(exist_ok=True, parents=True)

FILES = {
    'ordered_branch': TABLES / 'table_ordered_branch_stage_summary_v0_1_6.csv',
    'trend_tests': TABLES / 'table_ordered_branch_trend_tests_v0_1_6.csv',
    'partial': TABLES / 'table_partial_correlation_score_nupeak_control_z_v0_1_6.csv',
    'redshift_bins': TABLES / 'table_redshift_bin_evolutionary_branch_v0_1_6.csv',
    'leakage': TABLES / 'table_no_leakage_score_component_audit_v0_1_6.csv',
    'weight_summary': TABLES / 'table_weight_sensitivity_random_summary_v0_1_6.csv',
    'weight_loo': TABLES / 'table_weight_sensitivity_leave_one_out_v0_1_6.csv',
}


def read(name):
    p = FILES[name]
    if not p.exists():
        return pd.DataFrame()
    return pd.read_csv(p)


def markdown_table(df, max_rows=None):
    if df.empty:
        return '_Not available._'
    if max_rows is not None:
        df = df.head(max_rows)
    try:
        return df.to_markdown(index=False)
    except Exception:
        return df.to_string(index=False)


def main():
    branch = read('ordered_branch')
    trend = read('trend_tests')
    partial = read('partial')
    zb = read('redshift_bins')
    leak = read('leakage')
    ws = read('weight_summary')
    loo = read('weight_loo')

    lines = []
    lines.append('# v0.1.6 Q1-strength diagnostics report')
    lines.append('')
    lines.append('## Ordered TeV-favourable branch')
    lines.append(markdown_table(branch))
    lines.append('')
    lines.append('## Ordered trend tests')
    lines.append(markdown_table(trend))
    lines.append('')
    lines.append('## Partial correlation: score versus log nu_peak controlling for redshift')
    lines.append(markdown_table(partial))
    lines.append('')
    lines.append('## Redshift-bin branch table')
    lines.append(markdown_table(zb))
    lines.append('')
    lines.append('## No-leakage audit')
    lines.append(markdown_table(leak))
    lines.append('')
    lines.append('## Random ±30% score-weight sensitivity')
    lines.append(markdown_table(ws))
    lines.append('')
    lines.append('## Leave-one-component-out sensitivity')
    keep = [c for c in ['scenario','gold_known_TeV_fraction','gold_silver_known_TeV_fraction','AUROC_knownTeV_vs_other','spearman_vs_baseline_score','gold_overlap_with_baseline_fraction'] if c in loo.columns]
    lines.append(markdown_table(loo[keep] if keep else loo))
    lines.append('')
    lines.append('## Interpretation')
    lines.append('These tests are designed to move the paper from a candidate ranking to a physical-branch analysis. They should be interpreted as evidence that the score identifies a low-redshift, HSP-like, BL Lac-dominated TeV-favourable population branch. They do not prove one-to-one temporal evolution of individual blazars.')
    (TABLES / 'q1_strength_report_v0_1_6.md').write_text('\n'.join(lines), encoding='utf-8')

    # LaTeX text block suitable for Results/Discussion.
    latex = r'''
\subsection{Physical-branch tests}
The validated TeV-evolution score can be interpreted as more than an empirical
follow-up ranking if it traces a coherent population branch. We therefore
introduced an ordered branch proxy, FSRQ/QSO-like $\rightarrow$ BCU/uncertain
$\rightarrow$ BL Lac-like $\rightarrow$ HSP-like, and tested whether
$S_{\rm TeV,evo}$ increases along this sequence. We also measured the partial
rank correlation between $S_{\rm TeV,evo}$ and the synchrotron-peak proxy after
controlling for redshift, constructed redshift-bin summaries of the median
score and high-priority fractions, and repeated the TeVCat recovery analysis
under $\pm 30$ per cent random perturbations of the score weights. Finally, a
no-leakage audit verified that the score components do not use TeVCat membership
or Fermi TeV-association flags. These tests support a population-level
low-redshift, HSP-like TeV-favourable branch, while avoiding the stronger and
unsupported claim that individual FSRQs are observed to evolve directly into
TeV HSP BL Lacs.
'''.strip()
    (DOCS / 'latex_section_physical_branch_tests_v0_1_6.tex').write_text(latex, encoding='utf-8')
    print('Wrote tables/q1_strength_report_v0_1_6.md')
    print('Wrote docs/latex_section_physical_branch_tests_v0_1_6.tex')


if __name__ == '__main__':
    main()
