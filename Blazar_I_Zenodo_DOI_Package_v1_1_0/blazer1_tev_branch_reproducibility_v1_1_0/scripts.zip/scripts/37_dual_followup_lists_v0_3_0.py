#!/usr/bin/env python
from __future__ import annotations

import numpy as np
import pandas as pd

from _v030_helpers import TABLES, DOCS, load_v018_catalogue, numeric, percentile_rank, source_name


def first_existing(df: pd.DataFrame, candidates: list[str], default=np.nan) -> pd.Series:
    for c in candidates:
        if c in df.columns:
            return df[c]
    return pd.Series(default, index=df.index)


def main() -> None:
    df, source = load_v018_catalogue()
    required = ["S_TeV_evo", "tev_priority_tier", "S_xray_only_v0_1_8", "xray_only_tier"]
    missing = [c for c in required if c not in df]
    if missing:
        raise KeyError(f"Missing columns {missing}; run v0.1.8 X-ray controls first.")

    df = df.copy()
    df["source_name_clean"] = source_name(df)
    df["full_percentile_v0_3_0"] = percentile_rank(df["S_TeV_evo"])
    df["xray_percentile_v0_3_0"] = percentile_rank(df["S_xray_only_v0_1_8"])
    df["peak_percentile_v0_3_0"] = percentile_rank(df["S_nu_peak"])
    nontev = ~df["is_known_tev"].astype(bool)

    # List A: conservative, historically TeV-like observability gate.
    mask_a = nontev & df["tev_priority_tier"].isin(["Gold", "Silver"]) & df["xray_only_tier"].eq("Gold")
    # List B: branch-frontier objects selected by the full physical branch but not by the strict X-ray-only top tier.
    mask_b = nontev & df["tev_priority_tier"].eq("Gold") & ~df["xray_only_tier"].eq("Gold")

    base_cols = {
        "source_name": df["source_name_clean"],
        "ra_deg": numeric(first_existing(df, ["ra_deg", "RA", "RAJ2000"])),
        "dec_deg": numeric(first_existing(df, ["dec_deg", "DEC", "DEJ2000"])),
        "branch_stage": first_existing(df, ["branch_stage", "broad_class"], default="Unknown"),
        "redshift": numeric(first_existing(df, ["redshift_adopted_clean", "redshift_adopted"])),
        "log_nu_peak_proxy": numeric(first_existing(df, ["log_nu_peak_clean", "log_nu_peak_proxy"])),
        "peak_proxy_method": first_existing(df, ["log_nu_peak_proxy_method"], default="missing"),
        "S_TeV_branch": numeric(df["S_TeV_evo"]),
        "full_tier": df["tev_priority_tier"],
        "full_percentile": df["full_percentile_v0_3_0"],
        "S_X": numeric(df["S_X"]),
        "xray_only_score": numeric(df["S_xray_only_v0_1_8"]),
        "xray_only_tier": df["xray_only_tier"],
        "xray_percentile": df["xray_percentile_v0_3_0"],
        "peak_percentile": df["peak_percentile_v0_3_0"],
        "nearest_known_TeV_distance": numeric(first_existing(df, ["nearest_known_TeV_distance_v0_1_8", "nearest_known_TeV_distance"])),
    }
    base = pd.DataFrame(base_cols, index=df.index)

    list_a = base.loc[mask_a].copy()
    list_a["followup_list"] = "A_xray_confirmed_high_confidence"
    list_a["priority_index"] = 0.55*list_a["xray_percentile"] + 0.35*list_a["full_percentile"] + 0.10*list_a["peak_percentile"].fillna(50)
    list_a = list_a.sort_values(["priority_index", "S_X"], ascending=False)

    list_b = base.loc[mask_b].copy()
    list_b["followup_list"] = "B_HSP_branch_frontier"
    list_b["priority_index"] = 0.60*list_b["full_percentile"] + 0.30*list_b["peak_percentile"].fillna(50) + 0.10*(100-list_b["xray_percentile"])
    list_b = list_b.sort_values(["priority_index", "S_TeV_branch"], ascending=False)

    list_a.to_csv(TABLES / "candidate_list_A_xray_confirmed_high_confidence_v0_3_0.csv", index=False)
    list_b.to_csv(TABLES / "candidate_list_B_hsp_branch_frontier_v0_3_0.csv", index=False)
    list_a.head(30).to_csv(TABLES / "candidate_list_A_top30_v0_3_0.csv", index=False)
    list_b.head(30).to_csv(TABLES / "candidate_list_B_top30_v0_3_0.csv", index=False)

    summary_rows = []
    for label, d in (("A_xray_confirmed_high_confidence", list_a), ("B_HSP_branch_frontier", list_b)):
        summary_rows.append({
            "followup_list": label, "N": len(d),
            "median_full_percentile": d["full_percentile"].median(),
            "median_xray_percentile": d["xray_percentile"].median(),
            "median_redshift": d["redshift"].median(),
            "median_log_nu_peak": d["log_nu_peak_proxy"].median(),
            "median_S_X": d["S_X"].median(),
        })
    summary = pd.DataFrame(summary_rows)
    summary.to_csv(TABLES / "table_dual_followup_list_summary_v0_3_0.csv", index=False)

    lines = [
        "# v0.3.0 dual follow-up lists", "", f"Frozen catalogue: `{source}`", "",
        "**List A** requires Gold/Silver membership in the full branch score and Gold membership in the X-ray-only ranking. It is the conservative X-ray-confirmed list.", "",
        "**List B** requires Gold membership in the full branch score but excludes X-ray-only Gold objects. It isolates the high-peak branch frontier responsible for the known-TeV/Gold component asymmetry.", "",
        "## Summary", "", summary.to_markdown(index=False), "",
        "The priority indices only order objects within each pre-defined list. They are not probabilities.",
    ]
    (DOCS / "dual_followup_lists_report_v0_3_0.md").write_text("\n".join(lines), encoding="utf-8")

    print("v0.3.0 dual follow-up candidate lists complete.")
    print(f"Frozen catalogue: {source}")
    print(summary.to_string(index=False))
    print("\nTop 10 List A:")
    print(list_a.head(10)[["source_name", "full_tier", "full_percentile", "xray_percentile", "redshift", "log_nu_peak_proxy", "priority_index"]].to_string(index=False))
    print("\nTop 10 List B:")
    print(list_b.head(10)[["source_name", "full_tier", "full_percentile", "xray_percentile", "redshift", "log_nu_peak_proxy", "priority_index"]].to_string(index=False))


if __name__ == "__main__":
    main()
