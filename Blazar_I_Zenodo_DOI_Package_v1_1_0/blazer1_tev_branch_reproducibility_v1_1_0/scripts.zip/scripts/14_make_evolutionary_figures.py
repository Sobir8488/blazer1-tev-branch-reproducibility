#!/usr/bin/env python
"""Make v0.1.5 evolutionary-diagnostics figures for the BlazEr1 TeV-evolution project."""
from __future__ import annotations

from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

ROOT = Path('.')
AUG_PATH = ROOT / 'data' / 'processed' / 'tev_evolution_score_catalog_v0_1_5_augmented.csv'
STRESS_PATH = ROOT / 'tables' / 'table_selection_stress_tests_v0_1_5.csv'
ZBIN_PATH = ROOT / 'tables' / 'table_redshift_bin_gold_fraction_v0_1_5.csv'
FIG_DIR = ROOT / 'figures'
FIG_DIR.mkdir(parents=True, exist_ok=True)


def clean_scalar(x):
    if pd.isna(x):
        return ''
    s = str(x).strip()
    if s.startswith("b'") and s.endswith("'"):
        s = s[2:-1]
    if s.lower() in {'', '-', 'nan', 'none', 'null', '<na>'}:
        return ''
    return s


def savefig(name: str):
    for ext in ['png', 'pdf']:
        plt.savefig(FIG_DIR / f'{name}.{ext}', bbox_inches='tight', dpi=220)
    plt.close()


def load_augmented() -> pd.DataFrame:
    if not AUG_PATH.exists():
        raise SystemExit('Missing augmented catalogue. Run scripts/13_evolutionary_diagnostics.py first.')
    df = pd.read_csv(AUG_PATH, low_memory=False)
    df['S_TeV_evo'] = pd.to_numeric(df['S_TeV_evo'], errors='coerce')
    df['redshift_adopted_clean'] = pd.to_numeric(df.get('redshift_adopted_clean'), errors='coerce')
    df['log_nu_peak_proxy'] = pd.to_numeric(df.get('log_nu_peak_proxy'), errors='coerce')
    df['is_known_tev'] = df.get('is_known_tev', False).astype(str).str.lower().isin(['true', '1'])
    return df


def fig_class_score_distribution(df: pd.DataFrame) -> None:
    order = ['BL Lac-like', 'FSRQ/QSO-like', 'BCU/uncertain', 'Other/uncertain']
    data = [df.loc[df['broad_class'] == c, 'S_TeV_evo'].dropna().values for c in order]
    labels = [f'{c}\nN={len(v)}' for c, v in zip(order, data)]
    plt.figure(figsize=(8.8, 5.2))
    # Matplotlib compatibility: some versions accept tick_labels, older ones accept labels,
    # and a few distro builds reject labels entirely. Set tick labels manually as fallback.
    try:
        plt.boxplot(data, tick_labels=labels, showfliers=False)
    except TypeError:
        try:
            plt.boxplot(data, labels=labels, showfliers=False)
        except TypeError:
            plt.boxplot(data, showfliers=False)
            plt.xticks(range(1, len(labels) + 1), labels)
    known = df[df['is_known_tev']]
    for i, c in enumerate(order, start=1):
        y = known.loc[known['broad_class'] == c, 'S_TeV_evo'].dropna().values
        if len(y):
            x = np.full(len(y), i, dtype=float) + np.linspace(-0.12, 0.12, len(y))
            plt.scatter(x, y, marker='x', s=36, label='Known TeV' if i == 1 else None)
    plt.ylabel(r'$S_{\rm TeV,evo}$')
    plt.xlabel('Broad blazar class proxy')
    plt.title('TeV-evolution score by class')
    if len(known):
        plt.legend(frameon=False)
    savefig('Fig_class_score_distribution_v0_1_5')


def fig_redshift_score_evolution(df: pd.DataFrame) -> None:
    d = df[df['redshift_adopted_clean'].notna() & df['S_TeV_evo'].notna()].copy()
    d = d[(d['redshift_adopted_clean'] >= 0) & (d['redshift_adopted_clean'] < 4)]
    if len(d) == 0:
        return
    plt.figure(figsize=(8.2, 5.2))
    non = d[~d['is_known_tev']]
    known = d[d['is_known_tev']]
    plt.scatter(non['redshift_adopted_clean'], non['S_TeV_evo'], s=8, alpha=0.25, label='Other BlazEr1 sources')
    if len(known):
        plt.scatter(known['redshift_adopted_clean'], known['S_TeV_evo'], s=44, marker='x', label='Known TeV matches')
    bins = np.array([0.0, 0.1, 0.3, 0.5, 1.0, 2.0, 4.0])
    mids, med = [], []
    for lo, hi in zip(bins[:-1], bins[1:]):
        g = d[(d['redshift_adopted_clean'] >= lo) & (d['redshift_adopted_clean'] < hi)]
        if len(g) >= 20:
            mids.append((lo + hi) / 2)
            med.append(g['S_TeV_evo'].median())
    if mids:
        plt.plot(mids, med, marker='o', label='Median score by redshift bin')
    plt.xlabel('Adopted redshift')
    plt.ylabel(r'$S_{\rm TeV,evo}$')
    plt.title('Redshift dependence of TeV-evolution score')
    plt.legend(frameon=False)
    savefig('Fig_redshift_score_evolution_v0_1_5')


def fig_hsp_tev_branch(df: pd.DataFrame) -> None:
    d = df[df['log_nu_peak_proxy'].notna() & df['redshift_adopted_clean'].notna()].copy()
    d = d[(d['redshift_adopted_clean'] >= 0) & (d['redshift_adopted_clean'] < 3.5)]
    if len(d) == 0:
        return
    plt.figure(figsize=(8.2, 5.2))
    non = d[~d['is_known_tev']]
    known = d[d['is_known_tev']]
    plt.scatter(non['redshift_adopted_clean'], non['log_nu_peak_proxy'], s=8, alpha=0.25, label='Other BlazEr1 sources')
    if len(known):
        plt.scatter(known['redshift_adopted_clean'], known['log_nu_peak_proxy'], s=44, marker='x', label='Known TeV matches')
    plt.axhline(15.0, linestyle='--', linewidth=1, label='HSP proxy threshold')
    plt.xlabel('Adopted redshift')
    plt.ylabel(r'$\log_{10}\nu_{\rm peak}$ proxy')
    plt.title('HSP-like low-redshift branch and known TeV matches')
    plt.legend(frameon=False)
    savefig('Fig_HSP_TeV_branch_v0_1_5')


def fig_redshift_bin_gold_fraction() -> None:
    if not ZBIN_PATH.exists():
        return
    zbin = pd.read_csv(ZBIN_PATH)
    d = zbin[zbin['class'] == 'All'].copy()
    if len(d) == 0:
        return
    x = np.arange(len(d))
    plt.figure(figsize=(8.2, 5.2))
    plt.plot(x, d['gold_fraction'], marker='o', label='Gold fraction')
    plt.plot(x, d['gold_plus_silver_fraction'], marker='s', label='Gold+Silver fraction')
    plt.plot(x, d['hsp_like_fraction'], marker='^', label='HSP-like fraction')
    plt.xticks(x, d['z_bin'], rotation=35, ha='right')
    plt.ylabel('Fraction')
    plt.xlabel('Adopted redshift bin')
    plt.title('Priority-tier and HSP-like fractions by redshift')
    plt.legend(frameon=False)
    savefig('Fig_redshift_bin_gold_fraction_v0_1_5')


def fig_selection_bias_stress_tests() -> None:
    if not STRESS_PATH.exists():
        return
    stress = pd.read_csv(STRESS_PATH)
    d = stress[stress['tier_set'].isin(['Gold', 'Gold+Silver'])].copy()
    # Keep the most manuscript-relevant stress tests.
    keep = [
        'full_sample', 'fermi_matched_only', 'redshift_available', 'secure_redshift_only',
        'spectroscopic_redshift_only', 'BL_Lac_like_only', 'FSRQ_QSO_like_only', 'HSP_like_only',
        'z_lt_0p5', 'z_lt_1p0', 'xray_bright_upper_half'
    ]
    d = d[d['stress_sample'].isin(keep)]
    if len(d) == 0:
        return
    pivot = d.pivot(index='stress_sample', columns='tier_set', values='enrichment_vs_random').reindex(keep)
    pivot = pivot.dropna(how='all')
    x = np.arange(len(pivot))
    width = 0.38
    plt.figure(figsize=(10.5, 5.6))
    if 'Gold' in pivot:
        plt.bar(x - width/2, pivot['Gold'], width, label='Gold')
    if 'Gold+Silver' in pivot:
        plt.bar(x + width/2, pivot['Gold+Silver'], width, label='Gold+Silver')
    plt.axhline(1.0, linestyle='--', linewidth=1)
    plt.xticks(x, pivot.index, rotation=40, ha='right')
    plt.ylabel('Known-TeV enrichment vs random')
    plt.xlabel('Selection/stress-test sample')
    plt.title('Known-TeV enrichment under selection stress tests')
    plt.legend(frameon=False)
    savefig('Fig_selection_bias_stress_tests_v0_1_5')


def main() -> None:
    df = load_augmented()
    fig_class_score_distribution(df)
    fig_redshift_score_evolution(df)
    fig_hsp_tev_branch(df)
    fig_redshift_bin_gold_fraction()
    fig_selection_bias_stress_tests()
    print('Saved evolutionary-diagnostics figures:')
    for p in sorted(FIG_DIR.glob('Fig_*_v0_1_5.pdf')):
        print(p.as_posix())


if __name__ == '__main__':
    main()
