#!/usr/bin/env python
from __future__ import annotations

import argparse
import json
from pathlib import Path
from urllib.parse import urljoin

import requests
import yaml
from bs4 import BeautifulSoup


def download(url: str, out: Path, timeout: int = 120) -> bool:
    out.parent.mkdir(parents=True, exist_ok=True)
    r = requests.get(url, timeout=timeout)
    if r.status_code != 200 or len(r.content) < 100:
        print(f"[WARN] Failed or tiny download: {url} status={r.status_code}")
        return False
    out.write_bytes(r.content)
    print(f"[OK] {url} -> {out} ({out.stat().st_size} bytes)")
    return True


def scrape_fits_links(page_url: str) -> list[str]:
    html = requests.get(page_url, timeout=60).text
    soup = BeautifulSoup(html, "html.parser")
    links = []
    for a in soup.find_all("a"):
        href = a.get("href") or ""
        if any(href.lower().endswith(ext) for ext in [".fits", ".fit", ".fits.gz", ".fit.gz"]):
            links.append(urljoin(page_url, href))
    return sorted(set(links))


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--config", default="configs/config.yaml")
    p.add_argument("--manifest", default="metadata/DATA_MANIFEST.yaml")
    p.add_argument("--download-fermi", action="store_true", help="Try to download Fermi FITS files from official pages.")
    p.add_argument("--download-blazer1", action="store_true", help="Try to download BlazEr1 FITS/CSV/VOT from eROSITA page.")
    args = p.parse_args()

    manifest = yaml.safe_load(Path(args.manifest).read_text())
    log = {"attempted": [], "manual_required": []}

    for key, item in manifest["catalogues"].items():
        page = item.get("official_page")
        expected = Path(item.get("expected_local_path", ""))
        mode = item.get("access_mode", "")
        if not page:
            log["manual_required"].append({"catalogue": key, "reason": "no official_page in manifest"})
            continue

        should_auto = False
        if key.startswith("fermi") and args.download_fermi:
            should_auto = True
        if key == "blazer1" and args.download_blazer1:
            should_auto = True

        if not should_auto:
            log["manual_required"].append({"catalogue": key, "official_page": page, "expected_path": str(expected), "mode": mode})
            continue

        try:
            links = scrape_fits_links(page)
        except Exception as exc:
            log["attempted"].append({"catalogue": key, "official_page": page, "error": repr(exc)})
            continue

        chosen = None
        lower_key = key.lower()
        for link in links:
            ll = link.lower()
            if "4fgl" in lower_key and ("psc" in ll or "4fgl" in ll):
                chosen = link
                break
            if "4lac" in lower_key and "4lac" in ll:
                if "high" in lower_key and ("-h" in ll or "high" in ll):
                    chosen = link
                    break
                if "low" in lower_key and ("-l" in ll or "low" in ll):
                    chosen = link
                    break
            if key == "blazer1" and "blazer" in ll:
                chosen = link
                break
        if chosen is None and links:
            chosen = links[0]
        if chosen:
            ok = download(chosen, expected)
            log["attempted"].append({"catalogue": key, "url": chosen, "expected_path": str(expected), "ok": ok})
        else:
            log["manual_required"].append({"catalogue": key, "official_page": page, "reason": "no FITS link scraped"})

    Path("metadata/fetch_log.json").write_text(json.dumps(log, indent=2))
    print("Wrote metadata/fetch_log.json")


if __name__ == "__main__":
    main()
