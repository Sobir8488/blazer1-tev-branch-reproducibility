#!/usr/bin/env python
"""
Create compact manuscript-ready validation and candidate tables.

Outputs
-------
tables/table_validation_summary_paper_v0_1_4.csv/.tex
tables/table_known_tev_recovery_paper_v0_1_4.csv/.tex
tables/table_top_gold_non_tev_candidates_v0_1_4.csv/.tex
"""
from __future__ import annotations

from pathlib import Path
import numpy as np
import pandas as pd


def as_bool_series(s: pd.Series) -> pd.Series:
    if s.dtype == bool:
        return s.fillna(False)
    return (
        s.astype(str)
        .str.strip()
        .str.lower()
        .isin(["true", "1", "yes", "y", "t"])
    )


def clean_name(x):
    if pd.isna(x):
        return ""
    s = str(x)
    if s.startswith("b'") and s.endswith("'"):
        s = s[2:-1]
    if s.startswith('b"') and s.endswith('"'):
        s = s[2:-1]
    if s.lower() in {"nan", "none", "b'nan'", "b'none'"}:
        return ""
    return s


def frac(a, b):
    return np.nan if b == 0 else a / b


def main() -> None:
    score_path = Path("data/processed/tev_evolution_score_catalog.csv")
    if not score_path.exists():
        raise FileNotFoundError(f"Missing score catalogue: {score_path}")

    tables = Path("tables")
    tables.mkdir(parents=True, exist_ok=True)

    df = pd.read_csv(score_path, low_memory=False).copy()
    df["S_TeV_evo"] = pd.to_numeric(df["S_TeV_evo"], errors="coerce")
    if "tevcat_matched" in df.columns:
        df["is_known_tev"] = as_bool_series(df["tevcat_matched"])
    elif "tevcat_name" in df.columns:
        df["is_known_tev"] = df["tevcat_name"].notna() & (df["tevcat_name"].astype(str).str.lower() != "nan")
    else:
        raise KeyError("No TeVCat indicator found.")

    n_total = len(df)
    n_known = int(df["is_known_tev"].sum())

    def tier_count(tiers):
        mask = df["tev_priority_tier"].isin(tiers)
        return int(mask.sum()), int((mask & df["is_known_tev"]).sum())

    rows = []
    for label, tiers in [
        ("Gold", ["Gold"]),
        ("Gold+Silver", ["Gold", "Silver"]),
        ("Gold+Silver+Bronze", ["Gold", "Silver", "Bronze"]),
    ]:
        n_tier, k_known = tier_count(tiers)
        rows.append(
            {
                "Selection": label,
                "Catalogue sources": n_tier,
                "Catalogue fraction": frac(n_tier, n_total),
                "Known TeV recovered": k_known,
                "Known TeV fraction": frac(k_known, n_known),
                "Enrichment": frac(k_known, n_known) / frac(n_tier, n_total),
            }
        )

    # Add AUROC row from validation summary if available.
    summary_path = Path("tables/validation_summary_v0_1_3.csv")
    if summary_path.exists():
        s = pd.read_csv(summary_path)
        hit = s[s["metric"].astype(str).eq("AUROC_knownTeV_vs_other")]
        if len(hit):
            rows.append(
                {
                    "Selection": "AUROC known-TeV vs other",
                    "Catalogue sources": n_total,
                    "Catalogue fraction": np.nan,
                    "Known TeV recovered": n_known,
                    "Known TeV fraction": np.nan,
                    "Enrichment": float(hit["enrichment_vs_random"].iloc[0]),
                }
            )

    val = pd.DataFrame(rows)
    val_csv = tables / "table_validation_summary_paper_v0_1_4.csv"
    val_tex = tables / "table_validation_summary_paper_v0_1_4.tex"
    val.to_csv(val_csv, index=False)
    val.to_latex(val_tex, index=False, float_format="%.4g", escape=True)

    known = df[df["is_known_tev"]].sort_values("S_TeV_evo", ascending=False).copy()
    for c in ["SRC_NAME", "tevcat_name", "tev_priority_tier"]:
        if c in known.columns:
            known[c] = known[c].map(clean_name)
    keep_known = [c for c in ["SRC_NAME", "tevcat_name", "tevcat_sep_arcsec", "S_TeV_evo", "tev_priority_tier"] if c in known.columns]
    known_tab = known[keep_known].rename(
        columns={
            "SRC_NAME": "BlazEr1 source",
            "tevcat_name": "TeVCat source",
            "tevcat_sep_arcsec": "Separation arcsec",
            "S_TeV_evo": "Score",
            "tev_priority_tier": "Tier",
        }
    )
    known_csv = tables / "table_known_tev_recovery_paper_v0_1_4.csv"
    known_tex = tables / "table_known_tev_recovery_paper_v0_1_4.tex"
    known_tab.to_csv(known_csv, index=False)
    known_tab.to_latex(known_tex, index=False, float_format="%.3f", escape=True)

    nontev_gold = df[(~df["is_known_tev"]) & (df["tev_priority_tier"].eq("Gold"))].sort_values("S_TeV_evo", ascending=False).copy()
    for c in ["SRC_NAME", "BLAZAR_CLASS", "FGL_SRC_NAME", "fermi_Source_Name"]:
        if c in nontev_gold.columns:
            nontev_gold[c] = nontev_gold[c].map(clean_name)
    candidate_cols = [
        "SRC_NAME",
        "ra_deg",
        "dec_deg",
        "BLAZAR_CLASS",
        "S_TeV_evo",
        "redshift_adopted",
        "S_X",
        "S_gamma_hard",
        "S_IR",
        "S_R",
        "S_nu_peak",
        "S_EBL_proxy",
        "fermi_matched",
    ]
    candidate_cols = [c for c in candidate_cols if c in nontev_gold.columns]
    cand = nontev_gold[candidate_cols].head(50).rename(
        columns={
            "SRC_NAME": "Source",
            "ra_deg": "RA deg",
            "dec_deg": "Dec deg",
            "BLAZAR_CLASS": "Class",
            "S_TeV_evo": "Score",
            "redshift_adopted": "z",
            "fermi_matched": "Fermi match",
        }
    )
    cand_csv = tables / "table_top_gold_non_tev_candidates_v0_1_4.csv"
    cand_tex = tables / "table_top_gold_non_tev_candidates_v0_1_4.tex"
    cand.to_csv(cand_csv, index=False)
    cand.head(20).to_latex(cand_tex, index=False, float_format="%.3f", escape=True)

    print("Saved:", val_csv)
    print("Saved:", val_tex)
    print("Saved:", known_csv)
    print("Saved:", known_tex)
    print("Saved:", cand_csv)
    print("Saved:", cand_tex)
    print("\nValidation summary:")
    print(val.to_string(index=False))
    print("\nTop non-TeV Gold candidates preview:")
    print(cand.head(10).to_string(index=False))


if __name__ == "__main__":
    main()
