#!/usr/bin/env python
from __future__ import annotations

import pandas as pd
from pathlib import Path

SCORE_COLS = ["S_X", "S_gamma_hard", "S_gamma_var", "S_IR", "S_R", "S_nu_peak", "S_CD_penalty", "S_EBL_proxy"]


def main() -> None:
    path = Path("data/interim/master_with_features.csv")
    if not path.exists():
        raise SystemExit("Missing data/interim/master_with_features.csv. Run scripts/03_build_features.py first.")
    df = pd.read_csv(path, low_memory=False)
    print("feature table shape:", df.shape)
    print("\nScore-component coverage:")
    for col in SCORE_COLS:
        if col in df.columns:
            n = pd.to_numeric(df[col], errors="coerce").notna().sum()
            print(f"{col:18s} {n:5d} / {len(df)} ({n/len(df):.3f})")
        else:
            print(f"{col:18s} MISSING")
    print("\nAdopted redshift sources:")
    if "redshift_adopted_source" in df.columns:
        print(df["redshift_adopted_source"].value_counts(dropna=False).head(20).to_string())
    print("\nSynchrotron-peak proxy methods:")
    if "log_nu_peak_proxy_method" in df.columns:
        print(df["log_nu_peak_proxy_method"].value_counts(dropna=False).head(20).to_string())

    score_path = Path("data/processed/known_tev_validation_sample.csv")
    if score_path.exists():
        val = pd.read_csv(score_path, low_memory=False)
        print("\nKnown-TeV tier recovery:")
        print(val["tev_priority_tier"].value_counts(dropna=False).to_string())
        n = len(val)
        if n:
            print("Gold fraction =", (val["tev_priority_tier"] == "Gold").sum() / n)
            print("Gold+Silver fraction =", val["tev_priority_tier"].isin(["Gold", "Silver"]).sum() / n)


if __name__ == "__main__":
    main()
