#!/usr/bin/env python
"""v0.1.6 physical-branch tests for the BlazEr1 TeV-evolution project.

This script adds five manuscript-level diagnostics:
  1) ordered population trend: FSRQ/QSO -> BCU -> BL Lac -> HSP-like;
  2) partial Spearman correlation of S_TeV,evo with log nu_peak controlling for z;
  3) redshift-bin table with score, Gold fraction, and TeVCat fraction;
  4) no-leakage/circularity audit for TeVCat/Fermi-TeV flags;
  5) branch-strength summary table.

It does not change the science catalogue or score. It reads the existing
v0.1.5 augmented catalogue and writes new tables/docs for the manuscript.
"""
from __future__ import annotations

import re
from pathlib import Path
import numpy as np
import pandas as pd
from scipy import stats

ROOT = Path('.')
CAT_PATHS = [
    ROOT / 'data/processed/tev_evolution_score_catalog_v0_1_5_augmented.csv',
    ROOT / 'data/processed/tev_evolution_score_catalog.csv',
]
TABLES = ROOT / 'tables'
DOCS = ROOT / 'docs'
TABLES.mkdir(exist_ok=True, parents=True)
DOCS.mkdir(exist_ok=True, parents=True)

TIER_ORDER = {'Low-priority': 0, 'Bronze': 1, 'Silver': 2, 'Gold': 3}
STAGE_ORDER = ['FSRQ/QSO-like', 'BCU/uncertain', 'BL Lac-like', 'HSP-like']


def load_catalogue() -> pd.DataFrame:
    for p in CAT_PATHS:
        if p.exists():
            return pd.read_csv(p, low_memory=False)
    raise FileNotFoundError('No score catalogue found. Run v0.1.5 diagnostics first.')


def bool_series(df: pd.DataFrame, col: str) -> pd.Series:
    if col not in df.columns:
        return pd.Series(False, index=df.index)
    s = df[col]
    if s.dtype == bool:
        return s.fillna(False)
    return s.astype(str).str.lower().isin(['true', '1', 'yes', 'y', 't'])


def numeric(df: pd.DataFrame, col: str) -> pd.Series:
    if col not in df.columns:
        return pd.Series(np.nan, index=df.index, dtype=float)
    return pd.to_numeric(df[col], errors='coerce')


def add_branch_stage(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    if 'broad_class' not in out.columns:
        out['broad_class'] = 'Other/uncertain'
    if 'sed_class_proxy' not in out.columns:
        out['sed_class_proxy'] = 'Unknown'
    stage = out['broad_class'].astype(str).where(out['broad_class'].astype(str).isin(STAGE_ORDER[:-1]), 'BCU/uncertain')
    # HSP-like overrides broad class, because this is the end-state branch proxy.
    stage = stage.where(out['sed_class_proxy'].astype(str).ne('HSP-like'), 'HSP-like')
    out['branch_stage'] = pd.Categorical(stage, categories=STAGE_ORDER, ordered=True)
    out['branch_stage_rank'] = out['branch_stage'].cat.codes.replace(-1, np.nan)
    out['is_known_tev_clean'] = bool_series(out, 'is_known_tev') | bool_series(out, 'tevcat_matched')
    out['tier_rank_clean'] = out['tev_priority_tier'].map(TIER_ORDER)
    out['is_gold'] = out['tev_priority_tier'].eq('Gold')
    out['is_gold_silver'] = out['tev_priority_tier'].isin(['Gold', 'Silver'])
    out['redshift_clean'] = numeric(out, 'redshift_adopted_clean')
    if out['redshift_clean'].isna().all():
        out['redshift_clean'] = numeric(out, 'redshift_adopted')
    out['log_nu_peak_clean'] = numeric(out, 'log_nu_peak_proxy')
    out['score_clean'] = numeric(out, 'S_TeV_evo')
    return out


def safe_spearman(x: pd.Series, y: pd.Series) -> tuple[float, float, int]:
    m = pd.to_numeric(x, errors='coerce').notna() & pd.to_numeric(y, errors='coerce').notna()
    n = int(m.sum())
    if n < 5:
        return np.nan, np.nan, n
    rho, p = stats.spearmanr(pd.to_numeric(x[m]), pd.to_numeric(y[m]))
    return float(rho), float(p), n


def partial_spearman(x: pd.Series, y: pd.Series, controls: list[pd.Series]) -> tuple[float, float, int]:
    vals = [pd.to_numeric(x, errors='coerce'), pd.to_numeric(y, errors='coerce')] + [pd.to_numeric(c, errors='coerce') for c in controls]
    m = np.logical_and.reduce([v.notna().to_numpy() for v in vals])
    n = int(m.sum())
    if n < 10:
        return np.nan, np.nan, n
    # rank-transform all variables, then residualize x and y against controls.
    xr = stats.rankdata(vals[0][m])
    yr = stats.rankdata(vals[1][m])
    Z = np.column_stack([stats.rankdata(v[m]) for v in vals[2:]])
    Z = np.column_stack([np.ones(n), Z])
    bx = np.linalg.lstsq(Z, xr, rcond=None)[0]
    by = np.linalg.lstsq(Z, yr, rcond=None)[0]
    rx = xr - Z @ bx
    ry = yr - Z @ by
    r, p = stats.pearsonr(rx, ry)
    return float(r), float(p), n


def branch_stage_summary(df: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for stage in STAGE_ORDER:
        sub = df[df['branch_stage'].astype(str).eq(stage)].copy()
        if len(sub) == 0:
            continue
        rows.append({
            'branch_stage': stage,
            'stage_rank': STAGE_ORDER.index(stage),
            'N': len(sub),
            'known_TeV_N': int(sub['is_known_tev_clean'].sum()),
            'known_TeV_fraction': float(sub['is_known_tev_clean'].mean()),
            'median_score': float(sub['score_clean'].median()),
            'mean_score': float(sub['score_clean'].mean()),
            'gold_N': int(sub['is_gold'].sum()),
            'gold_fraction': float(sub['is_gold'].mean()),
            'gold_silver_N': int(sub['is_gold_silver'].sum()),
            'gold_silver_fraction': float(sub['is_gold_silver'].mean()),
            'redshift_available_N': int(sub['redshift_clean'].notna().sum()),
            'redshift_available_fraction': float(sub['redshift_clean'].notna().mean()),
            'median_z': float(sub['redshift_clean'].median()),
            'log_nu_peak_available_N': int(sub['log_nu_peak_clean'].notna().sum()),
            'log_nu_peak_available_fraction': float(sub['log_nu_peak_clean'].notna().mean()),
            'median_log_nu_peak_proxy': float(sub['log_nu_peak_clean'].median()),
        })
    tab = pd.DataFrame(rows)
    tab.to_csv(TABLES / 'table_ordered_branch_stage_summary_v0_1_6.csv', index=False)
    try:
        tab.to_latex(TABLES / 'table_ordered_branch_stage_summary_v0_1_6.tex', index=False, float_format='%.4g')
    except Exception:
        pass
    return tab


def branch_trend_tests(df: pd.DataFrame) -> pd.DataFrame:
    rows = []
    # Full branch trend.
    rho, p, n = safe_spearman(df['branch_stage_rank'], df['score_clean'])
    rows.append({'test': 'Spearman_stage_rank_vs_score', 'sample': 'all_branch_stages', 'N': n, 'statistic': rho, 'p_value': p})
    rho, p, n = safe_spearman(df['branch_stage_rank'], df['tier_rank_clean'])
    rows.append({'test': 'Spearman_stage_rank_vs_tier_rank', 'sample': 'all_branch_stages', 'N': n, 'statistic': rho, 'p_value': p})
    rho, p, n = safe_spearman(df['branch_stage_rank'], df['redshift_clean'])
    rows.append({'test': 'Spearman_stage_rank_vs_redshift', 'sample': 'z_available', 'N': n, 'statistic': rho, 'p_value': p})
    rho, p, n = safe_spearman(df['branch_stage_rank'], df['log_nu_peak_clean'])
    rows.append({'test': 'Spearman_stage_rank_vs_log_nu_peak_proxy', 'sample': 'nu_peak_available', 'N': n, 'statistic': rho, 'p_value': p})
    # Kruskal-Wallis across ordered groups.
    groups = [df.loc[df['branch_stage'].astype(str).eq(stage), 'score_clean'].dropna().to_numpy() for stage in STAGE_ORDER]
    groups = [g for g in groups if len(g) > 0]
    if len(groups) >= 2:
        H, pkw = stats.kruskal(*groups)
        rows.append({'test': 'Kruskal_Wallis_score_by_branch_stage', 'sample': 'all_branch_stages', 'N': int(sum(len(g) for g in groups)), 'statistic': float(H), 'p_value': float(pkw)})
    tab = pd.DataFrame(rows)
    tab.to_csv(TABLES / 'table_ordered_branch_trend_tests_v0_1_6.csv', index=False)
    try:
        tab.to_latex(TABLES / 'table_ordered_branch_trend_tests_v0_1_6.tex', index=False, float_format='%.4g')
    except Exception:
        pass
    return tab


def partial_correlation_table(df: pd.DataFrame) -> pd.DataFrame:
    samples = {
        'all_valid_z_nu_peak': df,
        'secure_redshift_only': df[df.get('redshift_secure', False).fillna(False).astype(bool)] if 'redshift_secure' in df else df.iloc[0:0],
        'BL_Lac_like_only': df[df['broad_class'].astype(str).eq('BL Lac-like')] if 'broad_class' in df else df.iloc[0:0],
        'non_known_TeV_only': df[~df['is_known_tev_clean']],
        'fermi_matched_only': df[bool_series(df, 'fermi_matched_clean') | bool_series(df, 'fermi_matched')],
    }
    rows = []
    for name, sub in samples.items():
        rho_raw, p_raw, n_raw = safe_spearman(sub['score_clean'], sub['log_nu_peak_clean'])
        r_z, p_z, n_z = partial_spearman(sub['score_clean'], sub['log_nu_peak_clean'], [sub['redshift_clean']])
        rows.append({
            'sample': name,
            'N_raw': n_raw,
            'spearman_score_vs_log_nu_peak': rho_raw,
            'spearman_p': p_raw,
            'N_partial_z': n_z,
            'partial_spearman_control_z': r_z,
            'partial_spearman_p_control_z': p_z,
        })
    tab = pd.DataFrame(rows)
    tab.to_csv(TABLES / 'table_partial_correlation_score_nupeak_control_z_v0_1_6.csv', index=False)
    try:
        tab.to_latex(TABLES / 'table_partial_correlation_score_nupeak_control_z_v0_1_6.tex', index=False, float_format='%.4g')
    except Exception:
        pass
    return tab


def redshift_bin_table(df: pd.DataFrame) -> pd.DataFrame:
    z = df['redshift_clean']
    # Compact bins that keep low-z structure while covering the full z range.
    bins = [0.0, 0.1, 0.2, 0.3, 0.5, 0.75, 1.0, 1.5, 2.0, 3.0, 5.0, 8.0]
    labels = [f'{bins[i]:.2g}-{bins[i+1]:.2g}' for i in range(len(bins)-1)]
    zbin = pd.cut(z, bins=bins, labels=labels, include_lowest=True, right=False)
    rows = []
    for lab in labels:
        sub = df[zbin.astype(str).eq(lab)].copy()
        if len(sub) == 0:
            continue
        rows.append({
            'z_bin': lab,
            'z_min': float(str(lab).split('-')[0]),
            'N': len(sub),
            'known_TeV_N': int(sub['is_known_tev_clean'].sum()),
            'known_TeV_fraction': float(sub['is_known_tev_clean'].mean()),
            'median_z': float(sub['redshift_clean'].median()),
            'median_score': float(sub['score_clean'].median()),
            'mean_score': float(sub['score_clean'].mean()),
            'gold_N': int(sub['is_gold'].sum()),
            'gold_fraction': float(sub['is_gold'].mean()),
            'gold_silver_N': int(sub['is_gold_silver'].sum()),
            'gold_silver_fraction': float(sub['is_gold_silver'].mean()),
            'hsp_like_N': int(sub['sed_class_proxy'].astype(str).eq('HSP-like').sum()) if 'sed_class_proxy' in sub else 0,
            'hsp_like_fraction': float(sub['sed_class_proxy'].astype(str).eq('HSP-like').mean()) if 'sed_class_proxy' in sub else np.nan,
            'median_log_nu_peak_proxy': float(sub['log_nu_peak_clean'].median()),
        })
    tab = pd.DataFrame(rows)
    tab.to_csv(TABLES / 'table_redshift_bin_evolutionary_branch_v0_1_6.csv', index=False)
    try:
        tab.to_latex(TABLES / 'table_redshift_bin_evolutionary_branch_v0_1_6.tex', index=False, float_format='%.4g')
    except Exception:
        pass
    return tab


def no_leakage_audit(df: pd.DataFrame) -> pd.DataFrame:
    forbidden_patterns = ['tevcat', 'assoc_tev', 'tev_flag', 'known_tev', 'is_known_tev', 'has_known_tev']
    score_components = {
        'S_X': ['ML_FLUX_1', 'PWL*_FLUX*', 'XRT_*FLUX*', 'SOFTFLUX_S'],
        'S_gamma_hard': ['fermi_PL_Index', 'fermi_LP_Index', 'FGL_*INDEX*'],
        'S_gamma_var': ['fermi_Variability_Index', 'fermi_Frac_Variability'],
        'S_IR': ['W1_MAG', 'W2_MAG', 'W3_MAG', 'W1_MINUS_W2', 'DERED_MAG_W1', 'DERED_MAG_W2'],
        'S_R': ['RFC_*RES/UNRES', 'XIE_MORPH_*', 'MOJAVE_*', 'TANAMI_*'],
        'S_nu_peak': ['LAC_LE_FREQ', 'LAC_SED_CLASS', 'ALPHA_RX', 'HSP_SRC_NAME'],
        'S_CD_penalty': ['gamma_energy_flux_adopted / xray_flux_adopted'],
        'S_EBL_proxy': ['redshift_adopted from Z_SPEC/Z_MASTER/Z_4LAC/Z_BZCAT/Z_SIMBAD/Z_3HSP/Z_MILLIQUAS/Z_PHOTO'],
    }
    rows = []
    for comp, inputs in score_components.items():
        txt = ' '.join(inputs).lower()
        leakage = any(p in txt for p in forbidden_patterns)
        rows.append({
            'score_component': comp,
            'input_columns_or_proxies': '; '.join(inputs),
            'uses_TeVCat_or_known_TeV_flag': leakage,
            'audit_result': 'FAIL' if leakage else 'PASS',
        })
    # Code scan for transparency. Distinguish scoring from validation output.
    scan_files = [
        Path('src/blazar_input/scoring.py'),
        Path('src/blazar_input/features.py'),
        Path('scripts/03_build_features.py'),
        Path('scripts/04_compute_tev_evolution_score.py'),
    ]
    code_hits = []
    for fp in scan_files:
        if not fp.exists():
            continue
        text = fp.read_text(errors='ignore')
        for pat in forbidden_patterns:
            if re.search(pat, text, flags=re.IGNORECASE):
                code_hits.append({'file': str(fp), 'forbidden_token': pat})
    leak_tab = pd.DataFrame(rows)
    leak_tab.to_csv(TABLES / 'table_no_leakage_score_component_audit_v0_1_6.csv', index=False)
    try:
        leak_tab.to_latex(TABLES / 'table_no_leakage_score_component_audit_v0_1_6.tex', index=False)
    except Exception:
        pass
    hits = pd.DataFrame(code_hits)
    if hits.empty:
        hits = pd.DataFrame(columns=['file', 'forbidden_token'])
    hits.to_csv(TABLES / 'table_no_leakage_code_token_scan_v0_1_6.csv', index=False)
    return leak_tab


def write_snippets(branch, trend, partial, zbin, leakage) -> None:
    gold = pd.read_csv(TABLES / 'table_selection_stress_tests_v0_1_5.csv') if (TABLES / 'table_selection_stress_tests_v0_1_5.csv').exists() else pd.DataFrame()
    lines = []
    lines.append('% v0.1.6 physical-branch result snippets')
    lines.append('')
    if not branch.empty:
        best = branch[['branch_stage','N','known_TeV_N','median_z','median_score','gold_fraction','gold_silver_fraction','median_log_nu_peak_proxy']]
        lines.append('The ordered branch-stage summary is:')
        lines.append(best.to_string(index=False))
        lines.append('')
    if not trend.empty:
        lines.append('Ordered branch trend tests:')
        lines.append(trend.to_string(index=False))
        lines.append('')
    if not partial.empty:
        lines.append('Partial correlation tests for score versus synchrotron-peak proxy:')
        lines.append(partial.to_string(index=False))
        lines.append('')
    if not zbin.empty:
        lines.append('Redshift-bin evolutionary table:')
        lines.append(zbin.to_string(index=False))
        lines.append('')
    lines.append('Interpretation note: these tests support a population-level TeV-favourable branch, not a direct proof that individual FSRQs temporally evolve into BL Lacs.')
    (DOCS / 'results_snippets_physical_branch_tests_v0_1_6.txt').write_text('\n'.join(lines), encoding='utf-8')

    latex = r'''
\paragraph{Physical branch tests.}
We tested whether the TeV-evolution score behaves as a population-level
branch diagnostic rather than as a purely empirical rank. Sources were
placed on an ordered class sequence, FSRQ/QSO-like $\rightarrow$
BCU/uncertain $\rightarrow$ BL Lac-like $\rightarrow$ HSP-like, where
HSP-like sources were identified from the synchrotron-peak proxy layer.
We then measured the monotonic trend of $S_{\rm TeV,evo}$ across this
ordered sequence, the partial Spearman association between $S_{\rm TeV,evo}$
and $\log\nu_{\rm peak}$ after controlling for redshift, and the evolution
of the Gold and Gold+Silver fractions in redshift bins. A no-leakage audit
confirmed that the score components use X-ray, GeV, infrared, radio,
redshift, Compton-dominance, and synchrotron-peak proxies, but not TeVCat
membership or Fermi TeV-association flags. These tests are interpreted as
evidence for a TeV-favourable population branch, not as proof of one-to-one
time evolution of individual blazars.
'''.strip()
    (DOCS / 'latex_snippet_physical_branch_tests_v0_1_6.tex').write_text(latex, encoding='utf-8')


def main() -> None:
    df = add_branch_stage(load_catalogue())
    # Save augmented v0.1.6 catalogue with branch-stage variables.
    out_path = ROOT / 'data/processed/tev_evolution_score_catalog_v0_1_6_branch_augmented.csv'
    out_path.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(out_path, index=False)

    branch = branch_stage_summary(df)
    trend = branch_trend_tests(df)
    partial = partial_correlation_table(df)
    zbin = redshift_bin_table(df)
    leakage = no_leakage_audit(df)
    write_snippets(branch, trend, partial, zbin, leakage)

    print('v0.1.6 physical-branch diagnostics complete.')
    print(f'Augmented catalogue: {out_path}')
    print('\nOrdered branch-stage summary:')
    print(branch.to_string(index=False))
    print('\nOrdered trend tests:')
    print(trend.to_string(index=False))
    print('\nPartial correlations:')
    print(partial.to_string(index=False))
    print('\nNo-leakage component audit:')
    print(leakage.to_string(index=False))


if __name__ == '__main__':
    main()
