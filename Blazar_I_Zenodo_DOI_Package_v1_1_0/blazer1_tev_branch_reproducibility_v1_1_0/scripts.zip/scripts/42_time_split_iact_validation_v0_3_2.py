from __future__ import annotations

import sys
from pathlib import Path
sys.path.append(str(Path(__file__).resolve().parent))

import numpy as np
import pandas as pd

from _v030_helpers import TABLES, DOCS, wilson_interval, jeffreys_interval
from _v031_v033_helpers import (
    EXTERNAL, load_frozen, coordinate_crossmatch, attach_catalogue_fields,
    exact_random_tier_test,
)

FREEZE_DATES = [pd.Timestamp("2018-12-31"), pd.Timestamp("2020-12-31")]
DATE_AXES = ["public_report_date", "detection_event_date"]


def tier_success(series: pd.Series, tier_set: str) -> pd.Series:
    s = series.astype(str)
    return s.eq("Gold") if tier_set == "Gold" else s.isin(["Gold", "Silver"])


def main() -> None:
    df, frozen_path = load_frozen()
    history_path = EXTERNAL / "iact_discovery_history_v0_3_2.csv"
    if not history_path.exists():
        raise FileNotFoundError(f"Missing seeded history file: {history_path}")
    hist = pd.read_csv(history_path, low_memory=False)
    for c in DATE_AXES:
        hist[c] = pd.to_datetime(hist[c], errors="coerce")
    hist["include_time_split"] = hist["include_time_split"].astype(str).str.lower().isin({"true","1","yes"})
    hist = hist[hist["include_time_split"]].copy()

    matched = coordinate_crossmatch(hist, df, radius_arcsec=180.0)
    matched = attach_catalogue_fields(matched, df)
    matched["validation_class"] = "quasi_prospective_label_time_split"
    matched["strict_feature_time_blind"] = False
    matched["feature_snapshot_note"] = "Scores use the frozen current BlazEr1 feature table; historical feature snapshots were not reconstructed."
    matched.to_csv(TABLES / "table_iact_discovery_history_crossmatch_v0_3_2.csv", index=False)
    matched[matched["catalogue_matched"].astype(bool)].to_csv(TABLES / "table_iact_discovery_history_matched_v0_3_2.csv", index=False)
    matched[~matched["catalogue_matched"].astype(bool)].to_csv(TABLES / "table_iact_discovery_history_unmatched_v0_3_2.csv", index=False)

    summary_rows = []
    source_rows = []
    variants = {
        "full": "matched_full_tier_v031",
        "xray_only": "matched_xray_only_tier_v031",
        "no_xray": "matched_no_xray_tier_v031",
        "continuous_peak_only": "matched_tier_continuous_peak_only",
    }
    for axis in DATE_AXES:
        for freeze in FREEZE_DATES:
            eligible = matched[matched[axis].notna() & (matched[axis] > freeze)].copy()
            eligible["date_axis"] = axis
            eligible["freeze_date"] = freeze.date().isoformat()
            source_rows.append(eligible)
            n_all = len(eligible)
            n_match = int(eligible["catalogue_matched"].astype(bool).sum())
            for variant, tier_col in variants.items():
                sub = eligible[eligible["catalogue_matched"].astype(bool) & eligible[tier_col].notna()].copy()
                n = len(sub)
                for tier_set, expected in [("Gold", 0.05), ("Gold+Silver", 0.15)]:
                    k = int(tier_success(sub[tier_col], tier_set).sum()) if n else 0
                    wlo, whi = wilson_interval(k, n)
                    jlo, jhi = jeffreys_interval(k, n)
                    summary_rows.append({
                        "date_axis": axis,
                        "freeze_date": freeze.date().isoformat(),
                        "score_variant": variant,
                        "tier_set": tier_set,
                        "postfreeze_detection_rows": n_all,
                        "matched_detection_rows": n_match,
                        "variant_usable_N": n,
                        "recovered_N": k,
                        "recovery_fraction": k / n if n else np.nan,
                        "wilson95_low": wlo,
                        "wilson95_high": whi,
                        "jeffreys95_low": jlo,
                        "jeffreys95_high": jhi,
                        "random_tier_fraction": expected,
                        "exact_binomial_p_greater": exact_random_tier_test(k, n, expected),
                        "strict_feature_time_blind": False,
                        "validation_class": "quasi_prospective_label_time_split",
                    })
    summary = pd.DataFrame(summary_rows)
    summary.to_csv(TABLES / "table_time_split_iact_validation_summary_v0_3_2.csv", index=False)
    pd.concat(source_rows, ignore_index=True).to_csv(TABLES / "table_time_split_iact_source_rows_v0_3_2.csv", index=False)

    report = [
        "# v0.3.2 time-split IACT validation", "",
        f"Frozen catalogue: `{frozen_path}`", "",
        "This is a label-time split, not a strict feature-time-blind prospective validation. The score is frozen, but historical versions of every input catalogue were not reconstructed.", "",
        f"IACT discovery rows: {len(hist)}; matched to BlazEr1 within 180 arcsec: {int(matched['catalogue_matched'].sum())}.", "",
        summary.to_markdown(index=False), "",
        "Use the public-report-date axis as the primary audit. Event dates are incomplete for multi-year campaigns and are retained only as a secondary sensitivity axis.",
    ]
    (DOCS / "time_split_iact_validation_report_v0_3_2.md").write_text("\n".join(report), encoding="utf-8")
    print("v0.3.2 time-split IACT validation complete.")
    print(f"History rows={len(hist)}; matched={int(matched['catalogue_matched'].sum())}; unmatched={int((~matched['catalogue_matched']).sum())}")
    compact = summary[(summary["date_axis"].eq("public_report_date")) & summary["score_variant"].isin(["full", "xray_only"])]
    print(compact.to_string(index=False))


if __name__ == "__main__":
    main()
