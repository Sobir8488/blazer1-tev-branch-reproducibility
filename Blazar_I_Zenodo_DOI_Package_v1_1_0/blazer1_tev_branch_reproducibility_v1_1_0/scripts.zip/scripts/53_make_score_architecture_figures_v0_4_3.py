from __future__ import annotations

import sys
from pathlib import Path
sys.path.append(str(Path(__file__).resolve().parent))

import numpy as np
import pandas as pd
import matplotlib as mpl
import matplotlib.pyplot as plt

from _v043_helpers import TABLES, FIGURES

mpl.rcParams["pdf.fonttype"] = 42
mpl.rcParams["ps.fonttype"] = 42
mpl.rcParams["font.family"] = "serif"
mpl.rcParams["font.size"] = 9


def save(fig, stem: str) -> None:
    fig.tight_layout()
    fig.savefig(FIGURES / f"{stem}.pdf", bbox_inches="tight")
    fig.savefig(FIGURES / f"{stem}.png", dpi=220, bbox_inches="tight")
    plt.close(fig)


def main() -> None:
    arch = pd.read_csv(TABLES / "table_score_architecture_variants_v0_4_3.csv")
    keep = arch[arch["score_variant"].isin(["published_available", "active_available", "fixed_active_weight"])]
    labels = ["Published\navailable", "Active-component\navailable", "Fixed active\nweight"]

    fig, ax = plt.subplots(figsize=(6.8, 4.1))
    x = np.arange(len(keep))
    width = 0.25
    ax.bar(x-width, keep["AUROC"], width, label="AUROC")
    ax.bar(x, keep["Gold_Jaccard_vs_published"], width, label="Gold Jaccard")
    ax.bar(x+width, keep["Gold_recovery"], width, label="Gold recovery")
    ax.set_xticks(x, labels)
    ax.set_ylim(0, 1.03)
    ax.set_ylabel("Metric value")
    ax.legend(frameon=False, ncol=3, loc="lower center")
    save(fig, "Fig_score_architecture_auc_stability_v0_4_3")

    cond = pd.read_csv(TABLES / "table_pattern_conditioned_validation_v0_4_3.csv")
    keep2 = cond[cond["score_variant"].isin(["published_available", "active_available", "fixed_active_weight", "xray_only", "no_xray"])]
    labels2 = ["Published", "Active", "Fixed active", "X-ray only", "No X-ray"]
    fig, ax = plt.subplots(figsize=(7.2, 4.2))
    x = np.arange(len(keep2)); width = 0.36
    ax.bar(x-width/2, keep2["unrestricted_AUROC"], width, label="Unrestricted")
    ax.bar(x+width/2, keep2["within_pattern_percentile_AUROC"], width, label="Exact-pattern conditioned")
    ax.axhline(0.5, linestyle="--", linewidth=1)
    ax.set_xticks(x, labels2, rotation=20, ha="right")
    ax.set_ylim(0.45, 1.0)
    ax.set_ylabel("AUROC")
    ax.legend(frameon=False)
    save(fig, "Fig_availability_pattern_conditioned_validation_v0_4_3")

    stab = pd.read_csv(TABLES / "table_candidate_architecture_stability_v0_4_3.csv")
    keep3 = stab[stab["score_variant"].isin(["published_available", "active_available", "fixed_active_weight"])]
    fig, ax = plt.subplots(figsize=(6.8, 4.1))
    x = np.arange(len(keep3)); width = 0.24
    ax.bar(x-width, keep3["Gold_Jaccard_vs_published"], width, label="Gold")
    ax.bar(x, keep3["List_A_Jaccard_vs_published"], width, label="List A")
    ax.bar(x+width, keep3["List_B_Jaccard_vs_published"], width, label="List B")
    ax.set_xticks(x, labels)
    ax.set_ylim(0, 1.03)
    ax.set_ylabel("Jaccard overlap with published architecture")
    ax.legend(frameon=False, ncol=3)
    save(fig, "Fig_candidate_architecture_stability_v0_4_3")

    trans = pd.read_csv(TABLES / "table_score_architecture_tier_transitions_v0_4_3.csv")
    d = trans[trans["comparison_variant"].eq("active_available")]
    order = ["Low", "Bronze", "Silver", "Gold"]
    matrix = d.pivot(index="published_tier", columns="variant_tier", values="N").reindex(index=order, columns=order).fillna(0).to_numpy()
    fig, ax = plt.subplots(figsize=(5.1, 4.4))
    im = ax.imshow(matrix, aspect="auto")
    ax.set_xticks(range(4), order); ax.set_yticks(range(4), order)
    ax.set_xlabel("Active-component tier"); ax.set_ylabel("Published tier")
    for i in range(4):
        for j in range(4):
            ax.text(j, i, f"{int(matrix[i,j])}", ha="center", va="center")
    fig.colorbar(im, ax=ax, label="Sources")
    save(fig, "Fig_active_score_tier_transitions_v0_4_3")

    print("Saved v0.4.3 score-architecture figures under figures/.")


if __name__ == "__main__":
    main()
