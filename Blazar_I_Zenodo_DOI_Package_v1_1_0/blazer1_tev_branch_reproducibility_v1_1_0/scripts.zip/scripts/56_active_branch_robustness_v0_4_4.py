#!/usr/bin/env python
from __future__ import annotations
import os
import numpy as np
import pandas as pd
from scipy.stats import kruskal
from _v044_helpers import *


def ensure_stage(df):
    out=df.copy()
    if "branch_stage" not in out:
        broad=out.get("broad_class",pd.Series("BCU/uncertain",index=out.index)).astype(str)
        stage=broad.where(broad.isin(STAGE_ORDER[:-1]),"BCU/uncertain")
        stage=stage.where(out.get("sed_class_proxy",pd.Series("",index=out.index)).astype(str).ne("HSP-like"),"HSP-like")
        out["branch_stage"]=stage
    out["branch_stage_rank_active_v0_4_4"]=out["branch_stage"].map({s:i for i,s in enumerate(STAGE_ORDER)})
    return out


def branch_tables(df):
    rows=[]
    for s in STAGE_ORDER:
        d=df[df["branch_stage"].astype(str).eq(s)]; z=numeric(d.get("redshift_adopted_clean",d.get("redshift_adopted"))); peak=numeric(d["log_nu_peak_proxy"]); score=numeric(d["S_TeV_branch_active_v0_4_4"]); y=d["is_known_tev"].astype(bool)
        rows.append({"branch_stage":s,"stage_rank":STAGE_ORDER.index(s),"N":len(d),"known_TeV_N":int(y.sum()),"median_active_score":float(score.median()),"mean_active_score":float(score.mean()),"Gold_N":int(d["tier_active_v0_4_4"].eq("Gold").sum()),"Gold_fraction":float(d["tier_active_v0_4_4"].eq("Gold").mean()),"Gold_Silver_N":int(d["tier_active_v0_4_4"].isin(["Gold","Silver"]).sum()),"Gold_Silver_fraction":float(d["tier_active_v0_4_4"].isin(["Gold","Silver"]).mean()),"median_z":float(z.median()),"median_log_nu_peak":float(peak.median())})
    tab=pd.DataFrame(rows); tab.to_csv(TABLES/"table_active_ordered_branch_summary_v0_4_4.csv",index=False)
    tests=[]
    for label,x in [("stage_vs_score",df["S_TeV_branch_active_v0_4_4"]),("stage_vs_tier",df["tier_rank_active_v0_4_4"]),("stage_vs_redshift",numeric(df.get("redshift_adopted_clean",df.get("redshift_adopted")))),("stage_vs_peak",df["log_nu_peak_proxy"])]:
        r,p,n=safe_spearman(df["branch_stage_rank_active_v0_4_4"],x); tests.append({"test":label,"N":n,"statistic":r,"p_value":p})
    groups=[numeric(df.loc[df["branch_stage"].astype(str).eq(s),"S_TeV_branch_active_v0_4_4"]).dropna().to_numpy() for s in STAGE_ORDER]
    H,p=kruskal(*groups); tests.append({"test":"Kruskal_Wallis_score_by_stage","N":sum(map(len,groups)),"statistic":float(H),"p_value":float(p)})
    pd.DataFrame(tests).to_csv(TABLES/"table_active_ordered_branch_tests_v0_4_4.csv",index=False)
    return tab,pd.DataFrame(tests)


def partial_table(df):
    z=numeric(df.get("redshift_adopted_clean",df.get("redshift_adopted")))
    samples={"all_valid":pd.Series(True,index=df.index),"secure_redshift":as_bool(df.get("redshift_secure",pd.Series(False,index=df.index))),"BL_Lac_like":df.get("broad_class",pd.Series("",index=df.index)).astype(str).eq("BL Lac-like"),"non_known_TeV":~df["is_known_tev"],"fermi_matched":as_bool(df.get("fermi_matched_clean",df.get("fermi_matched",pd.Series(False,index=df.index))))}
    rows=[]
    for name,m in samples.items():
        d=df[m]; zz=z[m]; r,p,n=safe_spearman(d["S_TeV_branch_active_v0_4_4"],d["log_nu_peak_proxy"]); pr,pp,pn=partial_spearman(d["S_TeV_branch_active_v0_4_4"],d["log_nu_peak_proxy"],zz)
        rows.append({"sample":name,"N_raw":n,"spearman_score_peak":r,"p_raw":p,"N_partial_z":pn,"partial_spearman_control_z":pr,"p_partial_z":pp})
    tab=pd.DataFrame(rows); tab.to_csv(TABLES/"table_active_partial_correlation_v0_4_4.csv",index=False); return tab


def redshift_bins(df):
    z=numeric(df.get("redshift_adopted_clean",df.get("redshift_adopted"))); bins=[0,.1,.2,.3,.5,.75,1,1.5,2,3,5,8]; cats=pd.cut(z,bins=bins,right=False,include_lowest=True); rows=[]
    for interval,d in df.groupby(cats,observed=True):
        if len(d)==0: continue
        rows.append({"z_bin":str(interval),"N":len(d),"known_TeV_N":int(d["is_known_tev"].sum()),"median_z":float(numeric(d.get("redshift_adopted_clean",d.get("redshift_adopted"))).median()),"median_active_score":float(numeric(d["S_TeV_branch_active_v0_4_4"]).median()),"Gold_fraction":float(d["tier_active_v0_4_4"].eq("Gold").mean()),"Gold_Silver_fraction":float(d["tier_active_v0_4_4"].isin(["Gold","Silver"]).mean()),"HSP_like_fraction":float(d.get("sed_class_proxy",pd.Series("",index=d.index)).astype(str).eq("HSP-like").mean()),"median_log_nu_peak":float(numeric(d["log_nu_peak_proxy"]).median())})
    tab=pd.DataFrame(rows); tab.to_csv(TABLES/"table_active_redshift_bins_v0_4_4.csv",index=False); return tab


def stress_table(df):
    z=numeric(df.get("redshift_adopted_clean",df.get("redshift_adopted"))); src=df.get("redshift_adopted_source_clean",df.get("redshift_adopted_source",pd.Series("",index=df.index))).astype(str)
    sx=numeric(df["S_X"]); gh=numeric(df["S_gamma_hard"])
    samples={
        "full_sample":pd.Series(True,index=df.index),
        "fermi_matched":as_bool(df.get("fermi_matched_clean",df.get("fermi_matched",pd.Series(False,index=df.index)))),
        "redshift_available":z.notna(),
        "secure_redshift":as_bool(df.get("redshift_secure",pd.Series(False,index=df.index))),
        "spectroscopic_redshift":src.str.contains("Z_SPEC",case=False,na=False),
        "high_latitude_abs_b_gt_10":numeric(df.get("BII",pd.Series(np.nan,index=df.index))).abs()>10,
        "BL_Lac_like":df.get("broad_class",pd.Series("",index=df.index)).astype(str).eq("BL Lac-like"),
        "FSRQ_QSO_like":df.get("broad_class",pd.Series("",index=df.index)).astype(str).eq("FSRQ/QSO-like"),
        "HSP_like":df.get("sed_class_proxy",pd.Series("",index=df.index)).astype(str).eq("HSP-like"),
        "z_lt_0p5":z<.5,
        "z_lt_1":z<1,
        "xray_bright_upper_half":sx>=sx.median(),
        "gamma_hard_upper_half":gh>=gh.median(),
    }
    rows=[]
    for name,m in samples.items():
        d=df[m & numeric(df["S_TeV_branch_active_v0_4_4"]).notna()]; y=d["is_known_tev"].astype(bool); N=len(d); K=int(y.sum())
        for ts,allowed in [("Gold",{"Gold"}),("Gold+Silver",{"Gold","Silver"})]:
            sel=d["tier_active_v0_4_4"].isin(allowed); n=int(sel.sum()); k=int((sel&y).sum()); lo,hi=wilson_interval(k,K)
            rows.append({"restriction":name,"tier_set":ts,"analysis_N":N,"known_TeV_N":K,"tier_N":n,"recovered_N":k,"recovery_fraction":k/K if K else np.nan,"wilson95_low":lo,"wilson95_high":hi,"enrichment":(k/K)/(n/N) if K and n else np.nan,"hypergeom_p_greater":hypergeom_p(N,K,n,k),"AUROC":auc_rank(y.to_numpy(),numeric(d["S_TeV_branch_active_v0_4_4"]).to_numpy())})
    tab=pd.DataFrame(rows); tab.to_csv(TABLES/"table_active_selection_stress_v0_4_4.csv",index=False); return tab


def weight_sensitivity(df):
    ndraw=int(os.getenv("BLAZER_V044_N_WEIGHT","1000")); seed=int(os.getenv("BLAZER_V044_SEED","8488")); rng=np.random.default_rng(seed); y=df["is_known_tev"].to_numpy(bool); base=numeric(df["S_TeV_branch_active_v0_4_4"]); base_tier=df["tier_active_v0_4_4"]; base_gold=set(df.index[base_tier.eq("Gold")]); rows=[]
    for i in range(ndraw):
        wo={k:v[2]*rng.uniform(.7,1.3) for k,v in ACTIVE_COMPONENTS.items()}; s=score_from_components(df,weight_override=wo); t=assign_tier(s); gold=t.eq("Gold"); gs=t.isin(["Gold","Silver"]); K=int(y.sum()); a=numeric(s); m=a.notna()&base.notna(); r=spearmanr(a[m],base[m]).statistic
        rows.append({"draw":i,"Gold_recovery":int((gold&df["is_known_tev"]).sum())/K,"Gold_enrichment":(int((gold&df["is_known_tev"]).sum())/K)/(gold.mean()),"Gold_Silver_recovery":int((gs&df["is_known_tev"]).sum())/K,"Gold_Silver_enrichment":(int((gs&df["is_known_tev"]).sum())/K)/(gs.mean()),"AUROC":auc_rank(y,a.to_numpy()),"spearman_vs_active":float(r),"Gold_overlap_fraction":len(base_gold&set(df.index[gold]))/len(base_gold|set(df.index[gold]))})
    draws=pd.DataFrame(rows); draws.to_csv(TABLES/"table_active_weight_random_draws_v0_4_4.csv",index=False)
    summ=[]
    for c in ["Gold_recovery","Gold_enrichment","Gold_Silver_recovery","Gold_Silver_enrichment","AUROC","spearman_vs_active","Gold_overlap_fraction"]:
        v=draws[c]; summ.append({"metric":c,"baseline":({"Gold_recovery":int((base_tier.eq('Gold')&df['is_known_tev']).sum())/int(y.sum()),"Gold_Silver_recovery":int((base_tier.isin(['Gold','Silver'])&df['is_known_tev']).sum())/int(y.sum()),"AUROC":auc_rank(y,base.to_numpy())}.get(c,np.nan)),"p05":float(v.quantile(.05)),"median":float(v.median()),"p95":float(v.quantile(.95)),"n_draws":ndraw})
    summary=pd.DataFrame(summ); summary.to_csv(TABLES/"table_active_weight_random_summary_v0_4_4.csv",index=False)
    loo=[]
    for key,(_,_,_,label) in ACTIVE_COMPONENTS.items():
        s=score_from_components(df,exclude={key}); t=assign_tier(s); gold=t.eq("Gold"); gs=t.isin(["Gold","Silver"]); m=numeric(s).notna()&base.notna(); r=spearmanr(numeric(s)[m],base[m]).statistic
        loo.append({"removed_component":key,"component_label":label,"Gold_recovery":int((gold&df["is_known_tev"]).sum())/int(y.sum()),"Gold_Silver_recovery":int((gs&df["is_known_tev"]).sum())/int(y.sum()),"AUROC":auc_rank(y,numeric(s).to_numpy()),"spearman_vs_active":float(r),"Gold_Jaccard":len(base_gold&set(df.index[gold]))/len(base_gold|set(df.index[gold]))})
    loo=pd.DataFrame(loo); loo.to_csv(TABLES/"table_active_leave_one_component_out_v0_4_4.csv",index=False); return summary,loo


def main():
    df,src=load_active_catalogue(); df=add_primary_columns(df); df=ensure_stage(df)
    b,t=branch_tables(df); p=partial_table(df); r=redshift_bins(df); s=stress_table(df); w,l=weight_sensitivity(df)
    out=PROCESSED/"tev_evolution_score_catalog_v0_4_4_active_primary.csv"; df.to_csv(out,index=False)
    print("v0.4.4 active branch and robustness analyses complete.")
    print("\nOrdered branch:"); print(b.to_string(index=False))
    print("\nPartial correlations:"); print(p.to_string(index=False))
    print("\nWeight sensitivity summary:"); print(w.to_string(index=False))
    print("\nLeave-one-out:"); print(l.to_string(index=False))

if __name__=="__main__": main()
