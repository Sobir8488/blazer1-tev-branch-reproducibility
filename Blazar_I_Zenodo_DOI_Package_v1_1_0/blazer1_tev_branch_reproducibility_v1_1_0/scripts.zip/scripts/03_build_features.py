#!/usr/bin/env python
from __future__ import annotations

import argparse
from pathlib import Path
import yaml
import pandas as pd
from blazar_input.features import add_wise_colours, add_radio_compactness, add_gamma_features, add_xray_features, add_evolution_proxies


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--config", default="configs/config.yaml")
    args = p.parse_args()
    cfg = yaml.safe_load(Path(args.config).read_text())
    master_path = Path(cfg["outputs"]["master_catalogue"])
    df = pd.read_csv(master_path)
    for fn in [add_xray_features, add_gamma_features, add_wise_colours, add_radio_compactness, add_evolution_proxies]:
        df = fn(df)
    out = Path("data/interim/master_with_features.csv")
    out.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(out, index=False)
    print(f"[OK] wrote {out} rows={len(df)} cols={len(df.columns)}")


if __name__ == "__main__":
    main()
