from __future__ import annotations

import sys
from pathlib import Path
sys.path.append(str(Path(__file__).resolve().parent))

import pandas as pd

from _v042_helpers import TABLES, DOCS, METADATA


def markdown_table(df: pd.DataFrame) -> str:
    try:
        return df.to_markdown(index=False)
    except Exception:
        return "```\n" + df.to_string(index=False) + "\n```"


def main() -> None:
    definition = pd.read_csv(TABLES / "table_exact_score_definition_v0_4_2.csv")
    reconstruction = pd.read_csv(TABLES / "table_score_reconstruction_audit_v0_4_2.csv")
    shifts = pd.read_csv(TABLES / "table_random_shift_crossmatch_summary_v0_4_2.csv")
    coverage_diag = pd.read_csv(TABLES / "table_component_coverage_diagnostics_v0_4_2.csv")
    coverage_sens = pd.read_csv(TABLES / "table_minimum_component_sensitivity_v0_4_2.csv")
    exact_coverage = pd.read_csv(TABLES / "table_exact_coverage_stratum_auroc_v0_4_2.csv")
    matching_audit = pd.read_csv(TABLES / "table_xray_matching_algorithm_audit_v0_4_2.csv")
    matching_balance = pd.read_csv(TABLES / "table_xray_matched_balance_v0_4_2.csv")
    matching_scores = pd.read_csv(TABLES / "table_xray_matched_score_metrics_v0_4_2.csv")
    matching_wins = pd.read_csv(TABLES / "table_xray_matched_pairwise_win_v0_4_2.csv")

    adopted = shifts.loc[shifts["radius_arcsec"] == 180].iloc[0]
    coverage_auc = coverage_diag.loc[
        coverage_diag["quantity"] == "AUROC coverage count for known-TeV label", "estimate"
    ].iloc[0]
    score_rho = coverage_diag.loc[
        coverage_diag["quantity"] == "Spearman full score vs component count", "estimate"
    ].iloc[0]
    high_cov = coverage_sens[
        (coverage_sens["minimum_components_required"] == 7)
        & coverage_sens["score_variant"].isin(["full", "xray_only", "no_xray"])
    ][["score_variant", "analysis_N", "known_TeV_N", "AUROC", "Gold_recovery_fraction", "Gold_Silver_recovery_fraction"]]

    report = [
        "# Scientific-hardening report v0.4.2",
        "",
        "## Scope",
        "",
        "This audit adds an exact score specification, a random-position-shift cross-match control, "
        "a component-coverage/missingness analysis, and an explicit balance audit for the X-ray-matched controls. "
        "No score weight, tier threshold, TeVCat label, or candidate-list definition is changed.",
        "",
        "## Exact score reconstruction",
        "",
        f"The published score is reconstructed for {int(reconstruction.iloc[0]['comparable_N'])} sources with a maximum absolute difference of "
        f"{reconstruction.iloc[0]['max_abs_delta_published_minus_reconstructed']:.3e}.",
        "",
        markdown_table(definition[["component_key", "fixed_weight", "available_N", "numerically_degenerate"]]),
        "",
        "The radio-compactness component is numerically degenerate in the frozen catalogue because its robust scale is zero; "
        "its standardized value is identically zero and it contributes no rank information. It should be described as an audited but inactive term, "
        "or removed from the displayed equation while retained in the machine-readable provenance for backward compatibility.",
        "",
        "## Random-shift TeVCat cross-match audit",
        "",
        f"At 180 arcsec the observed catalogue contains {int(adopted['observed_parent_matches'])} matches. "
        f"Across {int(adopted['random_draws_N'])} random local angular shifts, the median chance-match count is "
        f"{adopted['random_median_matches']:.1f}, the 97.5th percentile is {adopted['random_q97p5_matches']:.0f}, "
        f"and the maximum is {int(adopted['random_max_matches'])}. The empirical random-shift probability is "
        f"{adopted['empirical_p_random_ge_observed']:.4g}.",
        "",
        markdown_table(shifts[["radius_arcsec", "observed_parent_matches", "random_median_matches", "random_q97p5_matches", "random_max_matches", "empirical_p_random_ge_observed"]]),
        "",
        "This result argues against random sky superposition as the explanation for the 34 TeVCat associations. "
        "It does not make TeVCat a uniform survey and does not remove historical targeting bias.",
        "",
        "## Component coverage and selection history",
        "",
        f"Component count alone has known-TeV AUROC={coverage_auc:.3f}. All 34 TeVCat matches have seven or eight available components. "
        f"The full score correlates with component count at Spearman rho={score_rho:.3f}. This is a major selection-history result: "
        "historically detected TeV sources have much denser multiwavelength characterization than the general BlazEr1 population.",
        "",
        "The score still separates known TeV objects within high-coverage subsets, but the AUROCs are lower than in the unrestricted population:",
        "",
        markdown_table(high_cov),
        "",
        "Therefore the manuscript should state that retrospective enrichment contains both physical score information and a strong coverage/history layer. "
        "The X-ray-only statistic remains the strongest of the three tested scores after requiring at least seven components, supporting the X-ray-gateway result, "
        "but the unrestricted AUROC must not be presented as free of catalogue-completeness effects.",
        "",
        "## X-ray-matched control balance",
        "",
        f"The matching algorithm requests five nearest non-TeV controls per known TeV source, yielding "
        f"{int(matching_audit.iloc[0]['matched_control_rows_N'])} pair-weighted control rows but only "
        f"{int(matching_audit.iloc[0]['unique_controls_N'])} unique control sources. "
        f"{int(matching_audit.iloc[0]['controls_reused_N'])} controls are reused, with a maximum reuse count of "
        f"{int(matching_audit.iloc[0]['maximum_reuse_count'])}. The median absolute X-ray-component difference is "
        f"{matching_audit.iloc[0]['median_abs_delta_S_X']:.4f}.",
        "",
        markdown_table(matching_balance[["feature_label", "group_a_median", "group_b_median", "standardized_mean_difference", "ks_p_two_sided"]]),
        "",
        markdown_table(matching_scores),
        "",
        markdown_table(matching_wins[["score_variant", "matched_pair_rows_N", "pairwise_win_fraction", "ci95_low", "ci95_high", "signflip_p_two_sided"]]),
        "",
        "Pair-weighted X-ray balance is good, while redshift, peak proxy, and component count remain imbalanced. "
        "The within-pair win analysis finds no robust positive full-score or no-X-ray separation at fixed X-ray brightness; "
        "the X-ray-only win fraction is above 0.5 but its clustered interval includes the null. Because controls are reused, "
        "the original 204-row AUROC must be labelled pair-weighted and should not be described as 170 independent controls. "
        "This audit is conditional on X-ray brightness, not a fully multivariable causal comparison.",
        "",
        "## Manuscript-level interpretation",
        "",
        "1. Keep the central X-ray-gateway claim, but explicitly add multiwavelength coverage as a historical-selection axis.",
        "2. State that the nominal radio term is inactive in the frozen score because the robust MAD is zero.",
        "3. Add the random-shift audit to the cross-match robustness paragraph and Appendix.",
        "4. Add the >=7-component sensitivity as the primary coverage-controlled retrospective result.",
        "5. State that 170 matched control rows represent 98 unique sources and report the clustered within-pair analysis.",
        "6. Do not call the X-ray-matched set a fully balanced multivariable control sample.",
    ]
    (DOCS / "scientific_hardening_report_v0_4_2.md").write_text("\n".join(report), encoding="utf-8")

    latex = rf"""
% ------------------------------------------------------------------
% v0.4.2 scientific-hardening integration draft
% ------------------------------------------------------------------
\subsection{{Exact score specification and component coverage}}
The additive branch coordinate was reconstructed from the frozen component columns with a maximum absolute discrepancy of
${reconstruction.iloc[0]['max_abs_delta_published_minus_reconstructed']:.2e}$ relative to the released score.  Table~\ref{{tab:exact_score_definition_v042}}
reports the fixed weights, signs, availability, transformations, and robust standardisation constants.  The nominal radio-compactness
term is numerically inactive in the frozen catalogue because its pre-standardisation median absolute deviation is zero; its standardized
value is therefore identically zero.  We retain this term in the provenance layer for exact backward reconstruction, but do not attribute
physical leverage to it.

Feature availability is itself strongly associated with historical TeV identification.  All 34 TeVCat matches have seven or eight available
score components, and component count alone gives AUROC={coverage_auc:.3f}.  The full score correlates with component count at
$\rho={score_rho:.3f}$.  This does not invalidate the branch analysis, but it demonstrates that unrestricted retrospective enrichment combines
source physics with the denser multiwavelength characterization of historically targeted objects.  When the analysis is restricted to sources
with at least seven components, the X-ray-only, full, and no-X-ray AUROCs remain ordered in the same direction, with values
{high_cov.set_index('score_variant').loc['xray_only','AUROC']:.3f}, {high_cov.set_index('score_variant').loc['full','AUROC']:.3f}, and
{high_cov.set_index('score_variant').loc['no_xray','AUROC']:.3f}, respectively.

\subsection{{Random-shift cross-match and matched-control audits}}
At the adopted 180-arcsec TeVCat radius, the observed catalogue contains {int(adopted['observed_parent_matches'])} associations.  In
{int(adopted['random_draws_N'])} random local angular shifts of the TeVCat positions, the median chance-match count is
{adopted['random_median_matches']:.1f}, the 97.5th percentile is {adopted['random_q97p5_matches']:.0f}, and the maximum is
{int(adopted['random_max_matches'])}.  The empirical probability of obtaining the observed count or more is
${adopted['empirical_p_random_ge_observed']:.3g}$.  Random superposition is therefore unlikely to explain the validation sample, although
this test does not remove TeVCat's non-uniform exposure and targeting history.

The X-ray-matched audit uses five nearest non-TeV neighbours per known TeV object, yielding
{int(matching_audit.iloc[0]['matched_control_rows_N'])} matched control rows that represent {int(matching_audit.iloc[0]['unique_controls_N'])} unique sources.
Control reuse is therefore retained explicitly rather than treated as independent sampling.  The median $|\Delta S_X|$ is
{matching_audit.iloc[0]['median_abs_delta_S_X']:.3f}.  A known-source-clustered within-pair analysis gives win fractions of
{matching_wins.set_index('score_variant').loc['full','pairwise_win_fraction']:.3f} for the full score,
{matching_wins.set_index('score_variant').loc['xray_only','pairwise_win_fraction']:.3f} for X-ray only, and
{matching_wins.set_index('score_variant').loc['no_xray','pairwise_win_fraction']:.3f} without X-rays; none establishes robust positive
separation at fixed X-ray brightness.  Redshift and peak-proxy balance are not imposed and remain imperfect, so this is not interpreted as a fully multivariable causal match.
"""
    (DOCS / "latex_scientific_hardening_v0_4_2.tex").write_text(latex.strip() + "\n", encoding="utf-8")

    print("Wrote docs/scientific_hardening_report_v0_4_2.md")
    print("Wrote docs/latex_scientific_hardening_v0_4_2.tex")


if __name__ == "__main__":
    main()
