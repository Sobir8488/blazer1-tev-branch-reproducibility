#!/usr/bin/env python
"""
v0.1.7 proxy-scope and claim-language audit.

This script addresses three reviewer-facing risks:
1) The radio term is a radio-compactness proxy, not a homogeneous VLASS morphology layer.
2) The synchrotron-peak proxy is mixed-source and must not be treated as a uniform direct measurement.
3) The score is an empirical diagnostic score, not a calibrated physical TeV-detection probability.

Outputs
-------
- tables/table_radio_proxy_scope_audit_v0_1_7.csv/.tex
- tables/table_nu_peak_proxy_method_counts_v0_1_7.csv/.tex
- tables/table_score_claim_gate_v0_1_7.csv/.tex
- docs/latex_snippets_claim_scope_v0_1_7.tex
"""
from __future__ import annotations

from pathlib import Path
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
TABLES = ROOT / "tables"
DOCS = ROOT / "docs"
PROCESSED = ROOT / "data" / "processed"
RAW = ROOT / "data" / "raw"


def read_score():
    for p in [
        PROCESSED / "tev_evolution_score_catalog_v0_1_6_branch_augmented.csv",
        PROCESSED / "tev_evolution_score_catalog_v0_1_5_augmented.csv",
        PROCESSED / "tev_evolution_score_catalog.csv",
    ]:
        if p.exists():
            return pd.read_csv(p, low_memory=False)
    raise FileNotFoundError("No score catalogue found in data/processed")


def clean_str(x):
    if pd.isna(x):
        return np.nan
    s = str(x).strip()
    if s.startswith("b'") and s.endswith("'"):
        s = s[2:-1]
    if s.startswith('b"') and s.endswith('"'):
        s = s[2:-1]
    if s in {"", "-", "nan", "NaN", "None", "NONE", "b'-'", "b'nan'"}:
        return np.nan
    return s


def simple_latex(df: pd.DataFrame, caption: str, label: str, path: Path):
    text = "\\begin{table*}\n\\centering\n"
    text += df.to_latex(index=False, escape=False)
    text += f"\\caption{{{caption}}}\n\\label{{{label}}}\n\\end{{table*}}\n"
    path.write_text(text, encoding="utf-8")


def main():
    TABLES.mkdir(exist_ok=True, parents=True)
    DOCS.mkdir(exist_ok=True, parents=True)
    df = read_score()
    n = len(df)

    # Radio/VLASS scope audit.
    vlass_file = RAW / "vlass" / "vlass_crossmatch.csv"
    vlass_cols = [c for c in df.columns if "vlass" in c.lower()]
    radio_cols = [c for c in df.columns if "radio" in c.lower() or "mojave" in c.lower() or "tanami" in c.lower() or "rfc" in c.lower() or "xie_morph" in c.lower()]
    radio_available = pd.Series(False, index=df.index)
    for c in ["radio_feature_available", "radio_compactness", "S_R"]:
        if c in df.columns:
            if c == "radio_feature_available":
                radio_available = radio_available | df[c].astype(str).str.lower().isin(["true", "1", "yes", "y"])
            else:
                radio_available = radio_available | pd.to_numeric(df[c], errors="coerce").notna()

    radio_audit = pd.DataFrame([
        {
            "audit_item": "External VLASS cross-match file",
            "status": "FOUND" if vlass_file.exists() else "NOT_FOUND",
            "evidence": str(vlass_file) if vlass_file.exists() else "data/raw/vlass/vlass_crossmatch.csv not present",
            "allowed_claim": "VLASS morphology may be discussed only if this file is documented and used" if vlass_file.exists() else "Do not claim homogeneous VLASS morphology; use radio-compactness proxy language",
        },
        {
            "audit_item": "VLASS-named columns in score catalogue",
            "status": "FOUND" if vlass_cols else "NOT_FOUND",
            "evidence": "; ".join(vlass_cols[:20]) if vlass_cols else "no column names containing VLASS/vlass",
            "allowed_claim": "Audit these columns before claiming VLASS morphology" if vlass_cols else "No VLASS-specific morphology claim",
        },
        {
            "audit_item": "Radio-proxy columns available",
            "status": "FOUND" if radio_cols else "NOT_FOUND",
            "evidence": "; ".join(radio_cols[:30]) if radio_cols else "no radio-proxy columns detected",
            "allowed_claim": "Radio compactness proxy; not a homogeneous morphology measurement",
        },
        {
            "audit_item": "Radio-feature coverage",
            "status": "QUANTIFIED",
            "evidence": f"{int(radio_available.sum())}/{n} sources ({radio_available.mean():.3f}) with a radio proxy or S_R value",
            "allowed_claim": "Coverage-limited radio-compactness proxy",
        },
    ])
    radio_audit.to_csv(TABLES / "table_radio_proxy_scope_audit_v0_1_7.csv", index=False)
    simple_latex(radio_audit, "Radio and VLASS claim-scope audit.", "tab:radio_proxy_scope", TABLES / "table_radio_proxy_scope_audit_v0_1_7.tex")

    # Synchrotron-peak proxy method counts.
    if "log_nu_peak_proxy_method" in df.columns:
        method = df["log_nu_peak_proxy_method"].map(clean_str).fillna("missing")
    elif "sed_class_proxy" in df.columns:
        method = df["sed_class_proxy"].map(clean_str).fillna("missing_proxy_method")
    else:
        method = pd.Series("missing", index=df.index)
    counts = method.value_counts(dropna=False).rename_axis("nu_peak_proxy_method").reset_index(name="N")
    counts["fraction"] = counts["N"] / n
    counts.to_csv(TABLES / "table_nu_peak_proxy_method_counts_v0_1_7.csv", index=False)
    fmt_counts = counts.copy()
    fmt_counts["fraction"] = fmt_counts["fraction"].map(lambda x: f"{x:.3f}")
    simple_latex(fmt_counts, "Synchrotron-peak proxy source distribution. Mixed proxy sources explain horizontal structures in peak-frequency figures.", "tab:nu_peak_proxy_methods", TABLES / "table_nu_peak_proxy_method_counts_v0_1_7.tex")

    # Score interpretation claim gate.
    claim_gate = pd.DataFrame([
        {
            "topic": "Score meaning",
            "unsafe_wording": "TeV probability; physical probability of detection",
            "safe_wording": "Empirical, physically interpretable TeV-favourability diagnostic score",
            "status": "REQUIRED",
        },
        {
            "topic": "Evolution",
            "unsafe_wording": "Direct proof that individual FSRQs evolve into TeV HSP BL Lacs",
            "safe_wording": "Population-level ordered TeV-favourable branch or demographic sequence",
            "status": "REQUIRED",
        },
        {
            "topic": "Radio layer",
            "unsafe_wording": "Homogeneous VLASS morphology measurement",
            "safe_wording": "Coverage-limited radio-compactness proxy unless an external VLASS layer is added",
            "status": "REQUIRED",
        },
        {
            "topic": "Synchrotron peak",
            "unsafe_wording": "Uniform measured synchrotron peak frequency for all sources",
            "safe_wording": "Mixed-source synchrotron-peak proxy; horizontal bands are proxy artefacts",
            "status": "REQUIRED",
        },
        {
            "topic": "TeV validation",
            "unsafe_wording": "The Gold non-TeV sources are detections",
            "safe_wording": "The Gold non-TeV sources are high-priority follow-up candidates",
            "status": "REQUIRED",
        },
    ])
    claim_gate.to_csv(TABLES / "table_score_claim_gate_v0_1_7.csv", index=False)
    simple_latex(claim_gate, "Claim-gating table used to keep the interpretation empirical and non-circular.", "tab:score_claim_gate", TABLES / "table_score_claim_gate_v0_1_7.tex")

    snippet = r'''
% v0.1.7 claim-scope snippets for manuscript insertion

\paragraph{Radio-compactness scope.}
The radio term used in $S_{\rm TeV,evo}$ is a coverage-limited radio-compactness proxy based on the radio and VLBI-related information available in the standardized BlazEr1 table.  It is not treated as a homogeneous VLASS morphology measurement.  We therefore refer to this term as a radio-compactness proxy throughout the paper and reserve any VLASS-specific morphological claim for a future analysis with an explicitly documented VLASS cross-match layer.

\paragraph{Synchrotron-peak proxy scope.}
The synchrotron-peak term is a mixed-source proxy constructed from available SED-class, catalogue, and broad-band information.  Horizontal structures in $\log\nu_{\rm peak}$ diagrams reflect this proxy construction and must not be interpreted as intrinsic quantisation of synchrotron peak frequencies.  The proxy is used as a population diagnostic of HSP-like behaviour, not as a uniform direct measurement for every source.

\paragraph{Empirical-score interpretation.}
The score is an empirical, physically interpretable diagnostic of TeV favourability.  It is not a calibrated TeV-detection probability and should not be used as a substitute for spectral modelling, EBL-corrected flux extrapolation, or CTAO sensitivity calculations.  The score is used to identify a population-level TeV-favourable branch and to rank follow-up targets.

\paragraph{Caption addition for $\log\nu_{\rm peak}$ figures.}
The dashed HSP threshold and the horizontal bands should be interpreted in the context of the mixed proxy construction of $\log\nu_{\rm peak}$; they are not evidence for intrinsically discrete synchrotron-peak frequencies.
'''
    (DOCS / "latex_snippets_claim_scope_v0_1_7.tex").write_text(snippet.strip() + "\n", encoding="utf-8")

    print("v0.1.7 proxy-scope and claim audit complete.")
    print("Radio/VLASS scope audit:")
    print(radio_audit.to_string(index=False))
    print("\nSynchrotron-peak proxy methods:")
    print(counts.to_string(index=False))
    print("\nClaim gate:")
    print(claim_gate.to_string(index=False))


if __name__ == "__main__":
    main()
