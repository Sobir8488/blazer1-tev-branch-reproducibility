#!/usr/bin/env python
from __future__ import annotations
import os
import json
import numpy as np
import pandas as pd
from _v044_helpers import *


def tier_validation(df: pd.DataFrame, score_col: str, tier_col: str, label: str) -> pd.DataFrame:
    valid=numeric(df[score_col]).notna(); d=df.loc[valid].copy(); y=d["is_known_tev"].astype(bool); N=len(d); K=int(y.sum()); rows=[]
    sets=[("Gold",{"Gold"}),("Gold+Silver",{"Gold","Silver"}),("Gold+Silver+Bronze",{"Gold","Silver","Bronze"})]
    for name,allowed in sets:
        m=d[tier_col].astype(str).isin(allowed); n=int(m.sum()); k=int((m&y).sum()); wlo,whi=wilson_interval(k,K); jlo,jhi=jeffreys_interval(k,K)
        rows.append({"score_variant":label,"tier_set":name,"analysis_N":N,"known_TeV_N":K,"tier_N":n,"tier_fraction":n/N,"recovered_N":k,"recovery_fraction":k/K if K else np.nan,"wilson95_low":wlo,"wilson95_high":whi,"jeffreys95_low":jlo,"jeffreys95_high":jhi,"enrichment":(k/K)/(n/N) if K and n else np.nan,"hypergeom_p_greater":hypergeom_p(N,K,n,k),"AUROC":auc_rank(y.to_numpy(),numeric(d[score_col]).to_numpy())})
    return pd.DataFrame(rows)


def radius_sensitivity(df: pd.DataFrame) -> pd.DataFrame:
    if "tevcat_sep_arcsec" not in df:
        return pd.DataFrame()
    sep=numeric(df["tevcat_sep_arcsec"]); score=numeric(df["S_TeV_branch_active_v0_4_4"]); tier=df["tier_active_v0_4_4"].astype(str); valid=score.notna(); rows=[]
    for radius in [60.,90.,120.,180.]:
        y=(sep<=radius)&sep.notna(); d=df.loc[valid].copy(); yy=y.loc[valid].to_numpy(bool); N=len(d); K=int(yy.sum())
        for name,allowed in [("Gold",{"Gold"}),("Gold+Silver",{"Gold","Silver"})]:
            m=tier.loc[valid].isin(allowed).to_numpy(); n=int(m.sum()); k=int((m&yy).sum())
            rows.append({"radius_arcsec":radius,"tier_set":name,"analysis_N":N,"known_TeV_N":K,"tier_N":n,"recovered_N":k,"recovery_fraction":k/K if K else np.nan,"enrichment":(k/K)/(n/N) if K and n else np.nan,"hypergeom_p_greater":hypergeom_p(N,K,n,k),"AUROC":auc_rank(yy,score.loc[valid].to_numpy())})
    return pd.DataFrame(rows)



def active_xray_matched_audit(df: pd.DataFrame, n_boot: int, seed: int) -> tuple[pd.DataFrame,pd.DataFrame]:
    path=TABLES/"table_xray_matched_pairs_v0_4_2.csv"
    if not path.exists(): return pd.DataFrame(),pd.DataFrame()
    pairs=pd.read_csv(path)
    active=numeric(df["S_TeV_branch_active_v0_4_4"])
    pairs["known_active_score"]=pairs["known_index"].astype(int).map(active)
    pairs["control_active_score"]=pairs["control_index"].astype(int).map(active)
    pairs["known_minus_control_active"]=pairs["known_active_score"]-pairs["control_active_score"]
    pairs["win_active"]=(pairs["known_minus_control_active"]>0).astype(float)
    pairs.to_csv(TABLES/"table_active_xray_matched_pairs_v0_4_4.csv",index=False)
    known_ids=sorted(pairs["known_index"].astype(int).unique()); control_rows=pairs["control_index"].astype(int).tolist(); unique_controls=sorted(set(control_rows))
    rows=[]
    for rep,controls in [("pair_weighted_with_replacement",control_rows),("unique_control_sensitivity",unique_controls)]:
        ks=active.loc[known_ids].to_numpy(float); cs=active.loc[controls].to_numpy(float); y=np.r_[np.ones(len(ks),bool),np.zeros(len(cs),bool)]; sc=np.r_[ks,cs]
        rows.append({"control_representation":rep,"score_variant":"active_full","analysis_N":len(sc),"known_TeV_N":len(ks),"control_rows_N":len(cs),"unique_control_sources_N":len(unique_controls),"AUROC_known_vs_control":auc_rank(y,sc),"median_known":float(np.nanmedian(ks)),"median_control":float(np.nanmedian(cs))})
    metrics=pd.DataFrame(rows); metrics.to_csv(TABLES/"table_active_xray_matched_score_metrics_v0_4_4.csv",index=False)
    g=pairs.groupby("known_index")["win_active"].mean(); est=float(pairs["win_active"].mean()); rng=np.random.default_rng(seed); vals=[]
    ids=g.index.to_numpy()
    for _ in range(n_boot): vals.append(float(g.loc[rng.choice(ids,len(ids),replace=True)].mean()))
    # cluster-level sign flip of mean pair differences
    means=pairs.groupby("known_index")["known_minus_control_active"].mean().to_numpy(); obs=abs(float(np.mean(means))); n_perm=min(max(n_boot,1000),200000); null=[]
    for _ in range(n_perm): null.append(abs(float(np.mean(means*rng.choice([-1,1],len(means))))))
    pval=(np.sum(np.asarray(null)>=obs)+1)/(len(null)+1)
    pair_summary=pd.DataFrame([{"score_variant":"active_full","matched_pair_rows_N":len(pairs),"pairwise_win_fraction":est,"cluster_N":len(g),"cluster_bootstrap_ci95_low":float(np.percentile(vals,2.5)),"cluster_bootstrap_ci95_high":float(np.percentile(vals,97.5)),"cluster_signflip_p_two_sided":float(pval),"null_value":0.5,"matching_replacement_rule":"nearest-neighbour matching with replacement; 170 pair rows from 98 unique controls"}])
    pair_summary.to_csv(TABLES/"table_active_xray_matched_pairwise_v0_4_4.csv",index=False)
    return metrics,pair_summary

def main():
    df,source=load_active_catalogue(); df=add_primary_columns(df)
    out=PROCESSED/"tev_evolution_score_catalog_v0_4_4_active_primary.csv"; df.to_csv(out,index=False)

    val=tier_validation(df,"S_TeV_branch_active_v0_4_4","tier_active_v0_4_4","active_primary")
    legacy=tier_validation(df,"S_arch_published_available_v0_4_3","tier_arch_published_available_v0_4_3","published_legacy")
    pd.concat([val,legacy],ignore_index=True).to_csv(TABLES/"table_active_primary_validation_v0_4_4.csv",index=False)

    nboot=int(os.getenv("BLAZER_V044_N_BOOT","5000")); seed=int(os.getenv("BLAZER_V044_SEED","8488"))
    y=df["is_known_tev"].to_numpy(bool)
    scores={"active_full":numeric(df["S_TeV_branch_active_v0_4_4"]).to_numpy(),"xray_only":numeric(df["S_xray_only_v0_1_8"]).to_numpy(),"no_xray":numeric(df["S_no_xray_v0_1_8"]).to_numpy()}
    comps=[("xray_only","active_full"),("active_full","no_xray"),("xray_only","no_xray")]
    draws,summary=paired_stratified_bootstrap(y,scores,comps,nboot,seed)
    draws.to_csv(TABLES/"table_active_harmonized_bootstrap_draws_v0_4_4.csv",index=False); summary.to_csv(TABLES/"table_active_harmonized_auc_v0_4_4.csv",index=False)
    common=np.ones(len(y),dtype=bool)
    for arr in scores.values(): common &= np.isfinite(arr)
    yc=y[common]; sc={k:v[common] for k,v in scores.items()}
    drows=[]
    for a,b in comps:
        r=delong_pair(yc,sc[a],sc[b]); r.update({"model_a":a,"model_b":b,"analysis_population":"single_common_complete_case_population"}); drows.append(r)
    delong=pd.DataFrame(drows); delong.to_csv(TABLES/"table_active_harmonized_delong_v0_4_4.csv",index=False)

    rad=radius_sensitivity(df); rad.to_csv(TABLES/"table_active_tevcat_radius_sensitivity_v0_4_4.csv",index=False)
    matched_metrics,matched_pairs=active_xray_matched_audit(df,nboot,seed)
    decision={"primary_score":"S_TeV_branch_active_v0_4_4","source_column":"S_arch_active_available_v0_4_3","legacy_score":"S_arch_published_available_v0_4_3","inactive_component_removed":"radio_compactness","primary_selection_rationale":"mathematical activity gate, not TeVCat-label performance","catalogue_source":str(source),"catalogue_output":str(out),"bootstrap_draws":nboot,"seed":seed}
    (METADATA/"active_primary_score_decision_v0_4_4.json").write_text(json.dumps(decision,indent=2),encoding="utf-8")

    print("v0.4.4 active primary catalogue and validation complete.")
    print(f"Active catalogue: {out}")
    print("\nPrimary validation:")
    print(val.to_string(index=False))
    print("\nHarmonized AUROC:")
    print(summary.to_string(index=False))
    print("\nDeLong:")
    print(delong[["model_a","model_b","auc_a","auc_b","delta_auc","p_two_sided","N","N_pos"]].to_string(index=False))
    if not matched_metrics.empty:
        print("\nActive-score X-ray-matched audit:"); print(matched_metrics.to_string(index=False)); print(matched_pairs.to_string(index=False))

if __name__=="__main__": main()
