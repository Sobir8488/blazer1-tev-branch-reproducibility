from __future__ import annotations

from pathlib import Path
import math
import numpy as np
import pandas as pd

from scipy.stats import beta, norm, rankdata, spearmanr

ROOT = Path(__file__).resolve().parents[1]
PROCESSED = ROOT / "data" / "processed"
TABLES = ROOT / "tables"
FIGURES = ROOT / "figures"
DOCS = ROOT / "docs"
for p in (PROCESSED, TABLES, FIGURES, DOCS):
    p.mkdir(parents=True, exist_ok=True)

COMPONENTS = {
    "xray_brightness": ("S_X", +1.0, 1.00),
    "gamma_hardness": ("S_gamma_hard", +1.0, 1.00),
    "gamma_variability": ("S_gamma_var", +1.0, 0.35),
    "wise_hsp_locus": ("S_IR", +1.0, 0.75),
    "radio_compactness": ("S_R", +1.0, 0.75),
    "synchrotron_peak_proxy": ("S_nu_peak", +1.0, 1.00),
    "compton_dominance_penalty": ("S_CD_penalty", -1.0, 0.60),
    "ebl_penalty": ("S_EBL_proxy", -1.0, 0.80),
}


def numeric(s: pd.Series) -> pd.Series:
    return pd.to_numeric(s, errors="coerce").replace([np.inf, -np.inf], np.nan)


def robust_zscore(s: pd.Series) -> pd.Series:
    x = numeric(s)
    med = x.median(skipna=True)
    mad = (x - med).abs().median(skipna=True)
    if pd.isna(mad) or mad == 0:
        return (x - med) * 0.0
    return (x - med) / (1.4826 * mad)


def as_bool(s: pd.Series) -> pd.Series:
    if s.dtype == bool:
        return s.fillna(False)
    return s.astype(str).str.strip().str.lower().isin({"1", "true", "t", "yes", "y"})


def load_v018_catalogue() -> tuple[pd.DataFrame, Path]:
    candidates = [
        PROCESSED / "tev_evolution_score_catalog_v0_1_8_xray_control_augmented.csv",
        PROCESSED / "tev_evolution_score_catalog_v0_1_8_interpretability_augmented.csv",
        PROCESSED / "tev_evolution_score_catalog_v0_1_7_review_defence_augmented.csv",
        PROCESSED / "tev_evolution_score_catalog_v0_1_6_branch_augmented.csv",
        PROCESSED / "tev_evolution_score_catalog.csv",
    ]
    for path in candidates:
        if path.exists():
            df = pd.read_csv(path, low_memory=False)
            if "is_known_tev" in df:
                df["is_known_tev"] = as_bool(df["is_known_tev"])
            elif "tevcat_matched" in df:
                df["is_known_tev"] = as_bool(df["tevcat_matched"])
            else:
                raise KeyError("No TeV validation label found.")
            return df, path
    raise FileNotFoundError("No frozen score catalogue found in data/processed.")


def score_from_components(df: pd.DataFrame, peak_override: pd.Series | None = None, exclude: set[str] | None = None) -> pd.Series:
    exclude = exclude or set()
    total = pd.Series(0.0, index=df.index, dtype=float)
    denom = pd.Series(0.0, index=df.index, dtype=float)
    for key, (col, sign, weight) in COMPONENTS.items():
        if key in exclude:
            continue
        if key == "synchrotron_peak_proxy" and peak_override is not None:
            x = numeric(peak_override)
        elif col in df.columns:
            x = numeric(df[col])
        else:
            continue
        valid = x.notna()
        total.loc[valid] += sign * weight * x.loc[valid]
        denom.loc[valid] += abs(weight)
    return total / denom.replace(0, np.nan)


def assign_tier(score: pd.Series) -> pd.Series:
    s = numeric(score)
    valid = s.dropna()
    tier = pd.Series("Low-priority", index=s.index, dtype="object")
    if valid.empty:
        return tier
    q70, q85, q95 = np.nanpercentile(valid, [70, 85, 95])
    tier.loc[s >= q70] = "Bronze"
    tier.loc[s >= q85] = "Silver"
    tier.loc[s >= q95] = "Gold"
    return tier


def percentile_rank(score: pd.Series) -> pd.Series:
    s = numeric(score)
    return s.rank(method="average", pct=True) * 100.0


def auc_rank(y: np.ndarray, score: np.ndarray) -> float:
    y = np.asarray(y, dtype=bool)
    score = np.asarray(score, dtype=float)
    mask = np.isfinite(score)
    y, score = y[mask], score[mask]
    n1 = int(y.sum())
    n0 = int((~y).sum())
    if n1 == 0 or n0 == 0:
        return float("nan")
    ranks = rankdata(score, method="average")
    u = ranks[y].sum() - n1 * (n1 + 1) / 2.0
    return float(u / (n1 * n0))


def wilson_interval(k: int, n: int, alpha: float = 0.05) -> tuple[float, float]:
    if n <= 0:
        return float("nan"), float("nan")
    z = norm.ppf(1 - alpha / 2)
    p = k / n
    den = 1 + z*z/n
    centre = (p + z*z/(2*n)) / den
    half = z * math.sqrt(p*(1-p)/n + z*z/(4*n*n)) / den
    return max(0.0, centre-half), min(1.0, centre+half)


def jeffreys_interval(k: int, n: int, alpha: float = 0.05) -> tuple[float, float]:
    if n <= 0:
        return float("nan"), float("nan")
    lo = beta.ppf(alpha/2, k + 0.5, n - k + 0.5)
    hi = beta.ppf(1-alpha/2, k + 0.5, n - k + 0.5)
    return float(lo), float(hi)


def _midrank(x: np.ndarray) -> np.ndarray:
    order = np.argsort(x)
    sorted_x = x[order]
    n = len(x)
    out = np.empty(n, dtype=float)
    i = 0
    while i < n:
        j = i
        while j < n and sorted_x[j] == sorted_x[i]:
            j += 1
        out[i:j] = 0.5 * (i + j - 1) + 1.0
        i = j
    result = np.empty(n, dtype=float)
    result[order] = out
    return result


def fast_delong(predictions_sorted_transposed: np.ndarray, label_1_count: int) -> tuple[np.ndarray, np.ndarray]:
    m = label_1_count
    n = predictions_sorted_transposed.shape[1] - m
    pos = predictions_sorted_transposed[:, :m]
    neg = predictions_sorted_transposed[:, m:]
    k = predictions_sorted_transposed.shape[0]
    tx = np.empty((k, m), dtype=float)
    ty = np.empty((k, n), dtype=float)
    tz = np.empty((k, m+n), dtype=float)
    for r in range(k):
        tx[r] = _midrank(pos[r])
        ty[r] = _midrank(neg[r])
        tz[r] = _midrank(predictions_sorted_transposed[r])
    aucs = tz[:, :m].sum(axis=1) / (m*n) - (m+1.0)/(2.0*n)
    v01 = (tz[:, :m] - tx) / n
    v10 = 1.0 - (tz[:, m:] - ty) / m
    sx = np.atleast_2d(np.cov(v01, bias=False))
    sy = np.atleast_2d(np.cov(v10, bias=False))
    cov = sx/m + sy/n
    return aucs, cov


def delong_pair(y: np.ndarray, score_a: np.ndarray, score_b: np.ndarray) -> dict:
    y = np.asarray(y, dtype=bool)
    a = np.asarray(score_a, dtype=float)
    b = np.asarray(score_b, dtype=float)
    mask = np.isfinite(a) & np.isfinite(b)
    y, a, b = y[mask], a[mask], b[mask]
    order = np.argsort(~y)  # positives first
    preds = np.vstack([a[order], b[order]])
    m = int(y.sum())
    if m < 2 or len(y)-m < 2:
        return {"auc_a": np.nan, "auc_b": np.nan, "delta_auc": np.nan, "se_delta": np.nan, "z": np.nan, "p_two_sided": np.nan, "N": len(y), "N_pos": m}
    aucs, cov = fast_delong(preds, m)
    contrast = np.array([1.0, -1.0])
    var = float(contrast @ cov @ contrast.T)
    se = math.sqrt(max(var, 0.0))
    delta = float(aucs[0] - aucs[1])
    z = delta / se if se > 0 else np.nan
    p = 2 * norm.sf(abs(z)) if np.isfinite(z) else np.nan
    return {"auc_a": float(aucs[0]), "auc_b": float(aucs[1]), "delta_auc": delta, "se_delta": se, "z": z, "p_two_sided": float(p), "N": len(y), "N_pos": m}


def paired_stratified_bootstrap(y: np.ndarray, scores: dict[str, np.ndarray], comparisons: list[tuple[str, str]], n_boot: int = 5000, seed: int = 8488) -> tuple[pd.DataFrame, pd.DataFrame]:
    y = np.asarray(y, dtype=bool)
    all_arrays = {k: np.asarray(v, dtype=float) for k, v in scores.items()}
    # use rows finite for every supplied model so all comparisons are paired on one population
    common = np.ones(len(y), dtype=bool)
    for arr in all_arrays.values():
        common &= np.isfinite(arr)
    y = y[common]
    all_arrays = {k: v[common] for k, v in all_arrays.items()}
    pos = np.flatnonzero(y)
    neg = np.flatnonzero(~y)
    if len(pos) < 2 or len(neg) < 2:
        raise ValueError("Bootstrap requires at least two positive and negative cases.")
    rng = np.random.default_rng(seed)
    rows = []
    for i in range(n_boot):
        idx = np.concatenate([
            rng.choice(pos, size=len(pos), replace=True),
            rng.choice(neg, size=len(neg), replace=True),
        ])
        yy = y[idx]
        aucs = {name: auc_rank(yy, arr[idx]) for name, arr in all_arrays.items()}
        row = {"draw": i, **{f"auc_{k}": v for k, v in aucs.items()}}
        for a, b in comparisons:
            row[f"delta_{a}_minus_{b}"] = aucs[a] - aucs[b]
        rows.append(row)
    draws = pd.DataFrame(rows)
    summaries = []
    for name in all_arrays:
        vals = draws[f"auc_{name}"].to_numpy()
        summaries.append({
            "quantity": f"AUROC {name}", "estimate": auc_rank(y, all_arrays[name]),
            "bootstrap_median": float(np.nanmedian(vals)), "ci95_low": float(np.nanpercentile(vals, 2.5)),
            "ci95_high": float(np.nanpercentile(vals, 97.5)), "p_two_sided": np.nan,
            "N": len(y), "N_pos": int(y.sum()), "n_boot": n_boot,
        })
    for a, b in comparisons:
        col = f"delta_{a}_minus_{b}"
        vals = draws[col].to_numpy()
        p_lo = (np.sum(vals <= 0) + 1) / (len(vals) + 1)
        p_hi = (np.sum(vals >= 0) + 1) / (len(vals) + 1)
        summaries.append({
            "quantity": f"Delta AUROC {a} - {b}", "estimate": auc_rank(y, all_arrays[a]) - auc_rank(y, all_arrays[b]),
            "bootstrap_median": float(np.nanmedian(vals)), "ci95_low": float(np.nanpercentile(vals, 2.5)),
            "ci95_high": float(np.nanpercentile(vals, 97.5)), "p_two_sided": float(min(1.0, 2*min(p_lo, p_hi))),
            "N": len(y), "N_pos": int(y.sum()), "n_boot": n_boot,
        })
    return draws, pd.DataFrame(summaries)


def partial_spearman(x: pd.Series, y: pd.Series, z: pd.Series) -> tuple[float, float, int]:
    data = pd.DataFrame({"x": numeric(x), "y": numeric(y), "z": numeric(z)}).dropna()
    if len(data) < 5:
        return np.nan, np.nan, len(data)
    for col in ("x", "y", "z"):
        data[col] = data[col].rank(method="average")
    A = np.column_stack([np.ones(len(data)), data["z"].to_numpy()])
    bx, *_ = np.linalg.lstsq(A, data["x"].to_numpy(), rcond=None)
    by, *_ = np.linalg.lstsq(A, data["y"].to_numpy(), rcond=None)
    rx = data["x"].to_numpy() - A @ bx
    ry = data["y"].to_numpy() - A @ by
    rho, p = spearmanr(rx, ry)
    return float(rho), float(p), len(data)


def source_name(df: pd.DataFrame) -> pd.Series:
    for c in ("SRC_NAME", "catalogue_name", "source_name", "FGL_SRC_NAME", "HSP_SRC_NAME"):
        if c in df.columns:
            return df[c].astype(str).str.replace(r"^b['\"]|['\"]$", "", regex=True)
    return pd.Series([f"row_{i}" for i in df.index], index=df.index)
