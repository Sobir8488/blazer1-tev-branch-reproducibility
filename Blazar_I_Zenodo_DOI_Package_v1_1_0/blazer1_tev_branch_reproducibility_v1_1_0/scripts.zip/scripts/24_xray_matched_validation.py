from __future__ import annotations

import sys
from pathlib import Path
sys.path.append(str(Path(__file__).resolve().parent))

import numpy as np
import pandas as pd
from scipy.stats import mannwhitneyu
from _v018_helpers import TABLES, DOCS, PROCESSED, COMPONENTS, clean_numeric, load_score_catalogue, compute_score_from_components, assign_tiers, metrics_for_score, auroc_from_scores, residualize


def add_score_variants(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    out['S_full_recomputed_v0_1_8'] = compute_score_from_components(out)
    out['S_xray_only_v0_1_8'] = compute_score_from_components(out, only={'xray_brightness'})
    out['S_no_xray_v0_1_8'] = compute_score_from_components(out, exclude={'xray_brightness'})
    if 'S_X' in out.columns:
        out['S_full_residual_after_xray_v0_1_8'] = residualize(out['S_TeV_evo'], out[['S_X']])
        out['S_no_xray_residual_after_xray_v0_1_8'] = residualize(out['S_no_xray_v0_1_8'], out[['S_X']])
    else:
        out['S_full_residual_after_xray_v0_1_8'] = np.nan
        out['S_no_xray_residual_after_xray_v0_1_8'] = np.nan
    for score_col, prefix in [
        ('S_full_recomputed_v0_1_8','full_recomputed'),
        ('S_xray_only_v0_1_8','xray_only'),
        ('S_no_xray_v0_1_8','no_xray'),
        ('S_full_residual_after_xray_v0_1_8','full_resid_xray'),
        ('S_no_xray_residual_after_xray_v0_1_8','no_xray_resid_xray'),
    ]:
        out = assign_tiers(out, score_col, prefix=prefix)
    return out


def score_variant_metrics(df: pd.DataFrame) -> pd.DataFrame:
    variants = [
        ('published_full_score','S_TeV_evo','tev_priority_tier'),
        ('full_recomputed','S_full_recomputed_v0_1_8','full_recomputed_tier'),
        ('xray_only','S_xray_only_v0_1_8','xray_only_tier'),
        ('no_xray','S_no_xray_v0_1_8','no_xray_tier'),
        ('full_residual_after_xray','S_full_residual_after_xray_v0_1_8','full_resid_xray_tier'),
        ('no_xray_residual_after_xray','S_no_xray_residual_after_xray_v0_1_8','no_xray_resid_xray_tier'),
    ]
    rows = []
    for label, score_col, tier_col in variants:
        rows.append(metrics_for_score(df, score_col, tier_col, label))
    return pd.DataFrame(rows)


def xray_decile_table(df: pd.DataFrame) -> pd.DataFrame:
    d = df.copy()
    d['S_X_clean'] = clean_numeric(d['S_X']) if 'S_X' in d.columns else np.nan
    d = d[d['S_X_clean'].notna()].copy()
    if len(d) == 0:
        return pd.DataFrame()
    try:
        d['xray_bin'] = pd.qcut(d['S_X_clean'], q=10, duplicates='drop')
    except Exception:
        d['xray_bin'] = pd.qcut(d['S_X_clean'].rank(method='first'), q=min(5, len(d)//10), duplicates='drop')
    rows = []
    for b, g in d.groupby('xray_bin', observed=False):
        known = g['is_known_tev'].astype(bool)
        row = {
            'xray_bin': str(b),
            'N': len(g),
            'known_TeV_N': int(known.sum()),
            'median_S_X': float(g['S_X_clean'].median()),
            'median_full_score_known': float(g.loc[known,'S_TeV_evo'].median()) if known.any() else np.nan,
            'median_full_score_other': float(g.loc[~known,'S_TeV_evo'].median()) if (~known).any() else np.nan,
            'median_no_xray_score_known': float(g.loc[known,'S_no_xray_v0_1_8'].median()) if known.any() else np.nan,
            'median_no_xray_score_other': float(g.loc[~known,'S_no_xray_v0_1_8'].median()) if (~known).any() else np.nan,
        }
        for score_col in ['S_TeV_evo','S_no_xray_v0_1_8','S_full_residual_after_xray_v0_1_8']:
            auc, p = auroc_from_scores(known.values, clean_numeric(g[score_col]).values)
            row[f'AUROC_{score_col}'] = auc
            row[f'mannwhitney_p_{score_col}'] = p
        rows.append(row)
    return pd.DataFrame(rows)


def nearest_xray_matched_controls(df: pd.DataFrame, k=5) -> pd.DataFrame:
    d = df.copy()
    d['S_X_clean'] = clean_numeric(d['S_X']) if 'S_X' in d.columns else np.nan
    d = d[d['S_X_clean'].notna()].copy()
    known = d[d['is_known_tev'].astype(bool)].copy()
    other = d[~d['is_known_tev'].astype(bool)].copy()
    if len(known) == 0 or len(other) == 0:
        return pd.DataFrame()
    selected = []
    for _, row in known.iterrows():
        dist = (other['S_X_clean'] - row['S_X_clean']).abs()
        nn = other.loc[dist.nsmallest(k).index].copy()
        nn['matched_known_index'] = row.name
        nn['matched_known_S_X'] = row['S_X_clean']
        nn['delta_S_X'] = (nn['S_X_clean'] - row['S_X_clean']).abs()
        selected.append(nn)
    controls = pd.concat(selected, axis=0).drop_duplicates().copy()
    matched = pd.concat([known, controls], axis=0).copy()
    matched['xray_matched_role'] = np.where(matched['is_known_tev'].astype(bool), 'known_TeV', 'matched_non_TeV_control')
    return matched


def matched_control_metrics(df: pd.DataFrame) -> pd.DataFrame:
    matched = nearest_xray_matched_controls(df, k=5)
    if matched.empty:
        return pd.DataFrame()
    rows = []
    for score_col, label in [
        ('S_TeV_evo','full_score'),
        ('S_xray_only_v0_1_8','xray_only'),
        ('S_no_xray_v0_1_8','no_xray'),
        ('S_full_residual_after_xray_v0_1_8','full_residual_after_xray'),
    ]:
        auc, p = auroc_from_scores(matched['is_known_tev'].values, clean_numeric(matched[score_col]).values)
        known = matched['is_known_tev'].astype(bool)
        rows.append({
            'matched_set': 'nearest_5_nonTeV_controls_per_known_TeV_by_S_X',
            'score_variant': label,
            'N': len(matched),
            'known_TeV_N': int(known.sum()),
            'control_N': int((~known).sum()),
            'median_score_known': float(clean_numeric(matched.loc[known,score_col]).median()),
            'median_score_control': float(clean_numeric(matched.loc[~known,score_col]).median()),
            'AUROC_knownTeV_vs_xray_matched_controls': auc,
            'mannwhitney_p_greater': p,
            'median_abs_delta_S_X_controls': float(matched.loc[~known,'delta_S_X'].median()) if 'delta_S_X' in matched.columns else np.nan,
        })
    matched.to_csv(TABLES / 'table_xray_matched_control_sample_v0_1_8.csv', index=False)
    return pd.DataFrame(rows)


def main():
    df = load_score_catalogue()
    df = add_score_variants(df)
    outcat = PROCESSED / 'tev_evolution_score_catalog_v0_1_8_xray_control_augmented.csv'
    df.to_csv(outcat, index=False)

    metrics = score_variant_metrics(df)
    metrics.to_csv(TABLES / 'table_xray_only_vs_full_score_v0_1_8.csv', index=False)
    bins = xray_decile_table(df)
    bins.to_csv(TABLES / 'table_xray_bin_stratified_validation_v0_1_8.csv', index=False)
    matched_metrics = matched_control_metrics(df)
    matched_metrics.to_csv(TABLES / 'table_xray_matched_validation_v0_1_8.csv', index=False)

    snippet = r'''
% v0.1.8 X-ray-control result
The full score is compared with an X-ray-only score, a score reconstructed after removing the X-ray term, and residual scores after regressing out the X-ray term. We also construct X-ray-matched non-TeV controls for the known-TeV validation sample. These tests directly address whether the validation is merely rediscovering X-ray-bright HSPs. A strong drop after removing X-ray brightness is physically expected, but any residual separation at fixed X-ray brightness shows that the branch is multi-dimensional rather than purely X-ray selected.
'''
    (DOCS / 'latex_snippet_xray_control_v0_1_8.tex').write_text(snippet, encoding='utf-8')

    print('v0.1.8 X-ray control validation complete.')
    print('Augmented catalogue:', outcat)
    print('\nScore-variant metrics:')
    cols = ['score_variant','N','known_TeV_N','Gold_known_TeV_fraction','Gold_enrichment','Gold_Silver_known_TeV_fraction','Gold_Silver_enrichment','AUROC_knownTeV_vs_other']
    print(metrics[[c for c in cols if c in metrics.columns]].to_string(index=False))
    print('\nX-ray-matched metrics:')
    print(matched_metrics.to_string(index=False))

if __name__ == '__main__':
    main()
