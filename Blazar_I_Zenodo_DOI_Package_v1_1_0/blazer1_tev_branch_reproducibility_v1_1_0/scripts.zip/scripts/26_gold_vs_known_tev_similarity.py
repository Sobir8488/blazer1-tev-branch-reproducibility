from __future__ import annotations

import sys
from pathlib import Path
sys.path.append(str(Path(__file__).resolve().parent))

import numpy as np
import pandas as pd
from scipy.stats import mannwhitneyu, ks_2samp
from _v018_helpers import TABLES, DOCS, PROCESSED, clean_numeric, load_score_catalogue, bootstrap_median_diff

FEATURES = [
    ('redshift_adopted_clean', 'redshift'),
    ('log_nu_peak_clean', 'log nu_peak proxy'),
    ('S_TeV_evo', 'TeV-evolution score'),
    ('S_X', 'X-ray component'),
    ('S_gamma_hard', 'gamma hardness component'),
    ('S_gamma_var', 'gamma variability component'),
    ('S_IR', 'WISE/HSP-locus component'),
    ('S_R', 'radio compactness component'),
    ('S_nu_peak', 'synchrotron-peak component'),
    ('S_EBL_proxy', 'redshift/EBL component'),
    ('S_CD_penalty', 'Compton-dominance penalty component'),
    ('PC1_TeV_branch_axis_v0_1_8', 'PCA TeV-branch axis'),
]


def feature_comparison(df: pd.DataFrame) -> pd.DataFrame:
    known = df[df['is_known_tev'].astype(bool)].copy()
    gold_non = df[(~df['is_known_tev'].astype(bool)) & df['tev_priority_tier'].astype(str).eq('Gold')].copy()
    rows = []
    for col, label in FEATURES:
        if col not in df.columns:
            continue
        a = clean_numeric(known[col]).dropna()
        b = clean_numeric(gold_non[col]).dropna()
        if len(a) < 3 or len(b) < 3:
            continue
        try:
            ks = ks_2samp(a, b, alternative='two-sided')
            ks_stat, ks_p = float(ks.statistic), float(ks.pvalue)
        except Exception:
            ks_stat, ks_p = np.nan, np.nan
        try:
            mw = mannwhitneyu(a, b, alternative='two-sided')
            mw_p = float(mw.pvalue)
        except Exception:
            mw_p = np.nan
        diff, lo, hi = bootstrap_median_diff(a, b, n=1000)
        pooled = np.nanstd(pd.concat([a, b]).values)
        rows.append({
            'feature': col,
            'feature_label': label,
            'known_TeV_N': int(len(a)),
            'Gold_nonTeV_N': int(len(b)),
            'known_TeV_median': float(np.nanmedian(a)),
            'Gold_nonTeV_median': float(np.nanmedian(b)),
            'median_diff_known_minus_gold_nonTeV': diff,
            'median_diff_16': lo,
            'median_diff_84': hi,
            'standardized_median_diff': diff / pooled if pooled > 0 else np.nan,
            'KS_statistic': ks_stat,
            'KS_p_two_sided': ks_p,
            'MannWhitney_p_two_sided': mw_p,
            'overlap_interpretation': 'similar/overlapping' if (np.isfinite(ks_p) and ks_p > 0.05) else 'different or low-power caution',
        })
    return pd.DataFrame(rows)


def nearest_neighbour_similarity(df: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    features = [c for c, _ in FEATURES if c in df.columns and c not in ['S_TeV_evo']]
    d = df.copy()
    # Prefer compact feature vector with at least 5 usable values.
    X = d[features].apply(clean_numeric)
    good_cols = [c for c in X.columns if X[c].notna().sum() > 50]
    X = X[good_cols]
    # Standardize and impute medians.
    for c in X.columns:
        X[c] = X[c].fillna(X[c].median())
        sd = X[c].std()
        if sd == 0 or not np.isfinite(sd):
            X[c] = 0.0
        else:
            X[c] = (X[c] - X[c].mean()) / sd
    known_idx = d.index[d['is_known_tev'].astype(bool)].tolist()
    gold_non_idx = d.index[(~d['is_known_tev'].astype(bool)) & d['tev_priority_tier'].astype(str).eq('Gold')].tolist()
    non_gold_non_idx = d.index[(~d['is_known_tev'].astype(bool)) & (~d['tev_priority_tier'].astype(str).eq('Gold'))].tolist()
    if len(known_idx) == 0 or len(gold_non_idx) == 0:
        return pd.DataFrame(), pd.DataFrame()
    known_X = X.loc[known_idx].values
    rows = []
    for group_name, idxs in [('Gold_nonTeV', gold_non_idx), ('nonGold_nonTeV', non_gold_non_idx)]:
        for idx in idxs:
            v = X.loc[idx].values
            dist = np.sqrt(((known_X - v) ** 2).sum(axis=1))
            j = int(np.nanargmin(dist))
            nearest_idx = known_idx[j]
            rows.append({
                'source_index': idx,
                'comparison_group': group_name,
                'nearest_known_TeV_index': nearest_idx,
                'nearest_known_TeV_distance': float(dist[j]),
                'feature_dimension': len(good_cols),
            })
    dist_df = pd.DataFrame(rows)
    summary = dist_df.groupby('comparison_group').agg(
        N=('nearest_known_TeV_distance','size'),
        median_nearest_known_TeV_distance=('nearest_known_TeV_distance','median'),
        p16_distance=('nearest_known_TeV_distance', lambda x: np.nanpercentile(x,16)),
        p84_distance=('nearest_known_TeV_distance', lambda x: np.nanpercentile(x,84)),
    ).reset_index()
    # Add useful columns for top candidates
    top = dist_df[dist_df['comparison_group'].eq('Gold_nonTeV')].sort_values('nearest_known_TeV_distance').head(50).copy()
    keep = ['SRC_NAME','ra_deg','dec_deg','BLAZAR_CLASS','branch_stage','redshift_adopted_clean','log_nu_peak_clean','S_TeV_evo','tev_priority_tier']
    for c in keep:
        if c not in d.columns:
            d[c] = np.nan
    top = top.join(d[keep], on='source_index', rsuffix='_src')
    top = top.rename(columns={'nearest_known_TeV_distance':'distance_to_nearest_known_TeV_in_feature_space'})
    return summary, top


def main():
    # Prefer PCA-augmented catalogue if available.
    pca_path = PROCESSED / 'tev_evolution_score_catalog_v0_1_8_pca_branch_augmented.csv'
    if pca_path.exists():
        df = pd.read_csv(pca_path, low_memory=False)
        from _v018_helpers import standardize_df
        df = standardize_df(df)
    else:
        df = load_score_catalogue()
    comp = feature_comparison(df)
    comp.to_csv(TABLES / 'table_gold_nonTeV_vs_knownTeV_similarity_v0_1_8.csv', index=False)
    nn_summary, top = nearest_neighbour_similarity(df)
    nn_summary.to_csv(TABLES / 'table_gold_nonTeV_nearest_knownTeV_distance_summary_v0_1_8.csv', index=False)
    top.to_csv(TABLES / 'table_top_gold_nonTeV_knownTeV_analogues_v0_1_8.csv', index=False)

    snippet = r'''
% v0.1.8 Gold-vs-known-TeV similarity result
Gold non-TeV sources are compared with the independently known TeV sample in redshift, synchrotron-peak proxy, score components, and the PCA TeV-branch axis. We avoid claiming that the two samples are identical; instead, we test whether the Gold candidates occupy the same low-redshift, high-peak, high-score region of feature space as known TeV blazars. A nearest-neighbour table identifies the Gold non-TeV candidates most similar to known TeV sources in standardized multiwavelength feature space.
'''
    (DOCS / 'latex_snippet_gold_vs_known_tev_similarity_v0_1_8.tex').write_text(snippet, encoding='utf-8')

    print('v0.1.8 Gold non-TeV vs known-TeV similarity analysis complete.')
    print('\nFeature comparison:')
    show_cols = ['feature_label','known_TeV_N','Gold_nonTeV_N','known_TeV_median','Gold_nonTeV_median','KS_p_two_sided','overlap_interpretation']
    print(comp[[c for c in show_cols if c in comp.columns]].to_string(index=False))
    print('\nNearest-known-TeV distance summary:')
    print(nn_summary.to_string(index=False))
    print('\nTop Gold non-TeV analogues written:', TABLES / 'table_top_gold_nonTeV_knownTeV_analogues_v0_1_8.csv')

if __name__ == '__main__':
    main()
