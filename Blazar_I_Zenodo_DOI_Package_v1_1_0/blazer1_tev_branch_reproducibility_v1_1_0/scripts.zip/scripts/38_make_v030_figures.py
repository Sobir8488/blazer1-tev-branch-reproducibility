#!/usr/bin/env python
from __future__ import annotations

import pandas as pd
import matplotlib.pyplot as plt

from _v030_helpers import TABLES, FIGURES


def save_both(stem: str) -> None:
    plt.tight_layout()
    plt.savefig(FIGURES / f"{stem}.pdf", bbox_inches="tight")
    plt.savefig(FIGURES / f"{stem}.png", dpi=220, bbox_inches="tight")
    plt.close()


def main() -> None:
    boot = pd.read_csv(TABLES / "table_auc_bootstrap_summary_v0_3_0.csv")
    auc = boot[boot["quantity"].str.startswith("AUROC ")].copy()
    labels = auc["quantity"].str.replace("AUROC ", "", regex=False)
    yerr = [auc["estimate"] - auc["ci95_low"], auc["ci95_high"] - auc["estimate"]]
    plt.figure(figsize=(6.2, 4.3))
    plt.errorbar(labels, auc["estimate"], yerr=yerr, fmt="o", capsize=4)
    plt.axhline(0.5, linestyle="--", linewidth=1)
    plt.ylim(0.5, 1.01)
    plt.ylabel("AUROC with paired-bootstrap 95% CI")
    plt.xlabel("Score variant")
    plt.title("Formal uncertainty on known-TeV recovery")
    save_both("Fig_auc_formal_comparison_v0_3_0")

    hsp = pd.read_csv(TABLES / "table_hsp_circularity_sensitivity_summary_v0_3_0.csv")
    x = range(len(hsp))
    width = 0.25
    plt.figure(figsize=(8.0, 4.8))
    plt.bar([i-width for i in x], hsp["AUROC"], width=width, label="AUROC")
    plt.bar(list(x), hsp["Gold_recovery"], width=width, label="Gold recovery")
    plt.bar([i+width for i in x], hsp["Gold_Silver_recovery"], width=width, label="Gold+Silver recovery")
    plt.xticks(list(x), hsp["score_variant"], rotation=20, ha="right")
    plt.ylim(0, 1.02)
    plt.ylabel("Validation metric")
    plt.title("HSP-flag circularity sensitivity")
    plt.legend()
    save_both("Fig_hsp_circularity_sensitivity_v0_3_0")

    dual = pd.read_csv(TABLES / "table_dual_followup_list_summary_v0_3_0.csv")
    plt.figure(figsize=(6.8, 4.4))
    x = range(len(dual))
    plt.bar([i-0.18 for i in x], dual["median_full_percentile"], width=0.36, label="Full-score percentile")
    plt.bar([i+0.18 for i in x], dual["median_xray_percentile"], width=0.36, label="X-ray percentile")
    plt.xticks(list(x), ["List A\nX-ray-confirmed", "List B\nHSP frontier"])
    plt.ylim(0, 100)
    plt.ylabel("Median parent-sample percentile")
    plt.title("Component-asymmetric follow-up lists")
    plt.legend()
    save_both("Fig_dual_followup_lists_v0_3_0")

    print("Saved v0.3.0 figures under figures/.")


if __name__ == "__main__":
    main()
