#!/usr/bin/env python
"""
Create a manuscript-ready two-panel TeVCat validation figure.

Outputs
-------
figures/Fig_validation_TeVCat_recovery_panel_v0_1_4.pdf
figures/Fig_validation_TeVCat_recovery_panel_v0_1_4.png
figures/Fig_validation_TeVCat_recovery_panel_v0_1_4_summary.csv
"""
from __future__ import annotations

from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt


def as_bool_series(s: pd.Series) -> pd.Series:
    if s.dtype == bool:
        return s.fillna(False)
    return (
        s.astype(str)
        .str.strip()
        .str.lower()
        .isin(["true", "1", "yes", "y", "t"])
    )


def rankdata_average(x: np.ndarray) -> np.ndarray:
    """Average ranks, 1-based, without scipy dependency."""
    x = np.asarray(x, dtype=float)
    order = np.argsort(x, kind="mergesort")
    ranks = np.empty(len(x), dtype=float)
    sorted_x = x[order]
    i = 0
    while i < len(x):
        j = i + 1
        while j < len(x) and sorted_x[j] == sorted_x[i]:
            j += 1
        avg_rank = 0.5 * (i + 1 + j)  # 1-based average rank over i+1..j
        ranks[order[i:j]] = avg_rank
        i = j
    return ranks


def auroc_from_scores(y_true: np.ndarray, scores: np.ndarray) -> float:
    y = np.asarray(y_true, dtype=bool)
    scores = np.asarray(scores, dtype=float)
    valid = np.isfinite(scores)
    y = y[valid]
    scores = scores[valid]
    n_pos = int(y.sum())
    n_neg = int((~y).sum())
    if n_pos == 0 or n_neg == 0:
        return np.nan
    ranks = rankdata_average(scores)  # ascending ranks
    sum_ranks_pos = ranks[y].sum()
    u_pos = sum_ranks_pos - n_pos * (n_pos + 1) / 2.0
    return float(u_pos / (n_pos * n_neg))


def main() -> None:
    score_path = Path("data/processed/tev_evolution_score_catalog.csv")
    if not score_path.exists():
        raise FileNotFoundError(f"Missing score catalogue: {score_path}")

    outdir = Path("figures")
    outdir.mkdir(parents=True, exist_ok=True)

    df = pd.read_csv(score_path, low_memory=False).copy()
    if "S_TeV_evo" not in df.columns:
        raise KeyError("Column S_TeV_evo not found in score catalogue.")

    scores = pd.to_numeric(df["S_TeV_evo"], errors="coerce")
    if "tevcat_matched" in df.columns:
        known = as_bool_series(df["tevcat_matched"])
    elif "tevcat_name" in df.columns:
        known = df["tevcat_name"].notna() & (df["tevcat_name"].astype(str).str.lower() != "nan")
    else:
        raise KeyError("No TeVCat indicator column found: expected tevcat_matched or tevcat_name.")

    valid = scores.notna()
    plot_df = df.loc[valid].copy()
    plot_df["S_TeV_evo"] = scores.loc[valid].astype(float)
    plot_df["is_known_tev"] = known.loc[valid].astype(bool).values

    ranked = plot_df.sort_values("S_TeV_evo", ascending=False).reset_index(drop=True)
    total = len(ranked)
    n_known = int(ranked["is_known_tev"].sum())
    if n_known == 0:
        raise RuntimeError("No known TeV matches found; cannot make recovery curve.")

    x = (np.arange(total) + 1) / total
    y = ranked["is_known_tev"].cumsum().to_numpy(dtype=float) / n_known

    known_scores = plot_df.loc[plot_df["is_known_tev"], "S_TeV_evo"].to_numpy(dtype=float)
    other_scores = plot_df.loc[~plot_df["is_known_tev"], "S_TeV_evo"].to_numpy(dtype=float)
    auroc = auroc_from_scores(plot_df["is_known_tev"].to_numpy(), plot_df["S_TeV_evo"].to_numpy())

    fig, axes = plt.subplots(1, 2, figsize=(10.5, 4.2))

    ax = axes[0]
    ax.step(x, y, where="post", label="Known TeV recovery")
    ax.plot([0, 1], [0, 1], linestyle="--", label="Random expectation")
    ax.set_xlabel("Fraction of ranked catalogue inspected")
    ax.set_ylabel("Fraction of known TeV matches recovered")
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1.02)
    ax.legend(frameon=False, loc="lower right")
    ax.text(
        0.03,
        0.93,
        f"N={total}; known TeV={n_known}\nAUROC={auroc:.3f}",
        transform=ax.transAxes,
        va="top",
        ha="left",
        fontsize=9,
    )

    ax = axes[1]
    bins = np.linspace(
        np.nanpercentile(plot_df["S_TeV_evo"], 0.5),
        np.nanpercentile(plot_df["S_TeV_evo"], 99.5),
        28,
    )
    ax.hist(other_scores, bins=bins, density=True, alpha=0.55, label="Other BlazEr1 sources")
    ax.hist(known_scores, bins=bins, density=True, alpha=0.55, label="Known TeV matches")
    if len(other_scores):
        ax.axvline(np.nanmedian(other_scores), linestyle=":", linewidth=1.2)
    if len(known_scores):
        ax.axvline(np.nanmedian(known_scores), linestyle="--", linewidth=1.2)
    ax.set_xlabel(r"$S_{\rm TeV,evo}$")
    ax.set_ylabel("Density")
    ax.legend(frameon=False, loc="upper left")
    ax.text(
        0.97,
        0.93,
        f"median known={np.nanmedian(known_scores):.2f}\nmedian other={np.nanmedian(other_scores):.2f}",
        transform=ax.transAxes,
        va="top",
        ha="right",
        fontsize=9,
    )

    fig.tight_layout()
    pdf_path = outdir / "Fig_validation_TeVCat_recovery_panel_v0_1_4.pdf"
    png_path = outdir / "Fig_validation_TeVCat_recovery_panel_v0_1_4.png"
    fig.savefig(pdf_path, bbox_inches="tight")
    fig.savefig(png_path, dpi=220, bbox_inches="tight")
    plt.close(fig)

    summary = pd.DataFrame(
        [
            {
                "N_total": total,
                "N_known_TeV": n_known,
                "AUROC_knownTeV_vs_other": auroc,
                "median_score_known_TeV": np.nanmedian(known_scores),
                "median_score_other": np.nanmedian(other_scores),
            }
        ]
    )
    summary_path = outdir / "Fig_validation_TeVCat_recovery_panel_v0_1_4_summary.csv"
    summary.to_csv(summary_path, index=False)

    print("Saved:", pdf_path)
    print("Saved:", png_path)
    print("Saved:", summary_path)
    print(summary.to_string(index=False))


if __name__ == "__main__":
    main()
