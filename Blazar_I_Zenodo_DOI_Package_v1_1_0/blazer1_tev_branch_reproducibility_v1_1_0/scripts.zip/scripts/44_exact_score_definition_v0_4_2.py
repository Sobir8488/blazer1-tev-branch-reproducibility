from __future__ import annotations

import sys
from pathlib import Path
sys.path.append(str(Path(__file__).resolve().parent))

import numpy as np
import pandas as pd
import yaml

from _v042_helpers import (
    ROOT, TABLES, DOCS, METADATA, INTERIM, COMPONENTS,
    numeric, robust_location_scale, resolve_first_existing, write_json, load_frozen_catalogue,
)

INPUT_HIERARCHIES = {
    "xray_brightness": [
        "Fx", "flux", "flux_x", "erass1_flux", "xray_flux", "ML_FLUX_1",
        "PWL20_FLUX_ABS_0", "PWL17_FLUX_ABS_0", "PWL15_FLUX_ABS_0",
        "FIXED_FLUX_ABS_0", "FREE_FLUX_ABS_0", "SOFTFLUX_S",
        "XRT_ABS_FLUX_V", "XRT_UNABS_FLUX_V",
    ],
    "gamma_hardness": [
        "PL_Index", "Spectral_Index", "Photon_Index", "fermi_PL_Index",
        "fermi_Spectral_Index", "FGL_PL_INDEX", "FGL_LP_INDEX",
    ],
    "gamma_variability": ["Variability_Index", "fermi_Variability_Index"],
    "wise_w1": [
        "w1mpro", "W1mag", "wise_w1mpro", "wise_W1mag", "W1_MAG",
        "DERED_MAG_W1", "W1_MAG_AB", "wise_W1_MAG",
    ],
    "wise_w2": [
        "w2mpro", "W2mag", "wise_w2mpro", "wise_W2mag", "W2_MAG",
        "DERED_MAG_W2", "W2_MAG_AB", "wise_W2_MAG",
    ],
    "wise_w3": [
        "w3mpro", "W3mag", "wise_w3mpro", "wise_W3mag", "W3_MAG",
        "W3_MAG_AB", "wise_W3_MAG",
    ],
    "wise_direct_w12": ["W1_MINUS_W2", "wise_W1_MINUS_W2"],
    "radio_peak_flux": ["Speak", "peak_flux", "peak_flux_mJy", "vlass_Speak", "vlass_peak_flux_mJy"],
    "radio_integrated_flux": ["Sint", "total_flux", "int_flux_mJy", "vlass_Sint", "vlass_int_flux_mJy"],
    "gamma_energy_flux": [
        "Energy_Flux100", "Energy_Flux", "flux_gamma", "fermi_Energy_Flux100",
        "FGL_FLUX_A", "FGL_FLUX_B",
    ],
    "peak_frequency": ["LAC_LE_FREQ", "lac_le_freq", "LE_FREQ"],
    "alpha_rx": ["ALPHA_RX", "alpha_rx", "Alpha_rx", "arx"],
}

TRANSFORMATIONS = {
    "xray_brightness": "u=log10(F_X), F_X>0; S_X=(u-med(u))/(1.4826 MAD(u))",
    "gamma_hardness": "u=photon index; S_gamma_hard=-(u-med(u))/(1.4826 MAD(u))",
    "gamma_variability": "u=log10(variability index), index>0; robust z-score",
    "wise_hsp_locus": "u=-|W1-W2-0.55|-0.25|W2-W3-1.7|; robust z-score",
    "radio_compactness": "u=clip(coalesced flux ratio, RFC compactness, morphology score,0,2); robust z-score",
    "synchrotron_peak_proxy": "u=adopted log10(nu_peak/Hz); robust z-score",
    "compton_dominance_penalty": "u=log10(F_gamma/F_X), positive fluxes; robust z-score; negative branch sign",
    "ebl_penalty": "u=log10(1+z), 0<z<8; robust z-score; negative branch sign",
}

RAW_VALUE_COLUMNS = {
    "xray_brightness": "log_fx",
    "gamma_hardness": "gamma_photon_index_adopted",
    "radio_compactness": "radio_compactness",
    "synchrotron_peak_proxy": "log_nu_peak_proxy",
    "compton_dominance_penalty": "cd_proxy",
}


def _first_numeric(df: pd.DataFrame, names: list[str]) -> pd.Series:
    col = resolve_first_existing(df.columns, names)
    if col is None:
        return pd.Series(np.nan, index=df.index, dtype=float)
    return numeric(df[col])


def transformed_raw_values(df: pd.DataFrame) -> dict[str, pd.Series]:
    out: dict[str, pd.Series] = {}
    out["xray_brightness"] = numeric(df["log_fx"])
    out["gamma_hardness"] = numeric(df["gamma_photon_index_adopted"])

    variability = _first_numeric(df, INPUT_HIERARCHIES["gamma_variability"])
    out["gamma_variability"] = np.log10(variability.where(variability > 0))

    w1 = _first_numeric(df, INPUT_HIERARCHIES["wise_w1"])
    w2 = _first_numeric(df, INPUT_HIERARCHIES["wise_w2"])
    w3 = _first_numeric(df, INPUT_HIERARCHIES["wise_w3"])
    direct_w12 = _first_numeric(df, INPUT_HIERARCHIES["wise_direct_w12"])
    w12 = (w1 - w2).where((w1 - w2).notna(), direct_w12)
    w23 = w2 - w3
    s12 = -(w12 - 0.55).abs()
    s23 = -0.25 * (w23 - 1.7).abs()
    ir_raw = s12.add(s23, fill_value=0.0)
    ir_raw.loc[w12.isna() & w23.isna()] = np.nan
    out["wise_hsp_locus"] = ir_raw

    out["radio_compactness"] = numeric(df["radio_compactness"]).clip(lower=0, upper=2)
    out["synchrotron_peak_proxy"] = numeric(df["log_nu_peak_proxy"])
    out["compton_dominance_penalty"] = numeric(df["cd_proxy"])
    z = numeric(df["redshift_adopted"])
    out["ebl_penalty"] = np.log10(1 + z.where(z > 0))
    return out


def actual_input_summary(df: pd.DataFrame, key: str) -> str:
    if key == "wise_hsp_locus":
        parts = []
        for sub in ["wise_w1", "wise_w2", "wise_w3", "wise_direct_w12"]:
            parts.append(f"{sub}={resolve_first_existing(df.columns, INPUT_HIERARCHIES[sub]) or 'absent'}")
        return "; ".join(parts)
    if key == "radio_compactness":
        peak = resolve_first_existing(df.columns, INPUT_HIERARCHIES["radio_peak_flux"])
        integ = resolve_first_existing(df.columns, INPUT_HIERARCHIES["radio_integrated_flux"])
        return (
            f"flux-ratio inputs={peak or 'absent'}/{integ or 'absent'}; "
            "then median RFC S/C/X/U/K unresolved fraction; then morphology score"
        )
    if key == "synchrotron_peak_proxy":
        peak = resolve_first_existing(df.columns, INPUT_HIERARCHIES["peak_frequency"])
        arx = resolve_first_existing(df.columns, INPUT_HIERARCHIES["alpha_rx"])
        return f"{peak or 'absent'} -> SED class -> {arx or 'absent'} -> HSP catalogue flag"
    if key == "compton_dominance_penalty":
        gamma = resolve_first_existing(df.columns, INPUT_HIERARCHIES["gamma_energy_flux"])
        xray = resolve_first_existing(df.columns, INPUT_HIERARCHIES["xray_brightness"])
        return f"F_gamma={gamma or 'absent'}; F_X={xray or 'absent'}"
    if key == "ebl_penalty":
        return "Z_SPEC -> Z_MASTER -> Z_4LAC -> Z_BZCAT -> Z_SIMBAD -> Z_3HSP -> Z_MILLIQUAS -> external z -> Z_PHOTO"
    hierarchy_key = key
    return resolve_first_existing(df.columns, INPUT_HIERARCHIES[hierarchy_key]) or "absent"


def main() -> None:
    config_path = ROOT / "configs" / "config.yaml"
    if not config_path.exists():
        raise FileNotFoundError("Missing configs/config.yaml")

    cfg = yaml.safe_load(config_path.read_text(encoding="utf-8"))
    weights = cfg["score"]["weights"]
    df = load_frozen_catalogue()
    features_path = Path(df.attrs.get("source_path", "data/processed/frozen_score_catalogue.csv"))
    raw = transformed_raw_values(df)

    rows = []
    constants = []
    total = pd.Series(0.0, index=df.index, dtype=float)
    available_weight = pd.Series(0.0, index=df.index, dtype=float)

    for meta in COMPONENTS:
        key = meta["key"]
        col = meta["column"]
        weight = float(weights.get(key, meta["weight"]))
        sign = int(meta["sign"])
        x = numeric(df[col])
        valid = x.notna()
        total.loc[valid] += sign * weight * x.loc[valid]
        available_weight.loc[valid] += abs(weight)

        med, mad, scale, available_n = robust_location_scale(raw[key])
        score_unique = int(x.dropna().nunique())
        degenerate = bool((not np.isfinite(scale)) or scale == 0 or score_unique <= 1)
        rows.append({
            "component_key": key,
            "component_label": meta["label"],
            "score_column": col,
            "actual_resolved_input": actual_input_summary(df, key),
            "transformation_and_standardisation": TRANSFORMATIONS[key],
            "branch_sign": sign,
            "fixed_weight": weight,
            "available_N": int(valid.sum()),
            "available_fraction": float(valid.mean()),
            "standardized_unique_values_N": score_unique,
            "numerically_degenerate": degenerate,
        })
        constants.append({
            "component_key": key,
            "transformed_raw_available_N": available_n,
            "robust_location_median": med,
            "raw_MAD": mad,
            "robust_scale_1p4826_MAD": scale,
            "transformed_raw_min": float(numeric(raw[key]).min()),
            "transformed_raw_max": float(numeric(raw[key]).max()),
            "standardized_component_min": float(x.min()),
            "standardized_component_max": float(x.max()),
            "degenerate_scale": degenerate,
        })

    reconstructed = total / available_weight.replace(0, np.nan)
    published = numeric(df["S_TeV_evo"])
    compare = published.notna() & reconstructed.notna()
    max_delta = float((published[compare] - reconstructed[compare]).abs().max())

    definition = pd.DataFrame(rows)
    constants_df = pd.DataFrame(constants)
    definition.to_csv(TABLES / "table_exact_score_definition_v0_4_2.csv", index=False)
    constants_df.to_csv(TABLES / "table_score_standardization_constants_v0_4_2.csv", index=False)

    hierarchy_rows = []
    for key, values in INPUT_HIERARCHIES.items():
        hierarchy_rows.append({
            "input_group": key,
            "candidate_columns_in_precedence_order": " | ".join(values),
            "resolved_column_in_frozen_catalogue": resolve_first_existing(df.columns, values) or "absent",
        })
    pd.DataFrame(hierarchy_rows).to_csv(TABLES / "table_score_input_hierarchy_v0_4_2.csv", index=False)

    reconstruction = pd.DataFrame([{
        "catalogue": str(features_path.relative_to(ROOT)) if features_path.is_absolute() else str(features_path),
        "N": len(df),
        "comparable_N": int(compare.sum()),
        "max_abs_delta_published_minus_reconstructed": max_delta,
        "available_weight_min": float(available_weight[available_weight > 0].min()),
        "available_weight_median": float(available_weight[available_weight > 0].median()),
        "available_weight_max": float(available_weight.max()),
        "formula": "sum(sign_j * weight_j * S_ij) / sum_available(abs(weight_j))",
    }])
    reconstruction.to_csv(TABLES / "table_score_reconstruction_audit_v0_4_2.csv", index=False)

    metadata = {
        "version": "0.4.2",
        "score_name": "S_TeV_branch (catalogue column retained as S_TeV_evo for backward compatibility)",
        "tier_percentiles": cfg["score"]["tiers"],
        "robust_standardisation": "(x - median) / (1.4826 * median_absolute_deviation)",
        "missing_component_rule": "omit missing component from numerator and available-weight denominator",
        "weights": weights,
        "reconstruction_max_abs_delta": max_delta,
        "degenerate_components": definition.loc[definition["numerically_degenerate"], "component_key"].tolist(),
    }
    write_json(METADATA / "score_definition_v0_4_2.json", metadata)

    compact = definition[[
        "component_label", "score_column", "branch_sign", "fixed_weight",
        "available_fraction", "numerically_degenerate",
    ]].copy()
    tex = compact.to_latex(
        index=False,
        escape=True,
        float_format=lambda x: f"{x:.3f}",
        caption=("Exact score-component specification. Availability is measured in the frozen "
                 "5865-source catalogue. A degenerate component has zero robust scale or a single "
                 "standardized value and therefore contributes no rank information."),
        label="tab:exact_score_definition_v042",
    )
    (DOCS / "latex_exact_score_definition_v0_4_2.tex").write_text(tex, encoding="utf-8")

    print("v0.4.2 exact score-definition audit complete.")
    print(f"Reconstruction comparable N={int(compare.sum())}; max abs delta={max_delta:.3e}")
    if metadata["degenerate_components"]:
        print("Numerically degenerate components:", ", ".join(metadata["degenerate_components"]))
    print(definition[["component_key", "fixed_weight", "available_N", "numerically_degenerate"]].to_string(index=False))


if __name__ == "__main__":
    main()
