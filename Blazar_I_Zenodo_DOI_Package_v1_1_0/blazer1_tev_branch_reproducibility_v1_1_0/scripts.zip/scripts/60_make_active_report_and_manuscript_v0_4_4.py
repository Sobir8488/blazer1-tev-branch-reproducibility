#!/usr/bin/env python
from __future__ import annotations
import re
from pathlib import Path
import numpy as np
import pandas as pd
from _v044_helpers import *

TEMPLATES=ROOT/"templates"

def read(name): return pd.read_csv(TABLES/name)
def f(x,n=3): return f"{float(x):.{n}f}"
def lsci(x):
    x=float(x)
    if not np.isfinite(x): return "--"
    if x==0: return r"<10^{-300}"
    e=int(np.floor(np.log10(abs(x)))); m=x/10**e
    return rf"{m:.2f}\times10^{{{e}}}"

def sci(x):
    x=float(x)
    if not np.isfinite(x): return "--"
    if x==0: return "$<10^{-300}$"
    e=int(np.floor(np.log10(abs(x)))); m=x/10**e
    return f"${m:.2f}\\times10^{{{e}}}$" if abs(e)>=3 else f"${x:.4f}$"
def esc(s): return str(s).replace("_","\\_").replace("%","\\%")

def getq(tab,quantity): return tab.loc[tab["quantity"].eq(quantity)].iloc[0]
def gettier(tab,variant,tier): return tab[(tab["score_variant"].eq(variant))&(tab["tier_set"].eq(tier))].iloc[0]

def compact_table(df, columns, headers, caption, label, star=True, small=True):
    env="table*" if star else "table"
    align="l"+"r"*(len(columns)-1)
    lines=[f"\\begin{{{env}}}[t]","\\centering"]
    if small: lines.append("\\small")
    lines += [f"\\caption{{{caption}}}",f"\\label{{{label}}}",f"\\begin{{tabular}}{{{align}}}","\\toprule"," & ".join(headers)+" \\\\","\\midrule"]
    for _,r in df.iterrows():
        vals=[]
        for c in columns:
            v=r[c]
            if isinstance(v,(float,np.floating)):
                if pd.isna(v): vals.append("--")
                elif abs(v)<1e-3 and v!=0: vals.append(sci(v))
                else: vals.append(f"{v:.3f}")
            else: vals.append(esc(v))
        lines.append(" & ".join(vals)+" \\\\")
    lines += ["\\bottomrule","\\end{tabular}",f"\\end{{{env}}}"]
    return "\n".join(lines)

def build_sections():
    val=read("table_active_primary_validation_v0_4_4.csv"); auc=read("table_active_harmonized_auc_v0_4_4.csv"); de=read("table_active_harmonized_delong_v0_4_4.csv"); branch=read("table_active_ordered_branch_summary_v0_4_4.csv"); partial=read("table_active_partial_correlation_v0_4_4.csv"); hsp=read("table_active_hsp_circularity_v0_4_4.csv"); cand=read("table_active_candidate_list_summary_v0_4_4.csv"); cont=read("table_active_component_contributions_v0_4_4.csv"); pca=read("table_active_pca_validation_v0_4_4.csv"); sim=read("table_active_gold_vs_known_TeV_v0_4_4.csv"); dist=read("table_active_nearest_known_TeV_distance_v0_4_4.csv"); ts=read("table_active_time_split_iact_v0_4_4.csv"); obs=read("table_active_iact_observed_metrics_v0_4_4.csv"); pattern=read("table_pattern_conditioned_validation_v0_4_3.csv"); random=read("table_random_shift_crossmatch_summary_v0_4_2.csv"); matched=read("table_active_xray_matched_score_metrics_v0_4_4.csv") if (TABLES/"table_active_xray_matched_score_metrics_v0_4_4.csv").exists() else pd.DataFrame(); mpair=read("table_active_xray_matched_pairwise_v0_4_4.csv") if (TABLES/"table_active_xray_matched_pairwise_v0_4_4.csv").exists() else pd.DataFrame()
    ag=gettier(val,"active_primary","Gold"); ags=gettier(val,"active_primary","Gold+Silver")
    af=getq(auc,"AUROC active_full"); ax=getq(auc,"AUROC xray_only"); an=getq(auc,"AUROC no_xray"); dx=getq(auc,"Delta AUROC xray_only - active_full")
    pde=de[(de["model_a"].eq("xray_only"))&(de["model_b"].eq("active_full"))].iloc[0]
    patt={r.score_variant:r for _,r in pattern.iterrows()}
    hbase=hsp[hsp["score_variant"].eq("baseline_active")].iloc[0]; hcont=hsp[hsp["score_variant"].eq("continuous_peak_only")].iloc[0]
    ca=cand[(cand["followup_list"].eq("A_xray_prioritized"))&(cand["evidence_stratum"].eq("core_low_z_stable"))].iloc[0]
    cb=cand[(cand["followup_list"].eq("B_HSP_branch_frontier"))&(cand["evidence_stratum"].eq("core_low_z_stable"))].iloc[0]
    listA=int(cand[cand["followup_list"].eq("A_xray_prioritized")]["N"].sum()); listB=int(cand[cand["followup_list"].eq("B_HSP_branch_frontier")]["N"].sum())
    knownc=cont[(cont["sample"].eq("known_TeV"))].set_index("component_key"); goldc=cont[(cont["sample"].eq("Gold_non_TeV"))].set_index("component_key")
    pc1=pca[pca["relation"].eq("PC1_vs_active_score")].iloc[0]
    dgold=dist[dist["comparison_group"].eq("Gold_nonTeV")].iloc[0]; dnon=dist[dist["comparison_group"].eq("nonGold_nonTeV")].iloc[0]
    tprimary=ts[(ts["date_axis"].eq("public_report_date"))&(ts["freeze_date"].eq("2018-12-31"))&(ts["score_variant"].eq("active_full"))&(ts["tier_set"].eq("Gold+Silver"))].iloc[0]
    obsactive=obs[obs["score_variant"].eq("active_full")].iloc[0]
    rnd=random[random["radius_arcsec"].eq(180)].iloc[0]
    match_text=""
    if len(matched):
        pm=matched[matched["control_representation"].eq("pair_weighted_with_replacement")].iloc[0]; um=matched[matched["control_representation"].eq("unique_control_sensitivity")].iloc[0]; pp=mpair.iloc[0]
        match_text=f"The pair-weighted active-score AUROC is {pm.AUROC_known_vs_control:.3f}, whereas the 98-unique-control sensitivity gives {um.AUROC_known_vs_control:.3f}.  The within-pair win fraction is {pp.pairwise_win_fraction:.3f} (cluster-bootstrap 95 per cent interval {pp.cluster_bootstrap_ci95_low:.3f}--{pp.cluster_bootstrap_ci95_high:.3f})."

    abstract=rf"""\begin{{abstract}}
We test whether the known very-high-energy (VHE; TeV) locus in the 5865-source eROSITA BlazEr1 catalogue is best described by jet physics, historical target selection, or their shared observable structure.  We define a no-leakage active-component branch coordinate from X-ray brightness, gamma-ray hardness and variability, infrared colour, synchrotron-peak, Compton-dominance, and redshift/EBL proxies.  A radio-compactness proxy available for 3530 sources has zero robust dispersion and is excluded from both numerator and denominator; the released legacy score is retained only as a reproducibility reference.  The active Gold tier contains {int(ag.tier_N)} sources and recovers {int(ag.recovered_N)}/34 TeVCat matches, a {ag.enrichment:.2f}-fold enrichment, while Gold+Silver recovers {int(ags.recovered_N)}/34.  On one harmonized complete-case population ($N={int(af.N)}$), X-ray-only ranking has AUROC {ax.estimate:.3f} (95 per cent bootstrap interval {ax.ci95_low:.3f}--{ax.ci95_high:.3f}), compared with {af.estimate:.3f} ({af.ci95_low:.3f}--{af.ci95_high:.3f}) for the active branch and {an.estimate:.3f} ({an.ci95_low:.3f}--{an.ci95_high:.3f}) without X-rays.  The X-ray advantage is $\Delta\mathrm{{AUROC}}={dx.estimate:.3f}$ (DeLong $p={lsci(pde.p_two_sided)}$).  Multiwavelength coverage is itself associated with historical TeV membership, but exact conditioning on feature-availability pattern preserves AUROCs of {patt['xray_only'].within_pattern_percentile_AUROC:.3f}, {patt['active_available'].within_pattern_percentile_AUROC:.3f}, and {patt['no_xray'].within_pattern_percentile_AUROC:.3f}, respectively.  Removing categorical HSP flags does not weaken retrospective recovery, although candidate identity changes.  Known TeV sources are X-ray dominated, whereas Gold non-TeV sources extend farther along the peak-proxy axis.  We release a stable {listA}-source X-ray-prioritized list and a more architecture-sensitive {listB}-source HSP-branch-frontier list.  Chronological and observed-control audits remain small-$N$ consistency tests, not calibrated prospective prediction.  TeV favourability in BlazEr1 is therefore an X-ray-anchored, coverage-aware population branch rather than a detection probability.
\end{{abstract}}"""

    methods=rf"""\section{{Methods}}
\label{{sec:methods}}

\subsection{{Analysis architecture and active branch coordinate}}

The analysis is separated into score construction without TeV labels, retrospective validation, and audits of catalogue geometry, feature availability, and IACT selection history.  The primary coordinate is
\begin{{align}}
S_{{{{\rm TeV,branch}},i}}=\frac{{1}}{{W_{{i,\rm active}}}}\big(&1.00S_X+1.00S_{{\gamma h}}+0.35S_{{\gamma v}}+0.75S_{{\rm IR}}+1.00S_{{\nu_{{\rm peak}}}}\nonumber\\
&-0.60S_{{\rm CD}}-0.80S_{{\rm EBL}}\big),
\label{{eq:active_score}}
\end{{align}}
where $W_{{i,\rm active}}$ is the sum of the absolute weights of active components available for source $i$.  Each continuous input is transformed as specified in Appendix~\ref{{app:score_architecture}} and robustly standardized using $(x-\mathrm{{median}})/(1.4826\,\mathrm{{MAD}})$.  Missing components are omitted from numerator and denominator; no missing value is replaced by a favourable value.

The original radio-compactness proxy has one standardized value across its 3530 available rows because its raw median absolute deviation is zero.  It therefore contains no rank information.  The corrected primary coordinate excludes it from numerator and denominator.  This decision was made from numerical activity alone, before considering TeVCat performance.  The published available-component score is retained as a frozen legacy reference, and a fixed-denominator variant is retained only as a coverage-penalizing sensitivity test.

Gold, Silver, Bronze, and Low-priority tiers are fixed at the top 5, next 10, next 15, and remaining 70 per cent of the active-score population.  They are descriptive priority strata, not calibrated detection probabilities.

\subsection{{No-leakage validation and cross-match safety}}

TeVCat membership, TeVCat names, and Fermi TeV-association flags are excluded from every score component and tier definition.  At the adopted 180-arcsec radius the catalogue contains 34 TeVCat matches.  Recovery significance is evaluated with the hypergeometric survival probability and enrichment relative to a random tier of equal size.  Rank discrimination is summarized by AUROC.

Match-radius sensitivity is evaluated at 60, 90, 120, and 180 arcsec while holding scores and tiers fixed.  In addition, 1000 local random shifts displace every TeVCat position by $0.5$--$2.0$ deg.  At 180 arcsec the observed match count is 34, the random median is zero, the 97.5th percentile is one, and the empirical probability of obtaining at least the observed count is ${lsci(rnd.empirical_p_random_ge_observed)}$.  This audit addresses chance sky superposition, not the historical non-uniformity of IACT target selection.

\subsection{{Harmonized inference and feature-availability conditioning}}

The active, X-ray-only, and no-X-ray scores are compared on one common complete-case population.  We use 5000 paired class-stratified bootstrap draws and correlated DeLong tests.  Because known TeV sources are unusually well characterized, we separately encode each source's exact eight-component availability pattern.  Validation is then repeated only in patterns represented among the 34 known TeV objects, with scores converted to percentiles within each pattern.  Significance is measured by 5000 label permutations restricted within pattern.  This design distinguishes branch separation from characterization completeness.

\subsection{{X-ray anchoring and matched controls}}

For each known TeV source, the five nearest non-TeV neighbours in $S_X$ are selected with replacement.  The construction yields 170 matched pair rows from 98 unique control sources; control reuse is retained in the pair representation and inference is clustered by known source.  X-ray balance, residual imbalance in redshift, peak proxy, and component count, pair-weighted and unique-control AUROCs, and within-pair win fractions are all reported.  The matched audit tests conditional separation at similar X-ray brightness; it does not estimate an exposure-specific detection probability.

\subsection{{Population geometry, robustness, and interpretability}}

We test the demographic ordering FSRQ/QSO-like $\rightarrow$ BCU/uncertain $\rightarrow$ BL Lac-like $\rightarrow$ HSP-like using Spearman and Kruskal--Wallis statistics.  Score--peak correlations are repeated after rank-residualizing both variables against redshift.  Selection-stress tests restrict the catalogue by Fermi detection, redshift quality, Galactic latitude, class, redshift, X-ray brightness, and gamma-ray hardness.  Score weights are independently perturbed by $\pm30$ per cent, and each active component is removed in turn.

Signed component contributions are evaluated after the same source-specific active denominator used in equation~\ref{{eq:active_score}}.  A standardized PCA provides an unsupervised branch-axis check.  Gold non-TeV sources are compared with known TeV sources feature by feature and by their nearest distance in standardized active-component space.

\subsection{{HSP sensitivity, follow-up products, and IACT audits}}

The peak term is recomputed after removing categorical HSP flags, retaining only continuous 4LAC/$\alpha_{{\rm RX}}$ information, and removing the peak component entirely.  We report both aggregate recovery and source-identity stability.  List A comprises non-TeVCat active Gold or Silver sources that are X-ray-only Gold.  List B comprises non-TeVCat active Gold sources that are not X-ray-only Gold.  Both lists are stratified by redshift availability, attenuation caution, redshift quality, and, for List B, peak-proxy stability.

Eight firm IACT reports are used in a public-report-date split.  Present-day features are not reconstructed historically, so this is a quasi-prospective label-time split.  A separate observed-control pilot compares firm and non-firm outcomes in two MAGIC extreme-blazar programmes using exact permutation and Fisher tests.
"""

    main_auc=pd.DataFrame([{"Score":"Active branch","AUROC":af.estimate,"CI_low":af.ci95_low,"CI_high":af.ci95_high},{"Score":"X-ray only","AUROC":ax.estimate,"CI_low":ax.ci95_low,"CI_high":ax.ci95_high},{"Score":"No X-ray","AUROC":an.estimate,"CI_low":an.ci95_low,"CI_high":an.ci95_high}])
    auc_table=compact_table(main_auc,["Score","AUROC","CI_low","CI_high"],["Score","AUROC",r"95\% low",r"95\% high"],"Harmonized active-score comparison on a single complete-case population.","tab:active_harmonized",False)
    branch_table=compact_table(branch,["branch_stage","N","known_TeV_N","median_active_score","Gold_fraction","median_z","median_log_nu_peak"],["Stage","$N$","TeV $N$","Median score","Gold frac.","Median $z$","Median $\\log\\nu_{\\rm peak}$"],"Ordered demographic branch under the active coordinate.","tab:active_branch",True)
    results=rf"""\section{{Results}}
\label{{sec:results}}

\subsection{{The corrected active coordinate preserves the central signal}}

The active coordinate is defined for all 5865 sources.  Gold contains {int(ag.tier_N)} sources and {int(ag.recovered_N)} of 34 TeVCat matches, corresponding to {100*ag.recovery_fraction:.1f} per cent recovery, {ag.enrichment:.2f}-fold enrichment, and $p_{{\rm hyper}}={lsci(ag.hypergeom_p_greater)}$.  Gold+Silver contains {int(ags.tier_N)} sources and recovers {int(ags.recovered_N)}/34, with {ags.enrichment:.2f}-fold enrichment.  The active score has full-population AUROC {gettier(val,'active_primary','Gold').AUROC:.3f}.  Relative to the frozen legacy score, the active Gold tier retains 256 of 294 sources; the correction is small in rank correlation but material for individual candidate identity.

{auc_table}

\begin{{figure}}
\centering
\includegraphics[width=\columnwidth]{{figures/Fig_active_harmonized_auc_v0_4_4.pdf}}
\caption{{All three score variants evaluated on the same complete-case population.  X-ray-only ranking remains strongest, while the active branch retains substantial separation after removal of the inactive radio denominator term.}}
\label{{fig:active_auc}}
\end{{figure}}

On the common $N={int(af.N)}$ population, the active score has AUROC {af.estimate:.3f} ({af.ci95_low:.3f}--{af.ci95_high:.3f}), compared with {ax.estimate:.3f} ({ax.ci95_low:.3f}--{ax.ci95_high:.3f}) for X-ray only and {an.estimate:.3f} ({an.ci95_low:.3f}--{an.ci95_high:.3f}) without X-rays.  The X-ray-only advantage over the active score is {dx.estimate:.3f}, with bootstrap interval {dx.ci95_low:.3f}--{dx.ci95_high:.3f} and DeLong $p={lsci(pde.p_two_sided)}$.  The active score exceeds the no-X-ray score by {getq(auc,'Delta AUROC active_full - no_xray').estimate:.3f}.  The dominant retrospective gateway is therefore still the X-ray axis.

\subsection{{Coverage history amplifies but does not create the separation}}

All 34 known TeV sources have seven or eight available components, and component count alone is a strong proxy for historical TeV membership.  This inflates unrestricted retrospective AUROC.  Exact availability-pattern conditioning reduces the active-score AUROC from {patt['active_available'].unrestricted_AUROC:.3f} to {patt['active_available'].within_pattern_percentile_AUROC:.3f}, but the conditional signal remains well above the within-pattern permutation null ($p={lsci(patt['active_available'].conditional_permutation_p_greater)}$).  X-ray only remains strongest at {patt['xray_only'].within_pattern_percentile_AUROC:.3f}, followed by the active branch at {patt['active_available'].within_pattern_percentile_AUROC:.3f} and no X-ray at {patt['no_xray'].within_pattern_percentile_AUROC:.3f}.  Thus, multiwavelength characterization history contributes to the apparent separability but does not generate the X-ray ordering.

\begin{{figure}}
\centering
\includegraphics[width=\columnwidth]{{figures/Fig_active_coverage_conditioning_v0_4_4.pdf}}
\caption{{Unrestricted and exact-availability-pattern-conditioned AUROC.  Conditioning reduces all values but preserves the X-ray-only $>$ active branch $>$ no-X-ray ordering.}}
\label{{fig:coverage_conditioning}}
\end{{figure}}

\subsection{{X-ray-matched controls do not establish independent active-score separation}}

{match_text}  X-ray balance is close, but redshift, peak proxy, and component coverage remain imbalanced.  The representation dependence and clustered uncertainty preclude a claim that the active branch separates known TeV sources independently of X-ray brightness.  The matched audit instead supports the narrower conclusion that the unconditional TeVCat signal is X-ray anchored.

\subsection{{A low-redshift, high-peak population branch remains}}

{branch_table}

The active score rises from a median of {branch.iloc[0].median_active_score:.3f} in FSRQ/QSO-like sources to {branch.iloc[-1].median_active_score:.3f} in HSP-like sources.  Over the same ordering, median redshift falls from {branch.iloc[0].median_z:.3f} to {branch.iloc[-1].median_z:.3f}, and the peak proxy rises from {branch.iloc[0].median_log_nu_peak:.2f} to {branch.iloc[-1].median_log_nu_peak:.2f}.  The Gold fraction reaches {100*branch.iloc[-1].Gold_fraction:.1f} per cent in the HSP-like stage.  For all valid sources, the score--peak correlation is {partial.iloc[0].spearman_score_peak:.3f}; after controlling for redshift it remains {partial.iloc[0].partial_spearman_control_z:.3f}.  The corresponding BL Lac-like partial correlation is {partial[partial['sample'].eq('BL_Lac_like')].iloc[0].partial_spearman_control_z:.3f}.

\begin{{figure*}}
\centering
\includegraphics[width=0.92\textwidth]{{figures/Fig_active_ordered_branch_v0_4_4.pdf}}
\caption{{Active-score, redshift, and peak-proxy trends across the ordered demographic branch.  The sequence is a population ordering, not an evolutionary track for individual sources.}}
\label{{fig:active_branch}}
\end{{figure*}}

\subsection{{Component asymmetry and candidate identity}}

Known TeV sources receive {knownc.loc['xray_brightness','contribution_percent']:.1f} per cent of their aggregate absolute contribution from X-rays and {knownc.loc['synchrotron_peak_proxy','contribution_percent']:.1f} per cent from the peak proxy.  Gold non-TeV sources reverse this emphasis: the peak proxy contributes {goldc.loc['synchrotron_peak_proxy','contribution_percent']:.1f} per cent and X-rays {goldc.loc['xray_brightness','contribution_percent']:.1f} per cent.  PC1 explains the leading component-space variance and correlates with the active score at $\rho={pc1.spearman_rho:.3f}$.  Gold non-TeV sources remain statistically distinct from known TeV objects, but their median nearest-known distance ({dgold.median_nearest_known_TeV_distance:.2f}) is smaller than that of non-Gold non-TeV sources ({dnon.median_nearest_known_TeV_distance:.2f}).

\begin{{figure*}}
\centering
\includegraphics[width=0.88\textwidth]{{figures/Fig_active_component_contributions_v0_4_4.pdf}}
\caption{{Component asymmetry under the corrected active denominator.  Historical TeV matches are more X-ray dominated, whereas active Gold non-TeV sources extend farther along the peak-proxy direction.}}
\label{{fig:active_components}}
\end{{figure*}}

\subsection{{HSP sensitivity and two follow-up regimes}}

The active baseline recovers {int(hbase.Gold_known_TeV_N)}/34 TeVCat matches in Gold.  The continuous-peak-only variant recovers {int(hcont.Gold_known_TeV_N)}/34 and has AUROC {hcont.AUROC:.3f}, so categorical HSP labels do not create the retrospective signal.  Candidate identity is less stable: the active Gold Jaccard overlap is {hcont.Gold_Jaccard_vs_active:.3f}, and {int(hcont.top30_nonTeV_overlap_N)} of the baseline top 30 non-TeV sources remain.

List A contains {listA} X-ray-prioritized sources, including {int(ca.N)} in the core low-redshift stable stratum.  List B contains {listB} HSP-branch-frontier sources, including {int(cb.N)} in its core.  List A is nearly invariant to the active-score correction, whereas List B remains more sensitive to peak construction and score architecture.  Neither list is a detection catalogue.

\begin{{figure*}}
\centering
\includegraphics[width=0.9\textwidth]{{figures/Fig_active_hsp_circularity_v0_4_4.pdf}}
\caption{{Left: recovery remains high after removing categorical HSP information.  Right: Gold and top-30 membership change substantially, separating aggregate validation robustness from source-level stability.}}
\label{{fig:active_hsp}}
\end{{figure*}}

\subsection{{Chronological and observed-control audits}}

For the 2018-12-31 public-report split, three of eight later firm reports match BlazEr1 and all three lie in active Gold+Silver; the random-tier reference probability is {tprimary.random_tier_reference_probability:.4f}.  This is chronological consistency, not strict feature-time-blind prediction.  The observed-control pilot contains only two firm and two non-firm matched sources.  Active-score AUROC is {obsactive.AUROC_firm_vs_nonfirm:.2f} with exact permutation $p={obsactive.permutation_p_two_sided:.3f}$.  The pilot is therefore inconclusive for detection outcome conditional on observation.
"""

    discussion=rf"""\section{{Discussion}}
\label{{sec:discussion}}

\subsection{{An X-ray gateway jointly shaped by physics and selection history}}

The corrected analysis sharpens rather than overturns the original interpretation.  X-ray-only ranking remains significantly stronger than the active multiwavelength coordinate, including after exact control for feature-availability pattern.  This is consistent with a physical synchrotron gateway: in high-peak BL Lacs the X-ray band samples the highest-energy synchrotron-emitting electrons, whose inverse-Compton emission can reach the VHE regime.  It is also consistent with the history of IACT programmes, which preferentially selected X-ray-bright and high-peak targets.  TeVCat therefore encodes both jet physics and the observational logic used to find those jets.

The random-shift audit shows that the 34 coordinate associations are not chance sky coincidences.  It does not make TeVCat a uniform survey.  Likewise, availability-pattern conditioning removes a major characterization-history axis but cannot reconstruct unobserved exposure histories, source states, sky visibility, or publication selection.  The appropriate claim is that the X-ray-bright branch is real within BlazEr1 and strongly enriched in historical TeV sources, not that its score is an intrinsic TeV-emitter probability.

\subsection{{Why the active coordinate remains useful}}

The active coordinate is not retained because it outperforms X-rays; it does not.  Its function is geometric.  It organizes the low-redshift, high-peak, BL Lac/HSP-like population around the dominant X-ray axis and separates the historically X-ray-bright regime from a less X-ray-extreme high-peak frontier.  Removing the numerically inactive radio term makes this interpretation mathematically coherent: every term in the primary denominator now carries non-zero population information.

The fixed-denominator variant has higher unrestricted AUROC, but it changes candidate identity sharply and rewards characterization completeness.  It is therefore unsuitable as the primary physical coordinate.  The active available-component normalization provides the more conservative compromise: it removes a denominator artefact without turning missing data into an implicit penalty.

\subsection{{Aggregate robustness does not imply source-level stability}}

The HSP sensitivity tests demonstrate a general distinction.  Known-TeV enrichment remains strong when categorical HSP flags or the entire peak term are removed, yet the identity of the selected non-TeV population changes substantially.  The score is robust as a population statistic but less stable as an object-by-object candidate selector.  This is why the release provides alternative-score percentiles, evidence strata, and separate follow-up regimes rather than one undifferentiated Gold list.

List A is the conservative product because it requires both active full-score support and X-ray-only Gold status.  List B probes whether historical X-ray-led selection has undersampled a high-peak frontier, but its membership is more architecture- and proxy-sensitive.  A source in either list still requires spectral modelling, EBL attenuation, exposure, zenith angle, and contemporaneous state before an IACT detection forecast can be made.

\subsection{{Limits of the chronological and observed-control tests}}

The report-date audit uses present-day feature columns and later labels.  It is consequently a label-time split rather than a fully frozen historical prediction.  The observed-control pilot asks the more relevant conditional question---which already observed targets become firm detections---but currently has only four matched sources.  Its null result is not evidence against the branch; it shows that targetability and detection outcome are different inferential targets.

\subsection{{Remaining limitations and next tests}}

BlazEr1 is X-ray selected, redshift completeness varies by class, the peak proxy is heterogeneous, and the radio layer is currently uninformative after robust standardization.  The analysis does not estimate a luminosity function, intrinsic TeV fraction, or direct FSRQ-to-HSP evolution.  The strongest next validation would combine historically frozen feature snapshots with a larger post-freeze discovery set.  A separate exposure-conditioned model should incorporate spectra, upper limits, observing conditions, contemporaneous states, and instrument response.
"""

    conclusions=rf"""\section{{Conclusions}}
\label{{sec:conclusions}}

We have reconstructed TeV favourability in the 5865-source BlazEr1 catalogue as an X-ray-anchored, coverage-aware population-inference problem.  The principal conclusions are:
\begin{{enumerate}}
\item The corrected primary coordinate excludes a radio-compactness term whose robustly standardized dispersion is zero.  This removes a denominator dependence without selecting the architecture from TeVCat performance.
\item The active Gold tier recovers {int(ag.recovered_N)}/34 known TeV sources with {ag.enrichment:.2f}-fold enrichment; Gold+Silver recovers {int(ags.recovered_N)}/34.  These are retrospective enrichment statistics, not detection probabilities.
\item On one common $N={int(af.N)}$ population, X-ray-only AUROC is {ax.estimate:.3f}, active-score AUROC is {af.estimate:.3f}, and no-X-ray AUROC is {an.estimate:.3f}.  The X-ray-only advantage over the active score is significant ($p={lsci(pde.p_two_sided)}$).
\item Multiwavelength coverage is strongly associated with historical TeV membership, but exact availability-pattern conditioning preserves the ordering X-ray only ({patt['xray_only'].within_pattern_percentile_AUROC:.3f}) $>$ active branch ({patt['active_available'].within_pattern_percentile_AUROC:.3f}) $>$ no X-ray ({patt['no_xray'].within_pattern_percentile_AUROC:.3f}).
\item The active coordinate maps a low-redshift, high-peak, BL Lac/HSP-like demographic branch.  The score--peak relation remains strong after redshift control.
\item Known TeV sources are more X-ray dominated, whereas Gold non-TeV sources extend farther along the peak-proxy axis.  They are nearby branch analogues, not statistically interchangeable populations.
\item The released follow-up products comprise a stable {listA}-source X-ray-prioritized list and a more architecture-sensitive {listB}-source HSP-branch-frontier list, each with redshift, attenuation, and proxy-stability gates.
\item The report-date and observed-control layers remain small-sample audits.  They support high-tier targetability but do not establish prospective or exposure-conditioned detection prediction.
\end{{enumerate}}

The central result is therefore narrower than a TeV classifier but more defensible astrophysically: the historical VHE locus in eROSITA blazars follows an X-ray-anchored population branch whose observed strength is shaped by both jet physics and the history of multiwavelength characterization and IACT target selection.
"""
    return abstract,methods,results,discussion,conclusions


def build_appendix():
    exact=read("table_exact_score_definition_v0_4_2.csv"); exact=exact[~exact["component_key"].eq("radio_compactness")].copy(); exact["status"]="active"
    radio=read("table_exact_score_definition_v0_4_2.csv"); radio=radio[radio["component_key"].eq("radio_compactness")]
    random=read("table_random_shift_crossmatch_summary_v0_4_2.csv"); radius=read("table_active_tevcat_radius_sensitivity_v0_4_4.csv"); pattern=read("table_pattern_conditioned_validation_v0_4_3.csv"); match=read("table_active_xray_matched_score_metrics_v0_4_4.csv") if (TABLES/"table_active_xray_matched_score_metrics_v0_4_4.csv").exists() else pd.DataFrame(); stress=read("table_active_selection_stress_v0_4_4.csv"); weight=read("table_active_weight_random_summary_v0_4_4.csv"); loo=read("table_active_leave_one_component_out_v0_4_4.csv"); hsp=read("table_active_hsp_circularity_v0_4_4.csv"); cand=read("table_active_candidate_list_summary_v0_4_4.csv"); ts=read("table_active_time_split_iact_v0_4_4.csv"); obs=read("table_active_iact_observed_metrics_v0_4_4.csv")
    active_def=compact_table(exact,["component_label","score_column","branch_sign","fixed_weight","available_N"],["Component","Column","Sign","Weight","Available $N$"],"Exact active-component definition.  Transformations and robust standardization constants are supplied in the machine-readable release.","tab:app_active_components",True)
    radio_tab=compact_table(radio,["component_label","available_N","standardized_unique_values_N","numerically_degenerate"],["Excluded component","Available $N$","Unique standardized values","Degenerate"],"Numerical activity audit for the excluded radio term.","tab:app_radio_activity",False)
    random_tab=compact_table(random,["radius_arcsec","observed_parent_matches","random_median_matches","random_q97p5_matches","random_max_matches","empirical_p_random_ge_observed"],["Radius","Observed","Random median",r"Random 97.5\%","Random max","Empirical $p$"],"Local random-shift cross-match audit.","tab:app_random_shift",True)
    pat=pattern[pattern["score_variant"].isin(["active_available","xray_only","no_xray"])].copy()
    pat_tab=compact_table(pat,["score_variant","unrestricted_AUROC","represented_pattern_pool_N","within_pattern_percentile_AUROC","conditional_permutation_p_greater"],["Score","Unrestricted AUROC","Pattern pool $N$","Conditional AUROC","Permutation $p$"],"Exact feature-availability-pattern conditioning.","tab:app_pattern",True)
    loo_tab=compact_table(loo,["component_label","Gold_recovery","Gold_Silver_recovery","AUROC","Gold_Jaccard"],["Removed component","Gold rec.","G+S rec.","AUROC","Gold Jaccard"],"Leave-one-active-component-out sensitivity.","tab:app_loo",True)
    hsp_tab=compact_table(hsp,["score_variant","Gold_known_TeV_N","Gold_Silver_known_TeV_N","AUROC","Gold_Jaccard_vs_active","top30_nonTeV_overlap_N"],["Variant","Gold TeV","G+S TeV","AUROC","Gold Jaccard","Top-30 overlap"],"Active-score HSP-circularity and candidate-identity sensitivity.","tab:app_hsp",True)
    cand_tab=compact_table(cand,["followup_list","evidence_stratum","N","median_full_percentile","median_xray_percentile","median_redshift"],["List","Stratum","$N$","Full pct.","X-ray pct.","Median $z$"],"Hardened active-score follow-up strata.","tab:app_candidates",True)
    tpri=ts[(ts["date_axis"].eq("public_report_date"))&(ts["score_variant"].isin(["active_full","xray_only"]))]
    ts_tab=compact_table(tpri,["freeze_date","score_variant","tier_set","postfreeze_detection_rows","matched_detection_rows","recovered_N","random_tier_reference_probability"],["Freeze","Score","Tier","Reports","Matched","Recovered","Random-tier prob."],"Quasi-prospective public-report-date split.","tab:app_time_split",True)
    obs_tab=compact_table(obs,["score_variant","unique_matched_N","firm_detection_N","nonfirm_control_N","AUROC_firm_vs_nonfirm","permutation_p_two_sided"],["Score","Matched","Firm","Non-firm","AUROC","Permutation $p$"],"Observed-control pilot.","tab:app_observed",True)
    text=rf"""\clearpage
\appendix
\section{{Active score architecture and exact specification}}
\label{{app:score_architecture}}

The corrected primary coordinate retains only components with non-zero numerical dispersion in the frozen parent catalogue.  Architecture selection did not use TeVCat labels.  The published score remains in the release as a frozen legacy reference, and the fixed-denominator score remains a coverage-penalizing sensitivity product.

{active_def}

{radio_tab}

\FloatBarrier
\section{{Cross-match geometry and chance-coincidence audit}}

{random_tab}

\begin{{figure}}
\centering
\includegraphics[width=\columnwidth]{{figures/Fig_active_tevcat_radius_sensitivity_v0_4_4.pdf}}
\caption{{Active-score recovery as the external TeVCat match radius is varied while tiers remain fixed.}}
\end{{figure}}

\FloatBarrier
\section{{Coverage conditioning and X-ray matching}}

Known TeV sources occupy only three exact availability patterns.  Conditioning within those patterns removes the direct ranking advantage of characterization completeness while retaining substantial physical separation.

{pat_tab}

"""
    if len(match):
        text += compact_table(match,["control_representation","analysis_N","control_rows_N","unique_control_sources_N","AUROC_known_vs_control","median_known","median_control"],["Representation","$N$","Control rows","Unique controls","AUROC","Known median","Control median"],"Active-score X-ray-matched-control sensitivity.","tab:app_xmatch",True)+"\n"
    text += rf"""
\FloatBarrier
\section{{Robustness and score-construction sensitivity}}

The full selection-stress and random-weight tables are released in machine-readable form.  The compact leave-one-out and HSP-sensitivity summaries below show the largest claim-relevant effects.

{loo_tab}

{hsp_tab}

\begin{{figure*}}
\centering
\includegraphics[width=0.9\textwidth]{{figures/Fig_active_component_contributions_v0_4_4.pdf}}
\caption{{Active-component contribution asymmetry across validation and candidate populations.}}
\end{{figure*}}

\FloatBarrier
\section{{Follow-up products and IACT audits}}

{cand_tab}

{ts_tab}

{obs_tab}

The chronological table reports a probability under a random fixed-tier null, not a selection-free discovery significance.  The observed-control sample is too small for exposure-conditioned calibration.
"""
    return text


def replace_section(text,start,end,replacement):
    pat=re.compile(rf"\\section\{{{re.escape(start)}\}}.*?(?=\\section\{{{re.escape(end)}\}})",re.S)
    out,n=pat.subn(lambda m: replacement+"\n\n",text)
    if n!=1: raise RuntimeError(f"Could not replace section {start}; matches={n}")
    return out


def main():
    abstract,methods,results,discussion,conclusions=build_sections(); appendix=build_appendix()
    combined="\n\n".join([abstract,methods,results,discussion,conclusions]); (DOCS/"latex_active_score_sections_v0_4_4.tex").write_text(combined,encoding="utf-8"); (DOCS/"appendix_active_score_v0_4_4.tex").write_text(appendix,encoding="utf-8"); (ROOT/"appendix_active_score_v0_4_4.tex").write_text(appendix,encoding="utf-8")

    base=TEMPLATES/"Blazar_I_v0_4_1_base.tex"
    if base.exists():
        tex=base.read_text(encoding="utf-8")
        tex=re.sub(r"\\title\[[^\]]*\]\{[^\}]*\}",lambda m: r"\title[An X-ray-anchored TeV-favourable branch]{An X-ray-anchored TeV-favourable population branch in eROSITA blazars}",tex,count=1)
        tex=re.sub(r"\\begin\{abstract\}.*?\\end\{abstract\}",lambda m: abstract,tex,count=1,flags=re.S)
        tex=replace_section(tex,"Methods","Results",methods)
        tex=replace_section(tex,"Results","Discussion",results)
        tex=replace_section(tex,"Discussion","Conclusions",discussion)
        # Conclusions ends at unnumbered Data availability
        tex=re.sub(r"\\section\{Conclusions\}.*?(?=\\section\*\{Data availability\})",lambda m: conclusions+"\n\n",tex,count=1,flags=re.S)
        tex=tex.replace("\\input{appendix_v0_4_1}","\\input{appendix_active_score_v0_4_4}")
        # Replace the radio-score statement in Data with an explicit inactive-proxy statement.
        tex=tex.replace("The radio term is a compactness proxy based on RFC/VLBI, morphology, MOJAVE/TANAMI, or flux-ratio information when available.","A heterogeneous radio-compactness proxy is retained as catalogue metadata and is available for 3530 sources.  Its robustly standardized dispersion is zero in the frozen table, so it is excluded from the corrected primary score and used only in the architecture audit.")
        out=ROOT/"Blazar_I_active_score_v0_4_4.tex"; out.write_text(tex,encoding="utf-8"); (DOCS/"Blazar_I_active_score_v0_4_4.tex").write_text(tex,encoding="utf-8")

    # Report
    val=read("table_active_primary_validation_v0_4_4.csv"); auc=read("table_active_harmonized_auc_v0_4_4.csv"); pattern=read("table_pattern_conditioned_validation_v0_4_3.csv"); cand=read("table_active_candidate_list_summary_v0_4_4.csv"); obs=read("table_active_iact_observed_metrics_v0_4_4.csv")
    report=["# v0.4.4 active-score propagation report","","The active score is now propagated through validation, branch diagnostics, robustness, interpretability, follow-up lists, IACT audits, figures, manuscript sections, and Appendix.","","## Primary validation","",val.to_markdown(index=False),"","## Harmonized inference","",auc.to_markdown(index=False),"","## Availability-pattern conditioning","",pattern.to_markdown(index=False),"","## Candidate strata","",cand.to_markdown(index=False),"","## Observed-control pilot","",obs.to_markdown(index=False),"","## Generated manuscript products","","- `Blazar_I_active_score_v0_4_4.tex`","- `appendix_active_score_v0_4_4.tex`","- `docs/latex_active_score_sections_v0_4_4.tex`"]
    (DOCS/"active_score_propagation_report_v0_4_4.md").write_text("\n".join(report),encoding="utf-8")
    print("v0.4.4 report, manuscript, and Appendix generated.")
    print(f"Full manuscript: {ROOT/'Blazar_I_active_score_v0_4_4.tex'}")
    print(f"Appendix: {ROOT/'appendix_active_score_v0_4_4.tex'}")

if __name__=="__main__": main()
