#!/usr/bin/env python
"""
v0.1.5 evolutionary diagnostics for the BlazEr1 TeV-evolution project.

Inputs
------
data/processed/tev_evolution_score_catalog.csv

Outputs
-------
data/processed/tev_evolution_score_catalog_v0_1_5_augmented.csv
tables/table_class_summary_v0_1_5.csv/.tex
tables/table_redshift_completeness_by_class_v0_1_5.csv/.tex
tables/table_score_by_class_and_sed_v0_1_5.csv/.tex
tables/table_redshift_bin_gold_fraction_v0_1_5.csv/.tex
tables/table_selection_stress_tests_v0_1_5.csv/.tex
tables/table_known_tev_by_class_v0_1_5.csv/.tex
tables/table_top_gold_non_tev_candidates_v0_1_5.csv/.tex
docs/results_snippets_evolutionary_diagnostics_v0_1_5.tex
"""
from __future__ import annotations

import math
import re
from pathlib import Path
from typing import Iterable, Optional

import numpy as np
import pandas as pd

try:
    from scipy.stats import hypergeom, mannwhitneyu
except Exception:  # pragma: no cover
    hypergeom = None
    mannwhitneyu = None

ROOT = Path('.')
SCORE_PATH = ROOT / 'data' / 'processed' / 'tev_evolution_score_catalog.csv'
AUG_PATH = ROOT / 'data' / 'processed' / 'tev_evolution_score_catalog_v0_1_5_augmented.csv'
TABLE_DIR = ROOT / 'tables'
DOC_DIR = ROOT / 'docs'

TABLE_DIR.mkdir(parents=True, exist_ok=True)
DOC_DIR.mkdir(parents=True, exist_ok=True)
AUG_PATH.parent.mkdir(parents=True, exist_ok=True)

NULL_STRINGS = {'', '-', 'nan', 'none', 'null', 'na', '<na>', 'bnan', "b'nan'", 'b"nan"'}


def clean_scalar(x) -> str:
    """Return a compact text value from FITS/CSV byte-string artefacts."""
    if pd.isna(x):
        return ''
    s = str(x).strip()
    if len(s) >= 3 and s.startswith("b'") and s.endswith("'"):
        s = s[2:-1]
    elif len(s) >= 3 and s.startswith('b"') and s.endswith('"'):
        s = s[2:-1]
    s = s.strip()
    if s.lower() in NULL_STRINGS:
        return ''
    return s


def text_series(df: pd.DataFrame, col: str) -> pd.Series:
    if col not in df.columns:
        return pd.Series([''] * len(df), index=df.index, dtype='object')
    return df[col].map(clean_scalar)


def bool_series(df: pd.DataFrame, col: str) -> pd.Series:
    if col not in df.columns:
        return pd.Series(False, index=df.index)
    s = df[col]
    if s.dtype == bool:
        return s.fillna(False)
    txt = s.map(lambda v: clean_scalar(v).lower())
    return txt.isin(['true', '1', 'yes', 'y', 't'])


def num_series(df: pd.DataFrame, col: str) -> pd.Series:
    if col not in df.columns:
        return pd.Series(np.nan, index=df.index, dtype='float64')
    return pd.to_numeric(df[col], errors='coerce')


def first_existing_numeric(df: pd.DataFrame, cols: Iterable[str]) -> pd.Series:
    out = pd.Series(np.nan, index=df.index, dtype='float64')
    for c in cols:
        if c in df.columns:
            v = pd.to_numeric(df[c], errors='coerce')
            out = out.where(out.notna(), v)
    return out


def classify_broad_class(df: pd.DataFrame) -> pd.Series:
    # Prefer BlazEr1 class, fall back to Fermi class columns and BZCAT name prefix.
    cls = text_series(df, 'BLAZAR_CLASS').str.lower()
    f1 = text_series(df, 'fermi_CLASS1').str.lower()
    f2 = text_series(df, 'fermi_CLASS2').str.lower()
    bz = text_series(df, 'BZCAT_SRC_NAME').str.upper()
    sim = text_series(df, 'SIMBAD_TYPE2').str.lower()
    combined = (cls + ' ' + f1 + ' ' + f2 + ' ' + bz + ' ' + sim).str.lower()

    out = pd.Series('Other/uncertain', index=df.index, dtype='object')
    out[combined.str.contains(r'fsrq|bzq|qso|quasar', regex=True, na=False)] = 'FSRQ/QSO-like'
    out[combined.str.contains(r'bll|bz b|bzb|bllac|bllc|bll-g|bll\s', regex=True, na=False)] = 'BL Lac-like'
    out[combined.str.contains(r'\bbcu\b|bcuc|bcu', regex=True, na=False)] = 'BCU/uncertain'
    # If both QSO and BLL patterns occur, the explicit BL Lac-like class should not be overwritten by QSO-ish SIMBAD aliases.
    explicit_bl = cls.str.contains(r'bll|bllc', regex=True, na=False) | f1.str.contains('bll', na=False) | f2.str.contains('bll', na=False)
    out[explicit_bl] = 'BL Lac-like'
    explicit_fsrq = cls.str.contains('fsrq', na=False) | f1.str.contains('fsrq', na=False) | f2.str.contains('fsrq', na=False)
    out[explicit_fsrq] = 'FSRQ/QSO-like'
    return out


def classify_sed(df: pd.DataFrame) -> pd.Series:
    lac = text_series(df, 'LAC_SED_CLASS').str.upper()
    hsp_flag = text_series(df, 'HSP_SRC_NAME').map(lambda x: bool(x))
    lognu = num_series(df, 'log_nu_peak_proxy')
    out = pd.Series('Unknown', index=df.index, dtype='object')
    out[lac.str.contains('HSP', na=False)] = 'HSP-like'
    out[lac.str.contains('ISP', na=False)] = 'ISP-like'
    out[lac.str.contains('LSP', na=False)] = 'LSP-like'
    out[(out == 'Unknown') & (lognu >= 15.0)] = 'HSP-like'
    out[(out == 'Unknown') & (lognu >= 14.0) & (lognu < 15.0)] = 'ISP-like'
    out[(out == 'Unknown') & (lognu < 14.0)] = 'LSP-like'
    out[(out == 'Unknown') & hsp_flag] = 'HSP-like'
    return out


def score_tier_rank(tier: pd.Series) -> pd.Series:
    mapping = {'Low-priority': 0, 'Bronze': 1, 'Silver': 2, 'Gold': 3}
    return tier.map(mapping).fillna(-1).astype(int)


def safe_hypergeom_sf(N: int, K: int, n: int, k: int) -> float:
    if hypergeom is None or min(N, K, n, k) < 0 or K > N or n > N:
        return np.nan
    return float(hypergeom.sf(k - 1, N, K, n))


def auroc_mwu(pos: pd.Series, neg: pd.Series) -> tuple[float, float]:
    pos = pd.to_numeric(pos, errors='coerce').dropna()
    neg = pd.to_numeric(neg, errors='coerce').dropna()
    if len(pos) == 0 or len(neg) == 0 or mannwhitneyu is None:
        return np.nan, np.nan
    res = mannwhitneyu(pos, neg, alternative='greater')
    auroc = float(res.statistic) / float(len(pos) * len(neg))
    return auroc, float(res.pvalue)


def write_table(df: pd.DataFrame, name: str, float_fmt: str = '%.4g') -> None:
    csv_path = TABLE_DIR / f'{name}.csv'
    tex_path = TABLE_DIR / f'{name}.tex'
    df.to_csv(csv_path, index=False)
    try:
        df.to_latex(tex_path, index=False, escape=False, float_format=lambda x: float_fmt % x)
    except Exception:
        # LaTeX output is a convenience product; CSV is authoritative.
        pass


def summarise_class(df: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for label, g in df.groupby('broad_class', dropna=False):
        N = len(g)
        tev = int(g['is_known_tev'].sum())
        fermi = int(g['fermi_matched_clean'].sum())
        z_available = int(g['redshift_adopted_clean'].notna().sum())
        rows.append({
            'class': label,
            'N': N,
            'fermi_matched_N': fermi,
            'fermi_matched_fraction': fermi / N if N else np.nan,
            'known_TeV_N': tev,
            'known_TeV_fraction': tev / N if N else np.nan,
            'redshift_available_N': z_available,
            'redshift_available_fraction': z_available / N if N else np.nan,
            'median_z': g['redshift_adopted_clean'].median(),
            'median_score': g['S_TeV_evo'].median(),
            'gold_N': int((g['tev_priority_tier'] == 'Gold').sum()),
            'gold_fraction': float((g['tev_priority_tier'] == 'Gold').mean()),
            'gold_plus_silver_N': int(g['tev_priority_tier'].isin(['Gold', 'Silver']).sum()),
            'gold_plus_silver_fraction': float(g['tev_priority_tier'].isin(['Gold', 'Silver']).mean()),
            'hsp_like_N': int((g['sed_class_proxy'] == 'HSP-like').sum()),
            'hsp_like_fraction': float((g['sed_class_proxy'] == 'HSP-like').mean()),
        })
    return pd.DataFrame(rows).sort_values('N', ascending=False)


def redshift_completeness_by_class(df: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for label, g in df.groupby('broad_class', dropna=False):
        N = len(g)
        src = g['redshift_adopted_source_clean']
        rows.append({
            'class': label,
            'N': N,
            'z_any_N': int(g['redshift_adopted_clean'].notna().sum()),
            'z_any_fraction': float(g['redshift_adopted_clean'].notna().mean()),
            'z_secure_N': int(g['redshift_secure'].sum()),
            'z_secure_fraction': float(g['redshift_secure'].mean()),
            'z_spec_N': int((src == 'Z_SPEC').sum()),
            'z_photo_N': int((src == 'Z_PHOTO').sum()),
            'z_master_N': int((src == 'Z_MASTER').sum()),
            'z_missing_N': int(g['redshift_adopted_clean'].isna().sum()),
        })
    return pd.DataFrame(rows).sort_values('N', ascending=False)


def score_by_class_and_sed(df: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for (bc, sed), g in df.groupby(['broad_class', 'sed_class_proxy'], dropna=False):
        N = len(g)
        if N == 0:
            continue
        rows.append({
            'class': bc,
            'sed_class_proxy': sed,
            'N': N,
            'median_score': g['S_TeV_evo'].median(),
            'p25_score': g['S_TeV_evo'].quantile(0.25),
            'p75_score': g['S_TeV_evo'].quantile(0.75),
            'known_TeV_N': int(g['is_known_tev'].sum()),
            'gold_N': int((g['tev_priority_tier'] == 'Gold').sum()),
            'gold_fraction': float((g['tev_priority_tier'] == 'Gold').mean()),
            'gold_plus_silver_fraction': float(g['tev_priority_tier'].isin(['Gold', 'Silver']).mean()),
            'median_z': g['redshift_adopted_clean'].median(),
            'redshift_available_fraction': float(g['redshift_adopted_clean'].notna().mean()),
        })
    return pd.DataFrame(rows).sort_values(['class', 'N'], ascending=[True, False])


def redshift_bin_summary(df: pd.DataFrame) -> pd.DataFrame:
    bins = [0.0, 0.1, 0.3, 0.5, 1.0, 2.0, np.inf]
    labels = ['0-0.1', '0.1-0.3', '0.3-0.5', '0.5-1.0', '1.0-2.0', '>2.0']
    d = df[df['redshift_adopted_clean'].notna() & (df['redshift_adopted_clean'] >= 0)].copy()
    d['z_bin'] = pd.cut(d['redshift_adopted_clean'], bins=bins, labels=labels, include_lowest=True, right=False)
    rows = []
    for group_name, gg in [('All', d)]:
        for zbin, g in gg.groupby('z_bin', observed=False):
            N = len(g)
            if N == 0:
                continue
            rows.append({
                'class': group_name,
                'z_bin': str(zbin),
                'N': N,
                'known_TeV_N': int(g['is_known_tev'].sum()),
                'median_score': g['S_TeV_evo'].median(),
                'gold_fraction': float((g['tev_priority_tier'] == 'Gold').mean()),
                'gold_plus_silver_fraction': float(g['tev_priority_tier'].isin(['Gold', 'Silver']).mean()),
                'hsp_like_fraction': float((g['sed_class_proxy'] == 'HSP-like').mean()),
                'fermi_matched_fraction': float(g['fermi_matched_clean'].mean()),
            })
    for bc, gg in d.groupby('broad_class'):
        for zbin, g in gg.groupby('z_bin', observed=False):
            N = len(g)
            if N < 10:
                continue
            rows.append({
                'class': bc,
                'z_bin': str(zbin),
                'N': N,
                'known_TeV_N': int(g['is_known_tev'].sum()),
                'median_score': g['S_TeV_evo'].median(),
                'gold_fraction': float((g['tev_priority_tier'] == 'Gold').mean()),
                'gold_plus_silver_fraction': float(g['tev_priority_tier'].isin(['Gold', 'Silver']).mean()),
                'hsp_like_fraction': float((g['sed_class_proxy'] == 'HSP-like').mean()),
                'fermi_matched_fraction': float(g['fermi_matched_clean'].mean()),
            })
    return pd.DataFrame(rows)


def stress_metric_one_subset(label: str, d: pd.DataFrame, tiers: list[str]) -> dict:
    N = len(d)
    K = int(d['is_known_tev'].sum())
    in_tier = d['tev_priority_tier'].isin(tiers)
    n = int(in_tier.sum())
    k = int((in_tier & d['is_known_tev']).sum())
    frac_all = n / N if N else np.nan
    frac_known = k / K if K else np.nan
    enrich = frac_known / frac_all if (frac_all and not np.isnan(frac_known)) else np.nan
    p = safe_hypergeom_sf(N, K, n, k) if N and K and n else np.nan
    return {
        'stress_sample': label,
        'tier_set': '+'.join(tiers),
        'N': N,
        'known_TeV_N': K,
        'tier_size_N': n,
        'known_TeV_in_tier_N': k,
        'tier_fraction_all': frac_all,
        'known_TeV_recovery_fraction': frac_known,
        'enrichment_vs_random': enrich,
        'hypergeom_p_ge_k': p,
    }


def selection_stress_tests(df: pd.DataFrame) -> pd.DataFrame:
    score = pd.to_numeric(df['S_TeV_evo'], errors='coerce')
    log_fx = num_series(df, 'log_fx')
    gamma_hard = num_series(df, 'S_gamma_hard')
    b_lat = num_series(df, 'BII')
    z = df['redshift_adopted_clean']
    subsets = {
        'full_sample': pd.Series(True, index=df.index),
        'fermi_matched_only': df['fermi_matched_clean'],
        'redshift_available': z.notna(),
        'secure_redshift_only': df['redshift_secure'],
        'spectroscopic_redshift_only': df['redshift_adopted_source_clean'].eq('Z_SPEC'),
        'high_galactic_latitude_abs_b_gt_10': b_lat.abs().gt(10) if b_lat.notna().any() else pd.Series(False, index=df.index),
        'BL_Lac_like_only': df['broad_class'].eq('BL Lac-like'),
        'FSRQ_QSO_like_only': df['broad_class'].eq('FSRQ/QSO-like'),
        'HSP_like_only': df['sed_class_proxy'].eq('HSP-like'),
        'z_lt_0p5': z.lt(0.5),
        'z_lt_1p0': z.lt(1.0),
        'xray_bright_upper_half': log_fx.ge(log_fx.median()) if log_fx.notna().sum() > 10 else pd.Series(False, index=df.index),
        'fermi_gamma_hard_upper_half': gamma_hard.ge(gamma_hard.median()) if gamma_hard.notna().sum() > 10 else pd.Series(False, index=df.index),
    }
    rows = []
    for label, mask in subsets.items():
        d = df[mask.fillna(False)].copy()
        if len(d) == 0:
            continue
        for tiers in [['Gold'], ['Gold', 'Silver'], ['Gold', 'Silver', 'Bronze']]:
            rows.append(stress_metric_one_subset(label, d, tiers))
        pos = d.loc[d['is_known_tev'], 'S_TeV_evo']
        neg = d.loc[~d['is_known_tev'], 'S_TeV_evo']
        auc, mwp = auroc_mwu(pos, neg)
        rows[-1]['AUROC_knownTeV_vs_other'] = auc
        rows[-1]['mannwhitney_p_greater'] = mwp
    out = pd.DataFrame(rows)
    # propagate AUROC fields to all tier rows for easier filtering
    for sample, g in out.groupby('stress_sample'):
        auc = g['AUROC_knownTeV_vs_other'].dropna()
        mwp = g['mannwhitney_p_greater'].dropna()
        if len(auc):
            out.loc[out['stress_sample'] == sample, 'AUROC_knownTeV_vs_other'] = auc.iloc[0]
        if len(mwp):
            out.loc[out['stress_sample'] == sample, 'mannwhitney_p_greater'] = mwp.iloc[0]
    return out


def known_tev_by_class(df: pd.DataFrame) -> pd.DataFrame:
    d = df[df['is_known_tev']].copy()
    rows = []
    for (bc, sed), g in d.groupby(['broad_class', 'sed_class_proxy'], dropna=False):
        N = len(g)
        if N == 0:
            continue
        rows.append({
            'class': bc,
            'sed_class_proxy': sed,
            'known_TeV_N': N,
            'median_score': g['S_TeV_evo'].median(),
            'gold_N': int((g['tev_priority_tier'] == 'Gold').sum()),
            'gold_fraction': float((g['tev_priority_tier'] == 'Gold').mean()),
            'gold_plus_silver_N': int(g['tev_priority_tier'].isin(['Gold', 'Silver']).sum()),
            'gold_plus_silver_fraction': float(g['tev_priority_tier'].isin(['Gold', 'Silver']).mean()),
            'median_z': g['redshift_adopted_clean'].median(),
        })
    return pd.DataFrame(rows).sort_values('known_TeV_N', ascending=False)


def top_gold_non_tev(df: pd.DataFrame, n: int = 100) -> pd.DataFrame:
    cols = [
        'SRC_NAME', 'ra_deg', 'dec_deg', 'broad_class', 'sed_class_proxy',
        'redshift_adopted_clean', 'redshift_adopted_source_clean',
        'log_nu_peak_proxy', 'S_TeV_evo', 'tev_priority_tier',
        'fermi_matched_clean', 'S_X', 'S_gamma_hard', 'S_IR', 'S_R',
        'S_nu_peak', 'S_EBL_proxy', 'S_CD_penalty',
        'FGL_SRC_NAME', 'fermi_Source_Name', 'COMMON_SRC_NAME', 'SIMBAD_SRC_NAME'
    ]
    available = [c for c in cols if c in df.columns]
    d = df[(~df['is_known_tev']) & (df['tev_priority_tier'] == 'Gold')].copy()
    d = d.sort_values('S_TeV_evo', ascending=False).head(n)
    return d[available]


def make_latex_snippets(stress: pd.DataFrame, class_summary: pd.DataFrame, zcomp: pd.DataFrame) -> None:
    def get_row(sample: str, tier_set: str) -> Optional[pd.Series]:
        sel = stress[(stress['stress_sample'] == sample) & (stress['tier_set'] == tier_set)]
        return sel.iloc[0] if len(sel) else None

    gold = get_row('full_sample', 'Gold')
    gs = get_row('full_sample', 'Gold+Silver')
    gsb = get_row('full_sample', 'Gold+Silver+Bronze')
    lines = []
    lines.append('% Auto-generated by scripts/13_evolutionary_diagnostics.py (v0.1.5).')
    lines.append('% Edit wording before manuscript submission.')
    lines.append('')
    if gold is not None and gs is not None:
        lines.append(r'\paragraph{Independent TeVCat validation.}')
        lines.append(
            'The Gold tier contains '
            f"{int(gold['tier_size_N'])} of {int(gold['N'])} BlazEr1 sources "
            f"({100*gold['tier_fraction_all']:.2f} per cent), but includes "
            f"{int(gold['known_TeV_in_tier_N'])} of {int(gold['known_TeV_N'])} "
            f"TeVCat-matched sources ({100*gold['known_TeV_recovery_fraction']:.2f} per cent). "
            f"This corresponds to a {gold['enrichment_vs_random']:.2f}-fold enrichment "
            f"relative to random expectation ($p={gold['hypergeom_p_ge_k']:.2e}$, hypergeometric test). "
            'The combined Gold+Silver tiers recover '
            f"{int(gs['known_TeV_in_tier_N'])} of {int(gs['known_TeV_N'])} TeVCat-matched sources "
            f"({100*gs['known_TeV_recovery_fraction']:.2f} per cent), with a "
            f"{gs['enrichment_vs_random']:.2f}-fold enrichment "
            f"($p={gs['hypergeom_p_ge_k']:.2e}$)."
        )
        lines.append('')
    auc_rows = stress[(stress['stress_sample'] == 'full_sample') & (stress['tier_set'] == 'Gold+Silver+Bronze')]
    if len(auc_rows):
        r = auc_rows.iloc[0]
        if pd.notna(r.get('AUROC_knownTeV_vs_other', np.nan)):
            lines.append(
                f"The rank separation between TeVCat-matched and remaining BlazEr1 sources is strong "
                f"(AUROC={r['AUROC_knownTeV_vs_other']:.4f}; Mann--Whitney "
                f"$p={r['mannwhitney_p_greater']:.2e}$)."
            )
            lines.append('')
    lines.append(r'\paragraph{Class and redshift coverage.}')
    totalN = int(class_summary['N'].sum()) if len(class_summary) else 0
    zN = int(zcomp['z_any_N'].sum()) if len(zcomp) else 0
    zsec = int(zcomp['z_secure_N'].sum()) if len(zcomp) else 0
    if totalN:
        lines.append(
            f"Adopted redshifts are available for {zN} of {totalN} sources "
            f"({100*zN/totalN:.2f} per cent), while secure/non-photometric redshifts are available for "
            f"{zsec} sources ({100*zsec/totalN:.2f} per cent)."
        )
    lines.append('')
    lines.append(r'This validation should be interpreted as a follow-up-priority and evolutionary-diagnostic test, not as a claim of new TeV detections.')
    (DOC_DIR / 'results_snippets_evolutionary_diagnostics_v0_1_5.tex').write_text('\n'.join(lines), encoding='utf-8')


def main() -> None:
    if not SCORE_PATH.exists():
        raise SystemExit(f'Missing {SCORE_PATH}. Run scripts/04_compute_tev_evolution_score.py first.')

    df = pd.read_csv(SCORE_PATH, low_memory=False)
    if 'S_TeV_evo' not in df.columns:
        raise SystemExit('Missing S_TeV_evo column in score catalogue.')

    df['S_TeV_evo'] = pd.to_numeric(df['S_TeV_evo'], errors='coerce')
    df['tev_priority_tier'] = text_series(df, 'tev_priority_tier').replace('', 'Low-priority')
    df['tier_rank'] = score_tier_rank(df['tev_priority_tier'])

    df['broad_class'] = classify_broad_class(df)
    df['sed_class_proxy'] = classify_sed(df)

    # Independent TeVCat validation flag.
    tevcat_match = bool_series(df, 'tevcat_matched')
    if 'tevcat_name' in df.columns:
        tevcat_match = tevcat_match | text_series(df, 'tevcat_name').map(bool)
    df['is_known_tev'] = tevcat_match.fillna(False).astype(bool)

    df['fermi_matched_clean'] = bool_series(df, 'fermi_matched')
    if 'fermi_Source_Name' in df.columns:
        df['fermi_matched_clean'] = df['fermi_matched_clean'] | text_series(df, 'fermi_Source_Name').map(bool)

    # Redshift: use existing adopted values, fall back to BlazEr1 source columns if needed.
    z_adopted = num_series(df, 'redshift_adopted')
    if z_adopted.notna().sum() == 0:
        z_adopted = first_existing_numeric(df, ['Z_SPEC', 'Z_MASTER', 'Z_4LAC', 'Z_BZCAT', 'Z_SIMBAD', 'Z_MILLIQUAS', 'Z_3HSP', 'Z_PHOTO'])
    df['redshift_adopted_clean'] = z_adopted.where((z_adopted >= 0) & (z_adopted < 10))

    src = text_series(df, 'redshift_adopted_source')
    if src.map(bool).sum() == 0:
        src = pd.Series('', index=df.index, dtype='object')
        for c in ['Z_SPEC', 'Z_MASTER', 'Z_4LAC', 'Z_BZCAT', 'Z_SIMBAD', 'Z_MILLIQUAS', 'Z_3HSP', 'Z_PHOTO']:
            if c in df.columns:
                mask = src.eq('') & pd.to_numeric(df[c], errors='coerce').notna()
                src[mask] = c
    df['redshift_adopted_source_clean'] = src.replace('', np.nan)
    df['redshift_secure'] = df['redshift_adopted_clean'].notna() & ~df['redshift_adopted_source_clean'].eq('Z_PHOTO')

    # Persist augmented catalogue for figure scripts and manual auditing.
    df.to_csv(AUG_PATH, index=False)

    class_summary = summarise_class(df)
    zcomp = redshift_completeness_by_class(df)
    class_sed = score_by_class_and_sed(df)
    zbin = redshift_bin_summary(df)
    stress = selection_stress_tests(df)
    kt_class = known_tev_by_class(df)
    top_non_tev = top_gold_non_tev(df, n=100)

    write_table(class_summary, 'table_class_summary_v0_1_5')
    write_table(zcomp, 'table_redshift_completeness_by_class_v0_1_5')
    write_table(class_sed, 'table_score_by_class_and_sed_v0_1_5')
    write_table(zbin, 'table_redshift_bin_gold_fraction_v0_1_5')
    write_table(stress, 'table_selection_stress_tests_v0_1_5')
    write_table(kt_class, 'table_known_tev_by_class_v0_1_5')
    write_table(top_non_tev, 'table_top_gold_non_tev_candidates_v0_1_5')
    make_latex_snippets(stress, class_summary, zcomp)

    print(f'Augmented score catalogue written: {AUG_PATH}')
    print('Evolutionary diagnostics tables written under tables/.')
    print('Manuscript snippets written: docs/results_snippets_evolutionary_diagnostics_v0_1_5.tex')
    print('\nKey validation rows:')
    key = stress[(stress['stress_sample'] == 'full_sample') & stress['tier_set'].isin(['Gold', 'Gold+Silver', 'Gold+Silver+Bronze'])]
    print(key[['stress_sample', 'tier_set', 'N', 'known_TeV_N', 'tier_size_N', 'known_TeV_in_tier_N',
               'known_TeV_recovery_fraction', 'enrichment_vs_random', 'hypergeom_p_ge_k',
               'AUROC_knownTeV_vs_other', 'mannwhitney_p_greater']].to_string(index=False))
    print('\nClass summary:')
    print(class_summary.to_string(index=False))
    print('\nRedshift completeness by class:')
    print(zcomp.to_string(index=False))


if __name__ == '__main__':
    main()
