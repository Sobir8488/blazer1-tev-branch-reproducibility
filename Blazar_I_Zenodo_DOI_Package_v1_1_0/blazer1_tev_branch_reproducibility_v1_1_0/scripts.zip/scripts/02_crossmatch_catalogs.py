#!/usr/bin/env python
from __future__ import annotations

import argparse
from pathlib import Path
import yaml
import pandas as pd
from blazar_input.crossmatch import nearest_crossmatch


def read_if_exists(path: Path):
    return pd.read_csv(path) if path.exists() else None


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--config", default="configs/config.yaml")
    args = p.parse_args()
    cfg = yaml.safe_load(Path(args.config).read_text())
    m = cfg["matching"]
    base = read_if_exists(Path("data/interim/blazer1_standardized.csv"))
    if base is None:
        raise FileNotFoundError("Need data/interim/blazer1_standardized.csv")
    master = base.copy()
    maps = [
        ("fermi_4fgl_dr4", "fermi", m["blazer1_to_fermi_arcsec_default"]),
        ("allwise", "wise", m["blazer1_to_wise_arcsec"]),
        ("vlass", "vlass", m["blazer1_to_vlass_arcsec"]),
        ("tevcat", "tevcat", m["blazer1_to_tevcat_arcsec"]),
        ("redshift_user", "zcat", 3.0),
    ]
    for key, prefix, radius in maps:
        df = read_if_exists(Path("data/interim") / f"{key}_standardized.csv")
        if df is None:
            print(f"[SKIP] {key}: standardized table not found")
            continue
        print(f"[MATCH] BlazEr1 x {key}, radius={radius} arcsec")
        master = nearest_crossmatch(master, df, radius_arcsec=float(radius), right_prefix=prefix)
    out = Path(cfg["outputs"]["master_catalogue"])
    out.parent.mkdir(parents=True, exist_ok=True)
    master.to_csv(out, index=False)
    print(f"[OK] wrote {out} rows={len(master)} cols={len(master.columns)}")


if __name__ == "__main__":
    main()
