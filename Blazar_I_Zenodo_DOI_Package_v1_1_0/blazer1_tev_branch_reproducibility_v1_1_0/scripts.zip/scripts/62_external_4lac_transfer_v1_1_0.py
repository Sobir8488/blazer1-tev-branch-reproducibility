#!/usr/bin/env python3
"""Reproduce the non-overlapping 4LAC-DR3 transfer audit.

The workflow performs three frozen steps:
1. combine the 4LAC-DR3 high- and low-latitude tables;
2. remove every source represented in BlazEr1 by normalized 4FGL name or
   counterpart position within 3 arcsec;
3. attach frozen TeVCat labels after cohort construction and evaluate an
   X-ray/IR-independent projection of the frozen score architecture.

No coefficient, robust-standardisation constant, percentile fraction, or
validation threshold is fitted to the 4LAC or TeVCat labels.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import re
from pathlib import Path

import astropy.units as u
import numpy as np
import pandas as pd
from astropy.coordinates import SkyCoord, search_around_sky
from astropy.io import fits
from scipy.stats import hypergeom, rankdata

PRIMARY_OVERLAP_RADIUS_ARCSEC = 3.0
TEVCAT_RADIUS_ARCSEC = 180.0
RANDOM_SEED = 8488
BOOTSTRAP_SEED = 260717

FROZEN_CONSTANTS = {
    "gamma_hardness": (2.1249732, 0.3506331208799998),
    "gamma_variability": (1.3749357839135277, 0.41784132167306237),
    "synchrotron_peak_proxy": (12.61258948183325, 0.7762418119031917),
    "ebl_penalty": (0.2556103272531684, 0.15396162250134834),
}


def decode_string_array(values: np.ndarray) -> np.ndarray:
    result: list[str] = []
    for value in values:
        if isinstance(value, (bytes, bytearray, np.bytes_)):
            text = value.decode("utf-8", "ignore").strip()
        else:
            text = str(value).strip()
        if text.lower() in {"", "-", "--", "nan", "none"}:
            text = ""
        result.append(text)
    return np.asarray(result, dtype=object)


def native_endian(values: np.ndarray) -> np.ndarray:
    array = np.asarray(values)
    if array.dtype.byteorder not in ("=", "|"):
        array = array.byteswap().view(array.dtype.newbyteorder("="))
    return array


def load_fits_columns(path: Path, columns: list[str]) -> pd.DataFrame:
    with fits.open(path, memmap=True) as hdul:
        data = hdul[1].data
        output: dict[str, np.ndarray] = {}
        for column in columns:
            values = data[column]
            if values.dtype.kind in "SUO":
                output[column] = decode_string_array(values)
            else:
                output[column] = native_endian(values)
    return pd.DataFrame(output)


def normalize_identifier(value: object) -> str:
    text = str(value).upper().strip()
    if (text.startswith("B'") and text.endswith("'")) or (
        text.startswith('B"') and text.endswith('"')
    ):
        text = text[2:-1]
    return re.sub(r"[^A-Z0-9+\-.]", "", text)


def numeric(values: pd.Series) -> pd.Series:
    return pd.to_numeric(values, errors="coerce").replace([np.inf, -np.inf], np.nan)


def valid_redshift(values: pd.Series) -> pd.Series:
    x = numeric(values)
    return x.gt(0) & x.lt(8)


def finite_positive(values: pd.Series) -> pd.Series:
    return numeric(values).gt(0)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def random_ra_shift_counts(
    left_ra: np.ndarray,
    left_dec: np.ndarray,
    right: SkyCoord,
    radius_arcsec: float,
    n_draws: int,
    seed: int,
) -> np.ndarray:
    rng = np.random.default_rng(seed)
    counts = np.empty(n_draws, dtype=int)
    for draw in range(n_draws):
        shift = rng.uniform(1.0, 359.0)
        shifted = SkyCoord(((left_ra + shift) % 360.0) * u.deg, left_dec * u.deg)
        _, separation, _ = shifted.match_to_catalog_sky(right)
        counts[draw] = int(np.sum(separation.arcsec <= radius_arcsec))
    return counts


def auroc(labels: np.ndarray, scores: np.ndarray) -> float:
    y = np.asarray(labels, dtype=bool)
    s = np.asarray(scores, dtype=float)
    mask = np.isfinite(s)
    y, s = y[mask], s[mask]
    n_pos, n_neg = int(y.sum()), int((~y).sum())
    if n_pos == 0 or n_neg == 0:
        return float("nan")
    ranks = rankdata(s, method="average")
    return float((ranks[y].sum() - n_pos * (n_pos + 1) / 2) / (n_pos * n_neg))


def average_precision(labels: np.ndarray, scores: np.ndarray) -> float:
    y = np.asarray(labels, dtype=bool)
    s = np.asarray(scores, dtype=float)
    mask = np.isfinite(s)
    y, s = y[mask], s[mask]
    if y.sum() == 0:
        return float("nan")
    order = np.argsort(-s, kind="mergesort")
    y = y[order]
    return float(np.sum((np.cumsum(y) / np.arange(1, len(y) + 1)) * y) / y.sum())


def stratified_bootstrap_auc(
    labels: np.ndarray,
    scores: np.ndarray,
    n_bootstrap: int,
    seed: int,
) -> tuple[float, float, float]:
    y = np.asarray(labels, dtype=bool)
    s = np.asarray(scores, dtype=float)
    mask = np.isfinite(s)
    y, s = y[mask], s[mask]
    pos = np.flatnonzero(y)
    neg = np.flatnonzero(~y)
    if len(pos) == 0 or len(neg) == 0:
        return (float("nan"),) * 3
    rng = np.random.default_rng(seed)
    draws = np.empty(n_bootstrap, dtype=float)
    for index in range(n_bootstrap):
        sample = np.r_[
            rng.choice(pos, len(pos), replace=True),
            rng.choice(neg, len(neg), replace=True),
        ]
        draws[index] = auroc(y[sample], s[sample])
    lo, med, hi = np.quantile(draws, [0.025, 0.5, 0.975])
    return float(lo), float(med), float(hi)


def availability_weighted_score(
    frame: pd.DataFrame,
    parts: list[tuple[str, float, float]],
) -> pd.Series:
    numerator = pd.Series(0.0, index=frame.index)
    denominator = pd.Series(0.0, index=frame.index)
    for column, sign, weight in parts:
        values = numeric(frame[column])
        available = values.notna()
        numerator.loc[available] += sign * weight * values.loc[available]
        denominator.loc[available] += abs(weight)
    return numerator / denominator.replace(0, np.nan)


def tier_rows(labels: np.ndarray, scores: np.ndarray, score_variant: str) -> list[dict[str, object]]:
    y = np.asarray(labels, dtype=bool)
    s = np.asarray(scores, dtype=float)
    mask = np.isfinite(s)
    y, s = y[mask], s[mask]
    population_n = len(s)
    positive_n = int(y.sum())
    output: list[dict[str, object]] = []
    for tier, quantile in [("Gold", 0.95), ("Gold+Silver", 0.85), ("Gold+Silver+Bronze", 0.70)]:
        threshold = float(np.nanquantile(s, quantile))
        selected = s >= threshold
        tier_n = int(selected.sum())
        recovered = int(y[selected].sum())
        recovery = recovered / positive_n if positive_n else np.nan
        enrichment = ((recovered / tier_n) / (positive_n / population_n)) if tier_n and positive_n else np.nan
        p_value = float(hypergeom.sf(recovered - 1, population_n, positive_n, tier_n)) if tier_n and positive_n else np.nan
        output.append(
            {
                "score_variant": score_variant,
                "tier": tier,
                "threshold": threshold,
                "tier_size": tier_n,
                "positive_in_tier": recovered,
                "total_positive": positive_n,
                "recovery": recovery,
                "enrichment": enrichment,
                "hypergeom_p": p_value,
            }
        )
    return output


def build_cohort(release_root: Path, n_random_shifts: int) -> dict[str, pd.DataFrame | dict[str, object]]:
    third_party = release_root / "data" / "frozen_third_party_inputs"
    frozen = release_root / "data" / "frozen_analysis_input"

    lac_columns = [
        "Source_Name", "DataRelease", "RAJ2000", "DEJ2000", "GLON", "GLAT",
        "Signif_Avg", "Flux1000", "Energy_Flux100", "SpectrumType", "PL_Index",
        "LP_Index", "LP_beta", "Flags", "CLASS", "ASSOC1", "ASSOC_PROB_BAY",
        "ASSOC_PROB_LR", "Counterpart_Catalog", "RA_Counterpart", "DEC_Counterpart",
        "Unc_Counterpart", "VLBI_Counterpart", "Redshift", "SED_class", "nu_syn",
        "nuFnu_syn", "Variability_Index", "Frac_Variability", "Highest_energy",
    ]
    high = load_fits_columns(third_party / "4lac_dr3_high.fits", lac_columns)
    high.insert(0, "lac_latitude_table", "high")
    low = load_fits_columns(third_party / "4lac_dr3_low.fits", lac_columns)
    low.insert(0, "lac_latitude_table", "low")
    lac = pd.concat([high, low], ignore_index=True)
    lac.insert(0, "lac_index", np.arange(len(lac), dtype=int))

    blazer_columns = [
        "SRC_NAME", "RAJ2000", "DECJ2000", "FGL_SRC_NAME", "FGL_COMMON_SRC_NAME",
        "BLAZAR_CLASS", "LAC_SED_CLASS", "Z_MASTER", "Z_SPEC", "ML_FLUX_1", "DET_LIKE_0",
    ]
    blazer = load_fits_columns(third_party / "blazer1_catalog.fits", blazer_columns)
    blazer.insert(0, "blazer1_index", np.arange(len(blazer), dtype=int))

    lac["source_name_norm"] = lac["Source_Name"].map(normalize_identifier)
    blazer["fgl_name_norm"] = blazer["FGL_SRC_NAME"].map(normalize_identifier)
    blazer.loc[blazer["FGL_SRC_NAME"].eq(""), "fgl_name_norm"] = ""
    name_map = (
        blazer.loc[blazer["fgl_name_norm"].ne("")]
        .groupby("fgl_name_norm")["blazer1_index"]
        .apply(list)
        .to_dict()
    )
    lac["name_match_n"] = lac["source_name_norm"].map(lambda key: len(name_map.get(key, [])))
    lac["name_matched"] = lac["name_match_n"].gt(0)
    lac["name_match_blazer_index"] = lac["source_name_norm"].map(
        lambda key: name_map[key][0] if key in name_map else np.nan
    )

    lac_coord = SkyCoord(lac["RA_Counterpart"].to_numpy(float) * u.deg, lac["DEC_Counterpart"].to_numpy(float) * u.deg)
    blazer_coord = SkyCoord(blazer["RAJ2000"].to_numpy(float) * u.deg, blazer["DECJ2000"].to_numpy(float) * u.deg)
    nearest_idx, nearest_sep, _ = lac_coord.match_to_catalog_sky(blazer_coord)
    lac["nearest_blazer_index"] = nearest_idx.astype(int)
    lac["nearest_sep_arcsec"] = nearest_sep.arcsec

    radius_rows: list[dict[str, object]] = []
    ambiguity_at_primary = 0
    for radius in [0.5, 1, 2, 3, 5, 10, 30, 60]:
        left_idx, right_idx, separations, _ = search_around_sky(lac_coord, blazer_coord, radius * u.arcsec)
        pairs = pd.DataFrame({"lac_index": left_idx, "blazer1_index": right_idx, "sep_arcsec": separations.arcsec})
        counts = pairs.groupby("lac_index").size()
        matched_counts = lac["lac_index"].map(counts).fillna(0).astype(int)
        ambiguous = int((matched_counts > 1).sum())
        if radius == PRIMARY_OVERLAP_RADIUS_ARCSEC:
            ambiguity_at_primary = ambiguous
        radius_rows.append(
            {
                "radius_arcsec": radius,
                "n_4lac_with_position_match": int((matched_counts > 0).sum()),
                "n_4lac_ambiguous_multiple_blazer1": ambiguous,
                "n_unique_blazer1_in_pairs": int(pairs["blazer1_index"].nunique()),
                "n_pairs": int(len(pairs)),
                "n_name_matched": int(lac["name_matched"].sum()),
                "n_overlap_union_name_or_position": int((lac["name_matched"] | lac["nearest_sep_arcsec"].le(radius)).sum()),
            }
        )
    radius_sensitivity = pd.DataFrame(radius_rows)
    radius_sensitivity["n_exclusive_union_name_or_position"] = len(lac) - radius_sensitivity["n_overlap_union_name_or_position"]

    lac["position_matched_primary"] = lac["nearest_sep_arcsec"].le(PRIMARY_OVERLAP_RADIUS_ARCSEC)
    lac["overlap_primary"] = lac["name_matched"] | lac["position_matched_primary"]
    lac["exclusive_primary"] = ~lac["overlap_primary"]
    lac["matched_blazer_index"] = np.where(lac["name_matched"], lac["name_match_blazer_index"], lac["nearest_blazer_index"])
    lac.loc[~lac["overlap_primary"], "matched_blazer_index"] = np.nan
    lac["match_basis"] = np.select(
        [
            lac["name_matched"] & lac["position_matched_primary"],
            lac["name_matched"] & ~lac["position_matched_primary"],
            ~lac["name_matched"] & lac["position_matched_primary"],
        ],
        ["name+position", "name_only", "position_only"],
        default="exclusive",
    )

    name_separation = np.full(len(lac), np.nan)
    name_mask = lac["name_matched"].to_numpy()
    if name_mask.any():
        selected = lac.loc[name_mask, "name_match_blazer_index"].astype(int).to_numpy()
        name_separation[name_mask] = lac_coord[name_mask].separation(blazer_coord[selected]).arcsec
    lac["name_match_sep_arcsec"] = name_separation
    lac["name_position_discordant_gt3arcsec"] = lac["name_matched"] & lac["name_match_sep_arcsec"].gt(PRIMARY_OVERLAP_RADIUS_ARCSEC)

    attach_columns = [
        "SRC_NAME", "FGL_SRC_NAME", "FGL_COMMON_SRC_NAME", "RAJ2000", "DECJ2000",
        "BLAZAR_CLASS", "LAC_SED_CLASS", "Z_MASTER", "Z_SPEC", "ML_FLUX_1", "DET_LIKE_0",
    ]
    for column in attach_columns:
        values: list[object] = []
        is_text = blazer[column].dtype.kind in "OUS"
        for match_index in lac["matched_blazer_index"]:
            values.append("" if is_text else np.nan) if pd.isna(match_index) else values.append(blazer.loc[int(match_index), column])
        lac[f"blazer1_{column}"] = values

    lac["duplicate_source_name"] = lac["source_name_norm"].duplicated(keep=False)
    left_idx, right_idx, _, _ = search_around_sky(lac_coord, lac_coord, 0.1 * u.arcsec)
    near_duplicates = {(int(i), int(j)) for i, j in zip(left_idx, right_idx) if i < j}
    duplicate_indices = {index for pair in near_duplicates for index in pair}
    lac["near_duplicate_counterpart_0p1arcsec"] = lac["lac_index"].isin(duplicate_indices)

    tevcat = pd.read_csv(frozen / "tevcat_standardized.csv")
    tevcat_coord = SkyCoord(tevcat["ra_deg"].to_numpy(float) * u.deg, tevcat["dec_deg"].to_numpy(float) * u.deg)
    tev_idx, tev_sep, _ = lac_coord.match_to_catalog_sky(tevcat_coord)
    lac["tevcat_nearest_row"] = tev_idx.astype(int)
    lac["tevcat_nearest_sep_arcsec"] = tev_sep.arcsec
    lac["tevcat_matched_180"] = lac["tevcat_nearest_sep_arcsec"].le(TEVCAT_RADIUS_ARCSEC)
    for column in ["name", "alt_name", "source_type", "redshift"]:
        lac[f"tevcat_{column}"] = "" if column != "redshift" else np.nan
    for row_index in np.flatnonzero(lac["tevcat_matched_180"].to_numpy()):
        source_index = int(lac.loc[row_index, "tevcat_nearest_row"])
        for column in ["name", "alt_name", "source_type", "redshift"]:
            lac.loc[row_index, f"tevcat_{column}"] = tevcat.loc[source_index, column]
    lac["tevcat_firm_extragalactic"] = lac["tevcat_matched_180"] & lac["tevcat_source_type"].ne("UNID")

    tevcat_radius_rows: list[dict[str, object]] = []
    for radius in [30, 60, 120, 180, 300]:
        left_idx, right_idx, separations, _ = search_around_sky(lac_coord, tevcat_coord, radius * u.arcsec)
        pairs = pd.DataFrame({"lac_index": left_idx, "tevcat_index": right_idx, "sep_arcsec": separations.arcsec})
        counts = pairs.groupby("lac_index").size()
        pair_count = lac["lac_index"].map(counts).fillna(0).astype(int)
        for cohort_name, mask in {
            "all_4lac": np.ones(len(lac), dtype=bool),
            "blazer1_overlap": lac["overlap_primary"].to_numpy(),
            "4lac_exclusive": lac["exclusive_primary"].to_numpy(),
        }.items():
            tevcat_radius_rows.append(
                {
                    "radius_arcsec": radius,
                    "cohort": cohort_name,
                    "N_cohort": int(mask.sum()),
                    "N_TeVCat_matched": int(((pair_count > 0).to_numpy() & mask).sum()),
                    "N_ambiguous_multiple_TeVCat": int(((pair_count > 1).to_numpy() & mask).sum()),
                }
            )

    lac["has_gamma_spectral_index"] = np.isfinite(numeric(lac["PL_Index"])) | np.isfinite(numeric(lac["LP_Index"]))
    lac["has_gamma_variability"] = np.isfinite(numeric(lac["Frac_Variability"])) | np.isfinite(numeric(lac["Variability_Index"]))
    lac["has_nu_syn"] = finite_positive(lac["nu_syn"])
    lac["has_redshift_4lac"] = valid_redshift(lac["Redshift"])
    lac["has_native_gamma_peak"] = lac["has_gamma_spectral_index"] & lac["has_gamma_variability"] & lac["has_nu_syn"]
    lac["has_native_gamma_peak_z"] = lac["has_native_gamma_peak"] & lac["has_redshift_4lac"]

    sample_flow = pd.DataFrame(
        [
            ("4LAC-DR3 high-latitude", int((lac["lac_latitude_table"] == "high").sum()), "Frozen high-latitude table"),
            ("4LAC-DR3 low-latitude", int((lac["lac_latitude_table"] == "low").sum()), "Frozen low-latitude table"),
            ("4LAC union", len(lac), "High+low; zero duplicate normalized Source_Name rows"),
            ("Valid counterpart coordinates", int((np.isfinite(lac["RA_Counterpart"]) & np.isfinite(lac["DEC_Counterpart"])).sum()), "Finite 4LAC counterpart positions"),
            ("Exact normalized 4FGL-name overlap", int(lac["name_matched"].sum()), "4LAC Source_Name versus BlazEr1 FGL_SRC_NAME"),
            ("Counterpart-position overlap within 3 arcsec", int(lac["position_matched_primary"].sum()), "4LAC counterpart versus BlazEr1 catalogue position"),
            ("Primary overlap: name OR position", int(lac["overlap_primary"].sum()), "Dual-key physical overlap"),
            ("Primary 4LAC-exclusive cohort", int(lac["exclusive_primary"].sum()), "4LAC union minus primary overlap"),
            ("Overlap: name+position", int((lac["match_basis"] == "name+position").sum()), "Concordant dual-key match"),
            ("Overlap: position only", int((lac["match_basis"] == "position_only").sum()), "Release-shifted FGL name or non-FGL BlazEr1 entry"),
            ("Overlap: name only", int((lac["match_basis"] == "name_only").sum()), "Name/coordinate discordance audit"),
            ("Ambiguous overlap within 3 arcsec", ambiguity_at_primary, "Number of 4LAC rows with multiple BlazEr1 neighbours"),
            ("Firm extragalactic TeVCat positives: overlap", int((lac["overlap_primary"] & lac["tevcat_firm_extragalactic"]).sum()), "Frozen TeVCat; 180 arcsec; UNID excluded"),
            ("Firm extragalactic TeVCat positives: exclusive", int((lac["exclusive_primary"] & lac["tevcat_firm_extragalactic"]).sum()), "External-cohort transfer positives"),
        ],
        columns=["stage", "N", "detail"],
    )

    evaluability_rows: list[dict[str, object]] = []
    for cohort_name, mask in {
        "all_4lac": np.ones(len(lac), dtype=bool),
        "blazer1_overlap": lac["overlap_primary"].to_numpy(),
        "4lac_exclusive": lac["exclusive_primary"].to_numpy(),
    }.items():
        subset = lac.loc[mask]
        denominator = len(subset)
        stages = [
            ("C0_cohort", np.ones(denominator, dtype=bool), "Cohort after overlap definition"),
            ("C1_valid_counterpart_coordinates", np.isfinite(subset["RA_Counterpart"]) & np.isfinite(subset["DEC_Counterpart"]), "Valid 4LAC counterpart position"),
            ("C2_gamma_spectral_index", subset["has_gamma_spectral_index"], "PL or LP index available"),
            ("C3_gamma_variability", subset["has_gamma_variability"], "Catalogue variability measure available"),
            ("C4_continuous_nu_syn", subset["has_nu_syn"], "Positive continuous 4LAC synchrotron peak"),
            ("C5_redshift_4lac", subset["has_redshift_4lac"], "Finite 0<z<8 in 4LAC"),
            ("C6_native_gamma_peak_complete", subset["has_native_gamma_peak"], "Gamma spectral + variability + continuous peak"),
            ("C7_native_gamma_peak_redshift_complete", subset["has_native_gamma_peak_z"], "C6 plus 4LAC redshift"),
            ("V1_firm_extragalactic_TeVCat", subset["tevcat_firm_extragalactic"], "Validation labels attached after cohort definition"),
        ]
        for stage, stage_mask, detail in stages:
            count = int(np.asarray(stage_mask, dtype=bool).sum())
            evaluability_rows.append({"cohort": cohort_name, "stage": stage, "N": count, "denominator": denominator, "fraction": count / denominator if denominator else np.nan, "detail": detail})
        positives = subset.loc[subset["tevcat_firm_extragalactic"]]
        positive_denominator = len(positives)
        for stage, stage_mask, detail in [
            ("V2_TeVCat_with_native_gamma_peak", positives["has_native_gamma_peak"], "Firm positives evaluable for gamma+peak layer"),
            ("V3_TeVCat_with_native_gamma_peak_z", positives["has_native_gamma_peak_z"], "Firm positives evaluable for gamma+peak+redshift"),
        ]:
            count = int(np.asarray(stage_mask, dtype=bool).sum())
            evaluability_rows.append({"cohort": cohort_name, "stage": stage, "N": count, "denominator": positive_denominator, "fraction": count / positive_denominator if positive_denominator else np.nan, "detail": detail})
    evaluability = pd.DataFrame(evaluability_rows)

    composition_rows: list[dict[str, object]] = []
    for cohort_name, mask in {
        "all_4lac": np.ones(len(lac), dtype=bool),
        "blazer1_overlap": lac["overlap_primary"].to_numpy(),
        "4lac_exclusive": lac["exclusive_primary"].to_numpy(),
    }.items():
        subset = lac.loc[mask]
        for dimension in ["lac_latitude_table", "CLASS", "SED_class"]:
            normalized = subset[dimension].replace("", "missing")
            for level, count in normalized.value_counts(dropna=False).items():
                composition_rows.append({"cohort": cohort_name, "dimension": dimension, "level": level, "N": int(count), "fraction": count / len(subset)})
        zmask = valid_redshift(subset["Redshift"])
        for level, count in [("yes", int(zmask.sum())), ("no", int((~zmask).sum()))]:
            composition_rows.append({"cohort": cohort_name, "dimension": "redshift_available", "level": level, "N": count, "fraction": count / len(subset)})
    composition = pd.DataFrame(composition_rows)

    overlap_null = random_ra_shift_counts(
        lac["RA_Counterpart"].to_numpy(float), lac["DEC_Counterpart"].to_numpy(float),
        blazer_coord, PRIMARY_OVERLAP_RADIUS_ARCSEC, n_random_shifts, RANDOM_SEED,
    )
    firm_tevcat = tevcat.loc[tevcat["source_type"].ne("UNID")].reset_index(drop=True)
    firm_tev_coord = SkyCoord(firm_tevcat["ra_deg"].to_numpy(float) * u.deg, firm_tevcat["dec_deg"].to_numpy(float) * u.deg)
    exclusive = lac.loc[lac["exclusive_primary"]]
    tevcat_null = random_ra_shift_counts(
        exclusive["RA_Counterpart"].to_numpy(float), exclusive["DEC_Counterpart"].to_numpy(float),
        firm_tev_coord, TEVCAT_RADIUS_ARCSEC, n_random_shifts, RANDOM_SEED,
    )
    null_summary = pd.DataFrame(
        [
            {"test": "4LAC_to_BlazEr1_overlap_3arcsec", "observed": int(lac["position_matched_primary"].sum()), "n_random_shifts": len(overlap_null), "random_mean": float(overlap_null.mean()), "random_median": float(np.median(overlap_null)), "random_p95": float(np.quantile(overlap_null, 0.95)), "random_max": int(overlap_null.max())},
            {"test": "4LAC_exclusive_to_firm_TeVCat_180arcsec", "observed": int((lac["exclusive_primary"] & lac["tevcat_firm_extragalactic"]).sum()), "n_random_shifts": len(tevcat_null), "random_mean": float(tevcat_null.mean()), "random_median": float(np.median(tevcat_null)), "random_p95": float(np.quantile(tevcat_null, 0.95)), "random_max": int(tevcat_null.max())},
        ]
    )

    known_34 = pd.read_csv(release_root / "tables" / "table_tevcat_actual_associations_v0_4_2.csv")
    overlap_tev_names = set(lac.loc[lac["overlap_primary"] & lac["tevcat_firm_extragalactic"], "tevcat_name"].map(normalize_identifier))
    frozen_tev_names = set(known_34["tevcat_name"].map(normalize_identifier))
    crosscheck = pd.DataFrame(
        [{"check": "overlap_TeVCat_identity_equals_frozen_BlazEr1_34", "N_overlap_firm_TeVCat": len(overlap_tev_names), "N_frozen_BlazEr1_TeVCat": len(frozen_tev_names), "N_identity_intersection": len(overlap_tev_names & frozen_tev_names), "PASS": overlap_tev_names == frozen_tev_names}]
    )

    decision = {
        "analysis_name": "4LAC-DR3 non-overlapping external-cohort transfer",
        "primary_overlap_definition": {
            "name_key": "normalized 4LAC Source_Name equals BlazEr1 FGL_SRC_NAME",
            "position_key": "4LAC counterpart coordinate within 3 arcsec of BlazEr1 catalogue coordinate",
            "union": True,
            "name_preferred": True,
        },
        "validation_label_definition": {
            "catalogue": "frozen TeVCat",
            "radius_arcsec": TEVCAT_RADIUS_ARCSEC,
            "firm_extragalactic": "source_type != UNID",
            "attached_after_cohort_construction": True,
        },
        "counts": {
            "4lac_union": int(len(lac)),
            "overlap_primary": int(lac["overlap_primary"].sum()),
            "exclusive_primary": int(lac["exclusive_primary"].sum()),
            "position_only_overlap": int((lac["match_basis"] == "position_only").sum()),
            "ambiguous_overlap_3arcsec": ambiguity_at_primary,
            "firm_tevcat_overlap": int((lac["overlap_primary"] & lac["tevcat_firm_extragalactic"]).sum()),
            "firm_tevcat_exclusive": int((lac["exclusive_primary"] & lac["tevcat_firm_extragalactic"]).sum()),
        },
        "input_sha256": {
            name: sha256(third_party / name)
            for name in ["4lac_dr3_high.fits", "4lac_dr3_low.fits", "blazer1_catalog.fits"]
        } | {"tevcat_standardized.csv": sha256(frozen / "tevcat_standardized.csv")},
    }

    return {
        "lac": lac,
        "sample_flow": sample_flow,
        "radius_sensitivity": radius_sensitivity,
        "tevcat_radius_sensitivity": pd.DataFrame(tevcat_radius_rows),
        "evaluability": evaluability,
        "composition": composition,
        "null_summary": null_summary,
        "overlap_null_draws": pd.DataFrame({"draw": np.arange(len(overlap_null)), "random_matches": overlap_null}),
        "tevcat_null_draws": pd.DataFrame({"draw": np.arange(len(tevcat_null)), "random_matches": tevcat_null}),
        "crosscheck": crosscheck,
        "decision": decision,
    }


def score_transfer(exclusive: pd.DataFrame, n_bootstrap: int) -> dict[str, pd.DataFrame | dict[str, object]]:
    frame = exclusive.copy()
    pl_index = numeric(frame["PL_Index"])
    variability = numeric(frame["Variability_Index"])
    nu_syn = numeric(frame["nu_syn"]).where(numeric(frame["nu_syn"]).gt(0))
    redshift = numeric(frame["Redshift"]).where(valid_redshift(frame["Redshift"]))

    gamma_hard_med, gamma_hard_scale = FROZEN_CONSTANTS["gamma_hardness"]
    gamma_var_med, gamma_var_scale = FROZEN_CONSTANTS["gamma_variability"]
    peak_med, peak_scale = FROZEN_CONSTANTS["synchrotron_peak_proxy"]
    ebl_med, ebl_scale = FROZEN_CONSTANTS["ebl_penalty"]

    frame["S_gamma_hard_transfer"] = (gamma_hard_med - pl_index) / gamma_hard_scale
    frame["S_gamma_var_transfer"] = (np.log10(variability.where(variability.gt(0))) - gamma_var_med) / gamma_var_scale
    frame["S_nu_peak_transfer"] = (np.log10(nu_syn) - peak_med) / peak_scale
    frame["S_EBL_transfer"] = (np.log10(1 + redshift) - ebl_med) / ebl_scale

    frame["S_gamma_only_transfer"] = availability_weighted_score(frame, [("S_gamma_hard_transfer", 1, 1.0), ("S_gamma_var_transfer", 1, 0.35)])
    frame["S_gamma_peak_transfer"] = availability_weighted_score(frame, [("S_gamma_hard_transfer", 1, 1.0), ("S_gamma_var_transfer", 1, 0.35), ("S_nu_peak_transfer", 1, 1.0)])
    frame["S_fully_no_x_no_ir_transfer"] = availability_weighted_score(frame, [("S_gamma_hard_transfer", 1, 1.0), ("S_gamma_var_transfer", 1, 0.35), ("S_nu_peak_transfer", 1, 1.0), ("S_EBL_transfer", -1, 0.8)])
    complete = frame[["S_gamma_hard_transfer", "S_gamma_var_transfer", "S_nu_peak_transfer", "S_EBL_transfer"]].notna().all(axis=1)
    frame["S_fully_no_x_no_ir_complete"] = frame["S_fully_no_x_no_ir_transfer"].where(complete)

    labels = frame["tevcat_firm_extragalactic"].fillna(False).astype(bool).to_numpy()
    variants = [
        ("Gamma only", "S_gamma_only_transfer"),
        ("Gamma + peak", "S_gamma_peak_transfer"),
        ("Fully no-X/no-IR, availability weighted", "S_fully_no_x_no_ir_transfer"),
        ("Fully no-X/no-IR, complete case", "S_fully_no_x_no_ir_complete"),
    ]
    metrics_rows: list[dict[str, object]] = []
    tier_output: list[dict[str, object]] = []
    for offset, (name, column) in enumerate(variants):
        scores = numeric(frame[column]).to_numpy(float)
        mask = np.isfinite(scores)
        lo, median, hi = stratified_bootstrap_auc(labels, scores, n_bootstrap, BOOTSTRAP_SEED + offset)
        metrics_rows.append(
            {
                "score_variant": name,
                "score_column": column,
                "N": int(mask.sum()),
                "N_positive": int(labels[mask].sum()),
                "prevalence": float(labels[mask].mean()),
                "AUROC": auroc(labels, scores),
                "AUROC_bootstrap_low": lo,
                "AUROC_bootstrap_median": median,
                "AUROC_bootstrap_high": hi,
                "average_precision": average_precision(labels, scores),
                "n_bootstrap": n_bootstrap,
            }
        )
        tier_output.extend(tier_rows(labels, scores, name))
    metrics = pd.DataFrame(metrics_rows)
    tiers = pd.DataFrame(tier_output)

    coverage = pd.DataFrame(
        [
            {"component": column, "N": int(frame[column].notna().sum()), "fraction": float(frame[column].notna().mean()), "N_positive": int((frame[column].notna() & frame["tevcat_firm_extragalactic"].fillna(False)).sum())}
            for column in ["S_gamma_hard_transfer", "S_gamma_var_transfer", "S_nu_peak_transfer", "S_EBL_transfer"]
        ]
    )

    availability_count = frame[["S_gamma_hard_transfer", "S_gamma_var_transfer", "S_nu_peak_transfer", "S_EBL_transfer"]].notna().sum(axis=1)
    availability_null = pd.DataFrame(
        [
            {"diagnostic": "available_component_count", "N": len(frame), "N_positive": int(labels.sum()), "AUROC": auroc(labels, availability_count.to_numpy(float))},
            {"diagnostic": "peak_available_binary", "N": len(frame), "N_positive": int(labels.sum()), "AUROC": auroc(labels, frame["S_nu_peak_transfer"].notna().astype(float).to_numpy())},
            {"diagnostic": "redshift_available_binary", "N": len(frame), "N_positive": int(labels.sum()), "AUROC": auroc(labels, frame["S_EBL_transfer"].notna().astype(float).to_numpy())},
        ]
    )

    class_lower = frame["CLASS"].fillna("").astype(str).str.lower()
    sed_upper = frame["SED_class"].fillna("").astype(str).str.upper()
    subsets = {
        "full": np.ones(len(frame), dtype=bool),
        "redshift_available": frame["S_EBL_transfer"].notna().to_numpy(),
        "peak_available": frame["S_nu_peak_transfer"].notna().to_numpy(),
        "peak_and_redshift": complete.to_numpy(),
        "HSP_SED": sed_upper.eq("HSP").to_numpy(),
        "BL_Lac_like": class_lower.isin(["bll", "bllac"]).to_numpy(),
        "high_latitude": frame["lac_latitude_table"].eq("high").to_numpy(),
    }
    conditioning_rows: list[dict[str, object]] = []
    primary_scores = numeric(frame["S_fully_no_x_no_ir_transfer"]).to_numpy(float)
    for name, subset_mask in subsets.items():
        mask = np.asarray(subset_mask, dtype=bool) & np.isfinite(primary_scores)
        subset_labels = labels[mask]
        subset_scores = primary_scores[mask]
        if subset_labels.sum() == 0 or (~subset_labels).sum() == 0:
            continue
        tier = tier_rows(subset_labels, subset_scores, name)[0]
        conditioning_rows.append(
            {
                "subset": name,
                "N": int(mask.sum()),
                "N_positive": int(subset_labels.sum()),
                "AUROC": auroc(subset_labels, subset_scores),
                "gold_size": tier["tier_size"],
                "gold_positive": tier["positive_in_tier"],
                "gold_recovery": tier["recovery"],
                "gold_enrichment": tier["enrichment"],
                "gold_hypergeom_p": tier["hypergeom_p"],
            }
        )
    conditioning = pd.DataFrame(conditioning_rows)

    compact_columns = [
        "Source_Name", "RAJ2000", "DEJ2000", "RA_Counterpart", "DEC_Counterpart",
        "lac_latitude_table", "CLASS", "SED_class", "Redshift", "nu_syn", "PL_Index",
        "Variability_Index", "Energy_Flux100", "tevcat_firm_extragalactic", "tevcat_name",
        "tevcat_source_type", "tevcat_nearest_sep_arcsec", "S_gamma_hard_transfer",
        "S_gamma_var_transfer", "S_nu_peak_transfer", "S_EBL_transfer",
        "S_gamma_only_transfer", "S_gamma_peak_transfer", "S_fully_no_x_no_ir_transfer",
        "S_fully_no_x_no_ir_complete",
    ]
    compact = frame[compact_columns].copy()

    metadata = {
        "analysis_status": "FROZEN_EXTERNAL_COHORT_TRANSFER",
        "interpretation": "Transportability audit, not a calibrated TeV detection probability and not a test of universal X-ray dominance.",
        "parent_N": int(len(frame)),
        "firm_extragalactic_TeVCat_N": int(labels.sum()),
        "frozen_standardisation_constants": FROZEN_CONSTANTS,
        "score_definition": {
            "fully_no_x_no_ir": "Availability-weighted gamma hardness + gamma variability + synchrotron peak - redshift/EBL penalty; direct X-ray, X-ray-dependent Compton dominance, and WISE/IR are excluded.",
            "weights": {"gamma_hardness": 1.0, "gamma_variability": 0.35, "synchrotron_peak_proxy": 1.0, "ebl_penalty": -0.8},
            "complete_case": "All four retained components required.",
        },
        "tier_fractions": {"Gold": 0.05, "Gold+Silver": 0.15, "Gold+Silver+Bronze": 0.30},
        "n_bootstrap": n_bootstrap,
        "bootstrap_seed": BOOTSTRAP_SEED,
    }
    return {"compact": compact, "metrics": metrics, "tiers": tiers, "coverage": coverage, "availability_null": availability_null, "conditioning": conditioning, "metadata": metadata}


def write_outputs(release_root: Path, cohort: dict[str, object], transfer: dict[str, object]) -> None:
    data_dir = release_root / "data" / "external_transfer"
    tables_dir = release_root / "tables"
    provenance_dir = release_root / "provenance" / "external_transfer"
    data_dir.mkdir(parents=True, exist_ok=True)
    provenance_dir.mkdir(parents=True, exist_ok=True)

    lac = cohort["lac"]
    assert isinstance(lac, pd.DataFrame)
    lac.loc[lac["exclusive_primary"]].to_csv(data_dir / "4lac_exclusive_cohort_v1_1_0.csv", index=False)
    lac.loc[lac["overlap_primary"]].to_csv(data_dir / "4lac_blazer1_overlap_v1_1_0.csv", index=False)
    lac.loc[lac["exclusive_primary"] & lac["tevcat_firm_extragalactic"]].to_csv(data_dir / "4lac_exclusive_firm_tev_associations_v1_1_0.csv", index=False)
    transfer["compact"].to_csv(data_dir / "4lac_exclusive_transfer_scores_v1_1_0.csv", index=False)

    table_map = {
        "sample_flow": "table_4lac_transfer_sample_flow_v1_1_0.csv",
        "radius_sensitivity": "table_4lac_overlap_radius_sensitivity_v1_1_0.csv",
        "tevcat_radius_sensitivity": "table_4lac_tevcat_radius_sensitivity_v1_1_0.csv",
        "evaluability": "table_4lac_transfer_evaluability_v1_1_0.csv",
        "composition": "table_4lac_transfer_cohort_composition_v1_1_0.csv",
        "null_summary": "table_4lac_transfer_random_shift_summary_v1_1_0.csv",
        "crosscheck": "table_4lac_transfer_frozen_34_crosscheck_v1_1_0.csv",
    }
    for key, filename in table_map.items():
        value = cohort[key]
        assert isinstance(value, pd.DataFrame)
        value.to_csv(tables_dir / filename, index=False)
    transfer_table_map = {
        "metrics": "table_4lac_transfer_metrics_v1_1_0.csv",
        "tiers": "table_4lac_transfer_tier_enrichment_v1_1_0.csv",
        "coverage": "table_4lac_transfer_feature_coverage_v1_1_0.csv",
        "availability_null": "table_4lac_transfer_availability_null_v1_1_0.csv",
        "conditioning": "table_4lac_transfer_conditioning_v1_1_0.csv",
    }
    for key, filename in transfer_table_map.items():
        value = transfer[key]
        assert isinstance(value, pd.DataFrame)
        value.to_csv(tables_dir / filename, index=False)

    cohort["overlap_null_draws"].to_csv(provenance_dir / "4lac_blazer1_random_shift_draws_v1_1_0.csv", index=False)
    cohort["tevcat_null_draws"].to_csv(provenance_dir / "4lac_tevcat_random_shift_draws_v1_1_0.csv", index=False)
    (provenance_dir / "4lac_transfer_cohort_decision_v1_1_0.json").write_text(json.dumps(cohort["decision"], indent=2), encoding="utf-8")
    (provenance_dir / "4lac_transfer_score_definition_v1_1_0.json").write_text(json.dumps(transfer["metadata"], indent=2), encoding="utf-8")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--release-root", type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument("--n-bootstrap", type=int, default=20000)
    parser.add_argument("--n-random-shifts", type=int, default=250)
    args = parser.parse_args()
    release_root = args.release_root.resolve()
    if args.n_bootstrap < 10:
        raise ValueError("--n-bootstrap must be at least 10")
    if args.n_random_shifts < 10:
        raise ValueError("--n-random-shifts must be at least 10")

    cohort = build_cohort(release_root, args.n_random_shifts)
    lac = cohort["lac"]
    assert isinstance(lac, pd.DataFrame)
    transfer = score_transfer(lac.loc[lac["exclusive_primary"]].reset_index(drop=True), args.n_bootstrap)
    write_outputs(release_root, cohort, transfer)

    print(cohort["sample_flow"].to_string(index=False))
    print("\nTransfer metrics")
    print(transfer["metrics"].to_string(index=False))


if __name__ == "__main__":
    main()
