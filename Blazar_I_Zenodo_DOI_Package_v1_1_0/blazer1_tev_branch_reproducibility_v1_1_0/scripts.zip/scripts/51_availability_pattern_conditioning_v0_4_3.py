from __future__ import annotations

import os
import sys
from pathlib import Path
sys.path.append(str(Path(__file__).resolve().parent))

import numpy as np
import pandas as pd

from _v043_helpers import (
    PROCESSED, TABLES, load_frozen_catalogue, numeric, availability_pattern,
    auroc, within_pattern_percentile,
)


def conditional_permutation_p(
    labels: pd.Series,
    conditioned_score: pd.Series,
    patterns: pd.Series,
    eligible: pd.Series,
    n_perm: int,
    seed: int,
) -> tuple[float, float, float, float]:
    """Exact-pattern label permutation using precomputed score ranks.

    The number of positive labels is held fixed within each availability pattern.
    Rank sums are used directly, avoiding repeated score sorting in each draw.
    """
    y = labels[eligible].to_numpy(dtype=bool)
    s = numeric(conditioned_score[eligible]).to_numpy(dtype=float)
    p = patterns[eligible].astype(str).to_numpy()
    valid = np.isfinite(s)
    y, s, p = y[valid], s[valid], p[valid]
    n_pos = int(y.sum()); n_neg = int((~y).sum())
    if n_pos == 0 or n_neg == 0:
        return np.nan, np.nan, np.nan, np.nan
    ranks = pd.Series(s).rank(method="average").to_numpy(dtype=float)
    observed_u = ranks[y].sum() - n_pos*(n_pos+1)/2.0
    observed = float(observed_u/(n_pos*n_neg))
    groups = {g: np.flatnonzero(p == g) for g in np.unique(p)}
    rng = np.random.default_rng(seed)
    vals = np.empty(n_perm, dtype=float)
    yp = y.copy()
    for i in range(n_perm):
        for idx in groups.values():
            yp[idx] = rng.permutation(y[idx])
        u = ranks[yp].sum() - n_pos*(n_pos+1)/2.0
        vals[i] = u/(n_pos*n_neg)
    p_greater = float((np.sum(vals >= observed) + 1)/(n_perm + 1))
    return observed, float(np.nanmedian(vals)), float(np.nanpercentile(vals, 97.5)), p_greater


def clustered_case_concordance(
    df: pd.DataFrame,
    score: pd.Series,
    patterns: pd.Series,
    n_boot: int,
    seed: int,
) -> tuple[pd.DataFrame, dict]:
    known = df["is_known_tev"].astype(bool)
    rows = []
    s = numeric(score)
    for idx in df.index[known]:
        pat = patterns.loc[idx]
        controls = df.index[(~known) & patterns.eq(pat) & s.notna()]
        if not np.isfinite(s.loc[idx]) or len(controls) == 0:
            continue
        vals = s.loc[controls].to_numpy(dtype=float)
        case = float(s.loc[idx])
        concordance = float(np.mean(vals < case) + 0.5*np.mean(vals == case))
        rows.append({
            "known_row_id": int(idx),
            "availability_pattern": pat,
            "control_pool_N": int(len(controls)),
            "case_score": case,
            "case_concordance_vs_exact_pattern_controls": concordance,
        })
    case = pd.DataFrame(rows)
    vals = case["case_concordance_vs_exact_pattern_controls"].to_numpy(dtype=float)
    rng = np.random.default_rng(seed)
    boot = np.empty(n_boot, dtype=float)
    for i in range(n_boot):
        boot[i] = np.mean(rng.choice(vals, size=len(vals), replace=True))
    summary = {
        "known_cases_N": len(case),
        "mean_case_concordance": float(np.mean(vals)),
        "median_case_concordance": float(np.median(vals)),
        "cluster_bootstrap_ci95_low": float(np.percentile(boot, 2.5)),
        "cluster_bootstrap_ci95_high": float(np.percentile(boot, 97.5)),
        "n_boot": n_boot,
    }
    return case, summary


def main() -> None:
    augmented = PROCESSED / "tev_evolution_score_catalog_v0_4_3_score_architecture_augmented.csv"
    if augmented.exists():
        df = pd.read_csv(augmented, low_memory=False)
        df["is_known_tev"] = df["is_known_tev"].astype(str).str.lower().isin({"true", "1", "yes"})
    else:
        df, _ = load_frozen_catalogue()
        raise FileNotFoundError("Run scripts/50_score_architecture_variants_v0_4_3.py first.")

    n_perm = int(os.environ.get("BLAZER_V043_N_PERM", "5000"))
    n_boot = int(os.environ.get("BLAZER_V043_N_BOOT", "5000"))
    seed = int(os.environ.get("BLAZER_V043_SEED", "8488"))

    patterns = availability_pattern(df)
    known = df["is_known_tev"].astype(bool)
    pat_summary = pd.DataFrame({"availability_pattern": patterns, "is_known_tev": known}).groupby("availability_pattern").agg(
        sources_N=("is_known_tev", "size"), known_TeV_N=("is_known_tev", "sum")
    ).reset_index()
    pat_summary["nonTeV_N"] = pat_summary["sources_N"] - pat_summary["known_TeV_N"]
    pat_summary["known_TeV_fraction"] = pat_summary["known_TeV_N"] / pat_summary["sources_N"]
    pat_summary["represented_among_known_TeV"] = pat_summary["known_TeV_N"] > 0
    pat_summary = pat_summary.sort_values(["known_TeV_N", "sources_N"], ascending=False)
    pat_summary.to_csv(TABLES / "table_availability_pattern_summary_v0_4_3.csv", index=False)

    represented = set(pat_summary.loc[pat_summary["known_TeV_N"] > 0, "availability_pattern"])
    eligible = patterns.isin(represented)

    variants = {
        "published_available": numeric(df["S_arch_published_available_v0_4_3"]),
        "active_available": numeric(df["S_arch_active_available_v0_4_3"]),
        "fixed_active_weight": numeric(df["S_arch_fixed_active_weight_v0_4_3"]),
        "xray_only": numeric(df["S_xray_only_v0_1_8"]),
        "no_xray": numeric(df["S_no_xray_v0_1_8"]),
    }

    rows = []
    exact_rows = []
    case_summaries = []
    assignment = pd.DataFrame({
        "row_id": np.arange(len(df), dtype=int),
        "is_known_tev": known,
        "availability_pattern": patterns,
        "eligible_pattern_conditioned_pool": eligible,
    })

    for name, s in variants.items():
        conditioned = within_pattern_percentile(s, patterns, eligible=eligible)
        assignment[f"within_pattern_percentile_{name}"] = conditioned
        obs, null_med, null_q975, p_perm = conditional_permutation_p(
            known, conditioned, patterns, eligible, n_perm=n_perm, seed=seed
        )
        rows.append({
            "score_variant": name,
            "unrestricted_N": int(s.notna().sum()),
            "unrestricted_known_TeV_N": int(known[s.notna()].sum()),
            "unrestricted_AUROC": auroc(known, s),
            "represented_pattern_pool_N": int(eligible.sum()),
            "represented_pattern_pool_known_TeV_N": int(known[eligible].sum()),
            "represented_pattern_pool_AUROC_raw_score": auroc(known[eligible], s[eligible]),
            "within_pattern_percentile_AUROC": obs,
            "conditional_permutation_null_median": null_med,
            "conditional_permutation_null_q97p5": null_q975,
            "conditional_permutation_p_greater": p_perm,
            "n_permutations": n_perm,
        })

        for pattern in sorted(represented):
            mask = patterns.eq(pattern) & s.notna()
            exact_rows.append({
                "availability_pattern": pattern,
                "score_variant": name,
                "analysis_N": int(mask.sum()),
                "known_TeV_N": int((mask & known).sum()),
                "AUROC": auroc(known[mask], s[mask]),
            })

        case, csum = clustered_case_concordance(df, s, patterns, n_boot=n_boot, seed=seed)
        case["score_variant"] = name
        case.to_csv(TABLES / f"table_exact_pattern_case_concordance_{name}_v0_4_3.csv", index=False)
        case_summaries.append({"score_variant": name, **csum})

    validation = pd.DataFrame(rows)
    validation.to_csv(TABLES / "table_pattern_conditioned_validation_v0_4_3.csv", index=False)
    pd.DataFrame(exact_rows).to_csv(TABLES / "table_exact_pattern_auroc_v0_4_3.csv", index=False)
    pd.DataFrame(case_summaries).to_csv(TABLES / "table_exact_pattern_case_concordance_summary_v0_4_3.csv", index=False)
    assignment.to_csv(TABLES / "table_pattern_conditioned_assignments_v0_4_3.csv", index=False)

    print("v0.4.3 availability-pattern conditioning complete.")
    print(f"Patterns represented among known TeV: {sorted(represented)}")
    print(f"Pattern-conditioned pool N={int(eligible.sum())}; known TeV={int(known[eligible].sum())}")
    print(validation.to_string(index=False))
    print("\nExact-pattern case concordance:")
    print(pd.DataFrame(case_summaries).to_string(index=False))


if __name__ == "__main__":
    main()
