#!/usr/bin/env python
from __future__ import annotations

import argparse
from pathlib import Path
import yaml
import pandas as pd
from blazar_input.scoring import compute_score, assign_tiers


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--config", default="configs/config.yaml")
    args = p.parse_args()
    cfg = yaml.safe_load(Path(args.config).read_text())
    df = pd.read_csv("data/interim/master_with_features.csv")
    df = compute_score(df, cfg["score"]["weights"])
    tiers = cfg["score"]["tiers"]
    df = assign_tiers(df, tiers["gold_percentile"], tiers["silver_percentile"], tiers["bronze_percentile"])
    score_path = Path(cfg["outputs"]["score_catalogue"])
    cand_path = Path(cfg["outputs"]["candidate_catalogue"])
    val_path = Path(cfg["outputs"]["validation_catalogue"])
    score_path.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(score_path, index=False)
    is_known_tev = df.get("tevcat_matched", pd.Series(False, index=df.index)).astype(bool)
    df.loc[~is_known_tev].sort_values("S_TeV_evo", ascending=False).to_csv(cand_path, index=False)
    df.loc[is_known_tev].sort_values("S_TeV_evo", ascending=False).to_csv(val_path, index=False)
    print(f"[OK] wrote {score_path}")
    print(f"[OK] wrote {cand_path}")
    print(f"[OK] wrote {val_path}")


if __name__ == "__main__":
    main()
