from __future__ import annotations

import os
import sys
from pathlib import Path
sys.path.append(str(Path(__file__).resolve().parent))

import numpy as np
import pandas as pd

from _v030_helpers import TABLES, DOCS, auc_rank, assign_tier, wilson_interval, jeffreys_interval, delong_pair, paired_stratified_bootstrap
from _v031_v033_helpers import load_frozen, choose_score_columns


def main() -> None:
    df, frozen_path = load_frozen()
    score_cols = choose_score_columns(df)
    work = pd.DataFrame({"is_known_tev": df["is_known_tev"].astype(bool)})
    for label, col in score_cols.items():
        work[label] = pd.to_numeric(df[col], errors="coerce")
    work = work.replace([np.inf, -np.inf], np.nan).dropna(subset=list(score_cols))
    y = work["is_known_tev"].to_numpy(dtype=bool)
    scores = {name: work[name].to_numpy(dtype=float) for name in score_cols}

    n_boot = int(os.environ.get("BLAZER_V031_N_BOOT", os.environ.get("BLAZER_V030_N_BOOT", "5000")))
    comparisons = [("xray_only", "full"), ("full", "no_xray"), ("xray_only", "no_xray")]
    draws, boot = paired_stratified_bootstrap(y, scores, comparisons, n_boot=n_boot, seed=8488)
    draws.to_csv(TABLES / "table_harmonized_auc_bootstrap_draws_v0_3_1.csv", index=False)
    boot["analysis_population"] = "single_common_complete_case_population"
    boot.to_csv(TABLES / "table_harmonized_auc_summary_v0_3_1.csv", index=False)

    pair_rows = []
    for a, b in comparisons:
        rec = delong_pair(y, scores[a], scores[b])
        rec.update({"model_a": a, "model_b": b, "analysis_population": "single_common_complete_case_population"})
        pair_rows.append(rec)
    pair = pd.DataFrame(pair_rows)
    pair.to_csv(TABLES / "table_harmonized_auc_pairwise_v0_3_1.csv", index=False)

    recovery_rows = []
    n_pos = int(y.sum())
    for model, score in scores.items():
        tier = assign_tier(pd.Series(score)).to_numpy()
        for tier_set, mask in {
            "Gold": tier == "Gold",
            "Gold+Silver": np.isin(tier, ["Gold", "Silver"]),
        }.items():
            k = int(y[mask].sum())
            n_tier = int(mask.sum())
            wlo, whi = wilson_interval(k, n_pos)
            jlo, jhi = jeffreys_interval(k, n_pos)
            recovery_rows.append({
                "model": model,
                "tier_set": tier_set,
                "N_common": len(work),
                "known_TeV_N": n_pos,
                "tier_N": n_tier,
                "known_TeV_recovered_N": k,
                "recovery_fraction": k / n_pos if n_pos else np.nan,
                "wilson95_low": wlo,
                "wilson95_high": whi,
                "jeffreys95_low": jlo,
                "jeffreys95_high": jhi,
                "AUROC": auc_rank(y, score),
                "tier_definition": "percentile thresholds recomputed within the same N=common complete-case population",
            })
    recovery = pd.DataFrame(recovery_rows)
    recovery.to_csv(TABLES / "table_harmonized_recovery_with_intervals_v0_3_1.csv", index=False)

    report = [
        "# v0.3.1 harmonized statistical comparison", "",
        f"Frozen catalogue: `{frozen_path}`", "",
        f"All model comparisons use the same complete-case population: N={len(work)}, positives={n_pos}.", "",
        "## AUROC bootstrap summary", "", boot.to_markdown(index=False), "",
        "## Harmonized DeLong tests", "", pair.to_markdown(index=False), "",
        "## Recovery with small-N intervals", "", recovery.to_markdown(index=False), "",
        "Interpretation: the X-ray-only advantage is evaluated on exactly the same rows for every model. This removes the small sample-definition mismatch present in the earlier pairwise table.",
    ]
    (DOCS / "harmonized_statistics_report_v0_3_1.md").write_text("\n".join(report), encoding="utf-8")
    print("v0.3.1 harmonized statistics complete.")
    print(f"Common complete-case N={len(work)}; known TeV={n_pos}; bootstrap draws={n_boot}")
    print("\nAUROC summary:")
    print(boot.to_string(index=False))
    print("\nHarmonized DeLong tests:")
    print(pair[["model_a","model_b","auc_a","auc_b","delta_auc","p_two_sided","N","N_pos"]].to_string(index=False))


if __name__ == "__main__":
    main()
