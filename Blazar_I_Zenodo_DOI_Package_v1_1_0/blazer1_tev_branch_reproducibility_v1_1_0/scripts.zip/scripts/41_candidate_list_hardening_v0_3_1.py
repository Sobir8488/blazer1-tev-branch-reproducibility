from __future__ import annotations

import sys
from pathlib import Path
sys.path.append(str(Path(__file__).resolve().parent))

import numpy as np
import pandas as pd

from _v030_helpers import TABLES, DOCS, numeric, percentile_rank
from _v031_v033_helpers import load_frozen


def nearest_known_distance(df: pd.DataFrame) -> pd.Series:
    features = [c for c in [
        "redshift_adopted_clean", "log_nu_peak_proxy", "S_X", "S_gamma_hard",
        "S_gamma_var", "S_IR", "S_nu_peak", "S_EBL_proxy", "S_CD_penalty",
    ] if c in df.columns]
    X = df[features].apply(numeric)
    for c in features:
        med = X[c].median(skipna=True)
        X[c] = X[c].fillna(med)
        sd = X[c].std(skipna=True)
        X[c] = (X[c] - X[c].mean()) / sd if np.isfinite(sd) and sd > 0 else 0.0
    known_idx = np.flatnonzero(df["is_known_tev"].to_numpy(dtype=bool))
    out = np.full(len(df), np.nan)
    if len(known_idx) == 0:
        return pd.Series(out, index=df.index)
    K = X.iloc[known_idx].to_numpy(dtype=float)
    for i in np.flatnonzero(~df["is_known_tev"].to_numpy(dtype=bool)):
        v = X.iloc[i].to_numpy(dtype=float)
        out[i] = np.sqrt(((K - v) ** 2).sum(axis=1)).min()
    return pd.Series(out, index=df.index)


def classify_stratum(z: float, secure: bool, continuous_stable: bool) -> str:
    if not np.isfinite(z):
        return "unknown_redshift"
    if z > 0.5:
        return "attenuation_caution_z_gt_0p5"
    if not secure:
        return "redshift_quality_caution"
    if not continuous_stable:
        return "peak_proxy_sensitivity_caution"
    return "core_low_z_stable"


def main() -> None:
    df, frozen_path = load_frozen()
    hsp_path = TABLES / "table_hsp_circularity_variant_assignments_v0_3_0.csv"
    if not hsp_path.exists():
        raise FileNotFoundError(f"Missing {hsp_path}; run v0.3.0 first.")
    hsp = pd.read_csv(hsp_path, low_memory=False)
    keep_hsp = [
        "row_id", "score_continuous_peak_only", "tier_continuous_peak_only",
        "percentile_continuous_peak_only",
    ]
    df = df.merge(hsp[keep_hsp], on="row_id", how="left")

    full_score = numeric(df["S_full_recomputed_v0_1_8"] if "S_full_recomputed_v0_1_8" in df else df["S_TeV_evo"])
    xray_score = numeric(df["S_xray_only_v0_1_8"] if "S_xray_only_v0_1_8" in df else df["S_X"])
    df["full_percentile_v0_3_1"] = percentile_rank(full_score)
    df["xray_percentile_v0_3_1"] = percentile_rank(xray_score)
    df["nearest_known_TeV_distance_v0_3_1"] = nearest_known_distance(df)
    df["peak_percentile_v0_3_1"] = percentile_rank(df["log_nu_peak_proxy"])

    z = numeric(df["redshift_adopted_clean"] if "redshift_adopted_clean" in df else df["redshift_adopted"])
    secure = df["redshift_secure"].astype(str).str.lower().isin({"true","1","yes"}) if "redshift_secure" in df else pd.Series(False, index=df.index)
    continuous_stable = df["tier_continuous_peak_only"].astype(str).isin(["Gold", "Silver"])
    df["followup_evidence_stratum"] = [
        classify_stratum(zz, bool(ss), bool(cc)) for zz, ss, cc in zip(z, secure, continuous_stable)
    ]

    nontev = ~df["is_known_tev"].astype(bool)
    full_tier = df["full_recomputed_tier"].astype(str)
    xray_tier = df["xray_only_tier"].astype(str)
    list_a = df[nontev & full_tier.isin(["Gold", "Silver"]) & xray_tier.eq("Gold")].copy()
    list_b = df[nontev & full_tier.eq("Gold") & ~xray_tier.eq("Gold")].copy()

    z_favour = (100.0 * (1.0 - np.minimum(z.fillna(0.5), 1.0))).clip(0, 100)
    list_a["priority_index_v0_3_1"] = (
        0.40 * list_a["full_percentile_v0_3_1"] +
        0.35 * list_a["xray_percentile_v0_3_1"] +
        0.15 * numeric(list_a["percentile_continuous_peak_only"]).fillna(50) +
        0.10 * z_favour.loc[list_a.index]
    )
    list_b["priority_index_v0_3_1"] = (
        0.45 * list_b["full_percentile_v0_3_1"] +
        0.25 * numeric(list_b["percentile_continuous_peak_only"]).fillna(50) +
        0.20 * list_b["peak_percentile_v0_3_1"].fillna(50) +
        0.10 * z_favour.loc[list_b.index]
    )
    list_a["followup_list"] = "A_xray_prioritized"
    list_b["followup_list"] = "B_HSP_branch_frontier"
    list_a["scope_note"] = "X-ray-prioritized ranking; not a calibrated TeV probability or high-confidence detection claim."
    list_b["scope_note"] = "High-peak branch-frontier ranking; identity is sensitive to peak-proxy construction."

    output_cols = [c for c in [
        "source_name_v031", "ra_deg", "dec_deg", "branch_stage", "redshift_adopted_clean",
        "redshift_adopted_source_clean", "redshift_secure", "log_nu_peak_proxy",
        "log_nu_peak_proxy_method", "S_full_recomputed_v0_1_8", "full_recomputed_tier",
        "full_percentile_v0_3_1", "S_X", "S_xray_only_v0_1_8", "xray_only_tier",
        "xray_percentile_v0_3_1", "score_continuous_peak_only", "tier_continuous_peak_only",
        "percentile_continuous_peak_only", "nearest_known_TeV_distance_v0_3_1",
        "followup_evidence_stratum", "followup_list", "priority_index_v0_3_1", "scope_note",
    ] if c in df.columns or c in list_a.columns]

    def safe_median(series: pd.Series) -> float:
        x = numeric(series).dropna()
        return float(x.median()) if len(x) else np.nan

    manifest_rows = []
    for label, data in [("A_xray_prioritized", list_a), ("B_HSP_branch_frontier", list_b)]:
        data = data.sort_values(["followup_evidence_stratum", "priority_index_v0_3_1"], ascending=[True, False])
        all_path = TABLES / f"candidate_list_{label}_all_v0_3_1.csv"
        data[output_cols].to_csv(all_path, index=False)
        for stratum, group in data.groupby("followup_evidence_stratum", dropna=False):
            safe = str(stratum).replace(">", "gt").replace(".", "p").replace(" ", "_")
            path = TABLES / f"candidate_list_{label}_{safe}_v0_3_1.csv"
            group.sort_values("priority_index_v0_3_1", ascending=False)[output_cols].to_csv(path, index=False)
            manifest_rows.append({
                "followup_list": label,
                "evidence_stratum": stratum,
                "N": len(group),
                "median_full_percentile": float(group["full_percentile_v0_3_1"].median()),
                "median_xray_percentile": float(group["xray_percentile_v0_3_1"].median()),
                "median_redshift": safe_median(group["redshift_adopted_clean"]),
                "median_log_nu_peak": safe_median(group["log_nu_peak_proxy"]),
                "median_nearest_known_distance": safe_median(group["nearest_known_TeV_distance_v0_3_1"]),
                "output_file": str(path.relative_to(TABLES.parent)),
            })
        core = data[data["followup_evidence_stratum"].eq("core_low_z_stable")].sort_values("priority_index_v0_3_1", ascending=False)
        core.head(20)[output_cols].to_csv(TABLES / f"candidate_list_{label}_core_top20_v0_3_1.csv", index=False)

    manifest = pd.DataFrame(manifest_rows)
    manifest.to_csv(TABLES / "table_candidate_list_hardening_summary_v0_3_1.csv", index=False)

    report = [
        "# v0.3.1 candidate-list hardening", "",
        f"Frozen catalogue: `{frozen_path}`", "",
        "The former 'high-confidence' wording is retired. List A is now an X-ray-prioritized follow-up list; List B is an HSP-branch-frontier list.", "",
        "Candidates are separated into core low-z/stable, unknown-redshift, high-z attenuation-caution, redshift-quality-caution, and peak-proxy-sensitivity-caution strata.", "",
        manifest.to_markdown(index=False),
    ]
    (DOCS / "candidate_list_hardening_report_v0_3_1.md").write_text("\n".join(report), encoding="utf-8")
    print("v0.3.1 candidate-list hardening complete.")
    print(manifest.to_string(index=False))


if __name__ == "__main__":
    main()
