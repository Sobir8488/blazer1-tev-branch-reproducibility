#!/usr/bin/env python
"""Create a compact Markdown report for v0.1.5 diagnostics without optional tabulate."""
from pathlib import Path
import pandas as pd
import numpy as np

ROOT = Path('.')
REPORT = ROOT / 'tables' / 'evolutionary_diagnostics_report_v0_1_5.md'
TABLES = ROOT / 'tables'
DOCS = ROOT / 'docs'


def read_csv(name: str) -> pd.DataFrame:
    p = TABLES / name
    return pd.read_csv(p, low_memory=False) if p.exists() else pd.DataFrame()


def fmt_value(x):
    if pd.isna(x):
        return ''
    if isinstance(x, (float, np.floating)):
        ax = abs(float(x))
        if ax != 0 and (ax < 1e-3 or ax >= 1e4):
            return f'{x:.3e}'
        return f'{x:.6g}'
    return str(x)


def df_to_markdown_no_tabulate(df: pd.DataFrame, max_rows: int | None = None) -> str:
    """Small dependency-free markdown table writer."""
    if df is None or len(df) == 0:
        return '_No rows._'
    d = df.copy()
    if max_rows is not None:
        d = d.head(max_rows)
    cols = list(d.columns)
    rows = [[fmt_value(v) for v in row] for row in d[cols].itertuples(index=False, name=None)]
    # Do not aggressively pad long cells; keep markdown compact and copy-safe.
    header = '| ' + ' | '.join(cols) + ' |'
    sep = '| ' + ' | '.join(['---'] * len(cols)) + ' |'
    body = ['| ' + ' | '.join(r) + ' |' for r in rows]
    return '\n'.join([header, sep] + body)


def main() -> None:
    stress = read_csv('table_selection_stress_tests_v0_1_5.csv')
    cls = read_csv('table_class_summary_v0_1_5.csv')
    zcomp = read_csv('table_redshift_completeness_by_class_v0_1_5.csv')
    kt = read_csv('table_known_tev_by_class_v0_1_5.csv')
    zbin = read_csv('table_redshift_bin_gold_fraction_v0_1_5.csv')
    snippets = DOCS / 'results_snippets_evolutionary_diagnostics_v0_1_5.tex'

    lines = ['# BlazEr1 TeV-evolution diagnostics v0.1.5', '']
    if len(stress):
        lines += ['## Selection-stress validation', '']
        sel = stress[(stress['stress_sample'] == 'full_sample') & stress['tier_set'].isin(['Gold','Gold+Silver','Gold+Silver+Bronze'])]
        lines.append(df_to_markdown_no_tabulate(sel))
        lines.append('')
        lines += ['## Stress-test overview', '']
        cols = [c for c in ['stress_sample','tier_set','N','known_TeV_N','known_TeV_in_tier_N','known_TeV_recovery_fraction','enrichment_vs_random','hypergeom_p_ge_k','AUROC_knownTeV_vs_other'] if c in stress.columns]
        lines.append(df_to_markdown_no_tabulate(stress[cols], max_rows=40))
        lines.append('')
    if len(cls):
        lines += ['## Class summary', '', df_to_markdown_no_tabulate(cls), '']
    if len(zcomp):
        lines += ['## Redshift completeness by class', '', df_to_markdown_no_tabulate(zcomp), '']
    if len(kt):
        lines += ['## Known TeV by class/SED proxy', '', df_to_markdown_no_tabulate(kt), '']
    if len(zbin):
        lines += ['## Redshift-bin priority fractions', '', df_to_markdown_no_tabulate(zbin, max_rows=40), '']
    if snippets.exists():
        lines += ['## Manuscript snippet', '', '```latex', snippets.read_text(encoding='utf-8'), '```', '']
    REPORT.parent.mkdir(parents=True, exist_ok=True)
    REPORT.write_text('\n'.join(lines), encoding='utf-8')
    print(f'Wrote {REPORT}')


if __name__ == '__main__':
    main()
