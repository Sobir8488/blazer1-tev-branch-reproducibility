from __future__ import annotations

import sys
from pathlib import Path
sys.path.append(str(Path(__file__).resolve().parent))

import numpy as np
import pandas as pd
from _v018_helpers import TABLES, DOCS, PROCESSED, COMPONENTS, clean_numeric, load_score_catalogue, safe_spearman, auroc_from_scores

PCA_FEATURES = [
    ('S_X', +1, 'X-ray brightness'),
    ('S_gamma_hard', +1, 'Gamma hardness'),
    ('S_gamma_var', +1, 'Gamma variability'),
    ('S_IR', +1, 'WISE/HSP locus'),
    ('S_R', +1, 'Radio compactness'),
    ('S_nu_peak', +1, 'Synchrotron-peak proxy'),
    ('S_CD_penalty', -1, 'Low Compton-dominance proxy'),
    ('S_EBL_proxy', -1, 'Low redshift/EBL penalty proxy'),
]


def make_feature_matrix(df: pd.DataFrame):
    cols = []
    labels = []
    X_parts = []
    for col, sign, label in PCA_FEATURES:
        if col not in df.columns:
            continue
        x = sign * clean_numeric(df[col])
        if x.notna().sum() < 20:
            continue
        cols.append(col)
        labels.append(label)
        X_parts.append(x.rename(col))
    X = pd.concat(X_parts, axis=1)
    # median imputation after preserving missingness counts
    missing_frac = X.isna().mean()
    X_imp = X.copy()
    for c in X_imp.columns:
        med = X_imp[c].median()
        X_imp[c] = X_imp[c].fillna(med)
    mu = X_imp.mean(axis=0)
    sig = X_imp.std(axis=0).replace(0, 1.0)
    Z = (X_imp - mu) / sig
    return Z, cols, labels, missing_frac


def pca_svd(Z: pd.DataFrame):
    A = Z.values
    U, S, Vt = np.linalg.svd(A, full_matrices=False)
    scores = U * S
    eigenvalues = (S ** 2) / (len(Z) - 1)
    explained = eigenvalues / eigenvalues.sum()
    loadings = Vt.T
    return scores, loadings, explained


def main():
    df = load_score_catalogue()
    Z, cols, labels, missing_frac = make_feature_matrix(df)
    scores, loadings, explained = pca_svd(Z)
    pc1 = scores[:, 0]
    pc2 = scores[:, 1] if scores.shape[1] > 1 else np.full(len(df), np.nan)
    # Orient PC1 so higher PC1 means higher published TeV-evolution score.
    r, _, _ = safe_spearman(pc1, df['S_TeV_evo'])
    if np.isfinite(r) and r < 0:
        pc1 = -pc1
        loadings[:, 0] = -loadings[:, 0]
    df['PC1_TeV_branch_axis_v0_1_8'] = pc1
    df['PC2_TeV_branch_axis_v0_1_8'] = pc2
    outcat = PROCESSED / 'tev_evolution_score_catalog_v0_1_8_pca_branch_augmented.csv'
    df.to_csv(outcat, index=False)

    loading_rows = []
    for i, (col, label) in enumerate(zip(cols, labels)):
        loading_rows.append({
            'feature_column': col,
            'feature_label': label,
            'sign_convention': 'positive values favour TeV branch after sign flip where needed',
            'missing_fraction_before_imputation': float(missing_frac[col]),
            'PC1_loading': float(loadings[i,0]),
            'PC2_loading': float(loadings[i,1]) if loadings.shape[1] > 1 else np.nan,
        })
    pd.DataFrame(loading_rows).to_csv(TABLES / 'table_pca_branch_axis_loadings_v0_1_8.csv', index=False)

    metrics = []
    for ycol, label in [
        ('S_TeV_evo','published score'),
        ('redshift_adopted_clean','redshift'),
        ('log_nu_peak_clean','log nu_peak proxy'),
    ]:
        if ycol in df.columns:
            rr, pp, nn = safe_spearman(df['PC1_TeV_branch_axis_v0_1_8'], df[ycol])
            metrics.append({'relation': f'PC1 vs {label}', 'N': nn, 'spearman_rho': rr, 'p_value': pp})
    # ordinal stage if present
    stage_map = {'FSRQ/QSO-like':0, 'BCU/uncertain':1, 'BL Lac-like':2, 'HSP-like':3}
    if 'branch_stage' in df.columns:
        stage_rank = df['branch_stage'].map(stage_map)
        rr, pp, nn = safe_spearman(df['PC1_TeV_branch_axis_v0_1_8'], stage_rank)
        metrics.append({'relation': 'PC1 vs ordered branch stage', 'N': nn, 'spearman_rho': rr, 'p_value': pp})
    auc, mwp = auroc_from_scores(df['is_known_tev'].values, df['PC1_TeV_branch_axis_v0_1_8'].values)
    metrics.append({'relation': 'PC1 known-TeV AUROC', 'N': len(df), 'spearman_rho': auc, 'p_value': mwp})
    pd.DataFrame(metrics).to_csv(TABLES / 'table_pca_branch_axis_validation_v0_1_8.csv', index=False)

    stage_rows = []
    if 'branch_stage' in df.columns:
        for stage, g in df.groupby('branch_stage'):
            stage_rows.append({
                'branch_stage': stage,
                'N': len(g),
                'known_TeV_N': int(g['is_known_tev'].sum()),
                'median_PC1_TeV_branch_axis': float(clean_numeric(g['PC1_TeV_branch_axis_v0_1_8']).median()),
                'median_PC2': float(clean_numeric(g['PC2_TeV_branch_axis_v0_1_8']).median()),
                'median_score': float(clean_numeric(g['S_TeV_evo']).median()),
            })
    pd.DataFrame(stage_rows).to_csv(TABLES / 'table_pca_branch_axis_by_class_v0_1_8.csv', index=False)

    ev = pd.DataFrame([{'PC': f'PC{i+1}', 'explained_variance_fraction': float(v)} for i, v in enumerate(explained[:8])])
    ev.to_csv(TABLES / 'table_pca_branch_axis_explained_variance_v0_1_8.csv', index=False)

    snippet = r'''
% v0.1.8 latent branch-axis result
A PCA of sign-aligned score components provides an unsupervised latent TeV-branch axis. PC1 is oriented to increase with the published empirical score. The PCA is not used to define the score or the validation tiers; it is an independent visualization and consistency test showing whether the low-redshift, high-peak, BL Lac/HSP-like branch appears as a leading axis of the multiwavelength feature space.
'''
    (DOCS / 'latex_snippet_pca_branch_axis_v0_1_8.tex').write_text(snippet, encoding='utf-8')

    print('v0.1.8 PCA TeV-branch axis complete.')
    print('Augmented catalogue:', outcat)
    print('\nExplained variance:')
    print(ev.head(5).to_string(index=False))
    print('\nPCA validation metrics:')
    print(pd.DataFrame(metrics).to_string(index=False))
    print('\nPC1 loadings:')
    print(pd.DataFrame(loading_rows).sort_values('PC1_loading', key=lambda s: s.abs(), ascending=False).to_string(index=False))

if __name__ == '__main__':
    main()
