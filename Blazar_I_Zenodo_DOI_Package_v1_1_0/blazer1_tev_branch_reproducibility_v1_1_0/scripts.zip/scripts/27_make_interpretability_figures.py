from __future__ import annotations

import sys
from pathlib import Path
sys.path.append(str(Path(__file__).resolve().parent))

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from _v018_helpers import FIGURES, TABLES, PROCESSED, clean_numeric, load_score_catalogue


def savefig(name):
    FIGURES.mkdir(parents=True, exist_ok=True)
    plt.tight_layout()
    plt.savefig(FIGURES / f'{name}.png', dpi=220)
    plt.savefig(FIGURES / f'{name}.pdf')
    plt.close()


def fig_component_contributions():
    p = TABLES / 'table_component_contributions_v0_1_8.csv'
    if not p.exists():
        print('Missing', p)
        return
    df = pd.read_csv(p)
    samples = ['known_TeV','Gold_all','Gold_non_TeV','BL_Lac_like','HSP_like']
    d = df[df['sample'].isin(samples)].copy()
    d['contribution_percent'] = 100 * pd.to_numeric(d['fraction_of_abs_contribution'], errors='coerce')
    piv = d.pivot_table(index='sample', columns='component_label', values='contribution_percent', aggfunc='first').reindex(samples)
    ax = piv.plot(kind='bar', stacked=True, figsize=(10,6), width=0.8)
    ax.set_ylabel('Mean absolute contribution fraction (%)')
    ax.set_xlabel('Sample')
    ax.set_title('Component contributions to the empirical TeV-evolution score')
    ax.legend(loc='center left', bbox_to_anchor=(1.02,0.5), fontsize=8)
    plt.xticks(rotation=25, ha='right')
    savefig('Fig_component_contributions_v0_1_8')


def fig_xray_control():
    p = TABLES / 'table_xray_only_vs_full_score_v0_1_8.csv'
    if not p.exists():
        print('Missing', p)
        return
    df = pd.read_csv(p)
    labels = df['score_variant'].astype(str).tolist()
    x = np.arange(len(df))
    auroc = pd.to_numeric(df['AUROC_knownTeV_vs_other'], errors='coerce')
    gold = pd.to_numeric(df.get('Gold_known_TeV_fraction', pd.Series(np.nan, index=df.index)), errors='coerce')
    gs = pd.to_numeric(df.get('Gold_Silver_known_TeV_fraction', pd.Series(np.nan, index=df.index)), errors='coerce')
    fig, ax = plt.subplots(figsize=(10,6))
    width = 0.25
    ax.bar(x - width, auroc, width, label='AUROC')
    ax.bar(x, gold, width, label='Gold recovery')
    ax.bar(x + width, gs, width, label='Gold+Silver recovery')
    ax.set_xticks(x)
    ax.set_xticklabels(labels, rotation=25, ha='right')
    ax.set_ylim(0, 1.05)
    ax.set_ylabel('Validation metric')
    ax.set_title('Known-TeV validation under X-ray-control score variants')
    ax.legend()
    savefig('Fig_xray_control_validation_v0_1_8')


def fig_pca_axis():
    candidates = [
        PROCESSED / 'tev_evolution_score_catalog_v0_1_8_pca_branch_augmented.csv',
        PROCESSED / 'tev_evolution_score_catalog_v0_1_8_interpretability_augmented.csv',
    ]
    p = next((q for q in candidates if q.exists()), None)
    if p is None:
        print('Missing PCA catalogue')
        return
    df = pd.read_csv(p, low_memory=False)
    pc1 = clean_numeric(df.get('PC1_TeV_branch_axis_v0_1_8', pd.Series(np.nan, index=df.index)))
    pc2 = clean_numeric(df.get('PC2_TeV_branch_axis_v0_1_8', pd.Series(np.nan, index=df.index)))
    score = clean_numeric(df.get('S_TeV_evo', pd.Series(np.nan, index=df.index)))
    known = df.get('is_known_tev', pd.Series(False, index=df.index)).astype(str).str.lower().isin(['true','1','yes'])
    m = pc1.notna() & pc2.notna()
    plt.figure(figsize=(8,6))
    sc = plt.scatter(pc1[m & ~known], pc2[m & ~known], c=score[m & ~known], s=8, alpha=0.35)
    plt.scatter(pc1[m & known], pc2[m & known], marker='x', s=55, label='Known TeV')
    plt.colorbar(sc, label=r'$S_{\rm TeV,evo}$')
    plt.xlabel('PC1 latent TeV-branch axis')
    plt.ylabel('PC2')
    plt.title('PCA latent TeV-branch axis')
    plt.legend()
    savefig('Fig_pca_tev_branch_axis_v0_1_8')


def fig_gold_vs_known_similarity():
    p = TABLES / 'table_gold_nonTeV_vs_knownTeV_similarity_v0_1_8.csv'
    if not p.exists():
        print('Missing', p)
        return
    df = pd.read_csv(p)
    keep = ['redshift','log nu_peak proxy','TeV-evolution score','X-ray component','PCA TeV-branch axis']
    d = df[df['feature_label'].isin(keep)].copy()
    if d.empty:
        d = df.head(6).copy()
    labels = d['feature_label'].astype(str).tolist()
    x = np.arange(len(d))
    known = pd.to_numeric(d['known_TeV_median'], errors='coerce')
    gold = pd.to_numeric(d['Gold_nonTeV_median'], errors='coerce')
    # Normalize for display feature-by-feature using plotted medians.
    combined_min = pd.concat([known, gold], axis=1).min(axis=1)
    combined_max = pd.concat([known, gold], axis=1).max(axis=1)
    denom = (combined_max - combined_min).replace(0, 1)
    known_n = (known - combined_min) / denom
    gold_n = (gold - combined_min) / denom
    plt.figure(figsize=(9,5.5))
    width = 0.35
    plt.bar(x - width/2, known_n, width, label='Known TeV median')
    plt.bar(x + width/2, gold_n, width, label='Gold non-TeV median')
    plt.xticks(x, labels, rotation=25, ha='right')
    plt.ylabel('Feature-wise normalized median')
    plt.title('Known TeV vs Gold non-TeV candidates in diagnostic space')
    plt.legend()
    savefig('Fig_gold_vs_known_tev_similarity_v0_1_8')


def fig_nearest_distance():
    p = TABLES / 'table_gold_nonTeV_nearest_knownTeV_distance_summary_v0_1_8.csv'
    sample_p = TABLES / 'table_top_gold_nonTeV_knownTeV_analogues_v0_1_8.csv'
    if not p.exists():
        return
    df = pd.read_csv(p)
    plt.figure(figsize=(6.5,5))
    x = np.arange(len(df))
    med = pd.to_numeric(df['median_nearest_known_TeV_distance'], errors='coerce')
    plt.bar(x, med)
    plt.xticks(x, df['comparison_group'].astype(str), rotation=20, ha='right')
    plt.ylabel('Median distance to nearest known TeV')
    plt.title('Nearest-known-TeV distance in standardized feature space')
    savefig('Fig_nearest_known_tev_distance_v0_1_8')


def main():
    fig_component_contributions()
    fig_xray_control()
    fig_pca_axis()
    fig_gold_vs_known_similarity()
    fig_nearest_distance()
    print('Saved v0.1.8 interpretability figures:')
    for name in [
        'Fig_component_contributions_v0_1_8.pdf',
        'Fig_xray_control_validation_v0_1_8.pdf',
        'Fig_pca_tev_branch_axis_v0_1_8.pdf',
        'Fig_gold_vs_known_tev_similarity_v0_1_8.pdf',
        'Fig_nearest_known_tev_distance_v0_1_8.pdf',
    ]:
        print(FIGURES / name)

if __name__ == '__main__':
    main()
