#!/usr/bin/env python
from __future__ import annotations

import pandas as pd
from pathlib import Path

score = Path("data/processed/tev_evolution_score_catalog.csv")
if not score.exists():
    raise FileNotFoundError(score)

df = pd.read_csv(score, low_memory=False)
print("score shape:", df.shape)
for col in ["fermi_matched", "tevcat_matched", "wise_matched", "vlass_matched", "zcat_matched"]:
    if col in df.columns:
        print(col, int(df[col].fillna(False).astype(bool).sum()))
print("tier counts:")
print(df.get("tev_priority_tier", pd.Series(dtype=object)).value_counts(dropna=False).to_string())
if "tevcat_matched" in df.columns:
    tev = df[df["tevcat_matched"].fillna(False).astype(bool)]
    print("known TeV validation rows:", len(tev))
    cols = [c for c in ["SRC_NAME", "ra_deg", "dec_deg", "tevcat_name", "tevcat_sep_arcsec", "S_TeV_evo", "tev_priority_tier"] if c in df.columns]
    print(tev.sort_values("S_TeV_evo", ascending=False)[cols].head(20).to_string(index=False))
