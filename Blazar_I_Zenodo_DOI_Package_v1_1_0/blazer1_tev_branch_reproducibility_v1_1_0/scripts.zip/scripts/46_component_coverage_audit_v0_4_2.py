from __future__ import annotations

import sys
from pathlib import Path
sys.path.append(str(Path(__file__).resolve().parent))

import numpy as np
import pandas as pd
from scipy.stats import mannwhitneyu

from _v042_helpers import (
    TABLES, DOCS, COMPONENTS, load_frozen_catalogue, numeric,
    auroc, fixed_fraction_tiers, safe_spearman,
)


def _score_variants(df: pd.DataFrame) -> dict[str, pd.Series]:
    components = {m["key"]: m for m in COMPONENTS}
    total = pd.Series(0.0, index=df.index, dtype=float)
    denom = pd.Series(0.0, index=df.index, dtype=float)
    no_x = pd.Series(0.0, index=df.index, dtype=float)
    no_x_denom = pd.Series(0.0, index=df.index, dtype=float)
    for meta in COMPONENTS:
        x = numeric(df[meta["column"]])
        valid = x.notna()
        signed = meta["sign"] * meta["weight"] * x
        total.loc[valid] += signed.loc[valid]
        denom.loc[valid] += abs(meta["weight"])
        if meta["key"] != "xray_brightness":
            no_x.loc[valid] += signed.loc[valid]
            no_x_denom.loc[valid] += abs(meta["weight"])
    full = numeric(df["S_TeV_evo"]) if "S_TeV_evo" in df.columns else total / denom.replace(0, np.nan)
    xray = numeric(df["S_xray_only_v0_1_8"]) if "S_xray_only_v0_1_8" in df.columns else numeric(df[components["xray_brightness"]["column"]])
    no_xray = numeric(df["S_no_xray_v0_1_8"]) if "S_no_xray_v0_1_8" in df.columns else no_x / no_x_denom.replace(0, np.nan)
    return {"full": full, "xray_only": xray, "no_xray": no_xray}


def main() -> None:
    df = load_frozen_catalogue()
    known = df["is_known_tev"].astype(bool)

    for meta in COMPONENTS:
        df[meta["column"]] = numeric(df[meta["column"]])
    df["n_components_v0_4_2"] = df[[m["column"] for m in COMPONENTS]].notna().sum(axis=1)
    df["available_weight_v0_4_2"] = 0.0
    for meta in COMPONENTS:
        df["available_weight_v0_4_2"] += df[meta["column"]].notna().astype(float) * abs(meta["weight"])

    variants = _score_variants(df)
    for label, s in variants.items():
        df[f"score_{label}_v0_4_2"] = s

    # Component-by-component coverage contrast.
    availability_rows = []
    for meta in COMPONENTS:
        available = df[meta["column"]].notna()
        availability_rows.append({
            "component_key": meta["key"],
            "component_label": meta["label"],
            "parent_available_N": int(available.sum()),
            "parent_available_fraction": float(available.mean()),
            "known_TeV_available_N": int((available & known).sum()),
            "known_TeV_available_fraction": float(available[known].mean()),
            "nonTeV_available_N": int((available & ~known).sum()),
            "nonTeV_available_fraction": float(available[~known].mean()),
            "known_minus_nonTeV_fraction": float(available[known].mean() - available[~known].mean()),
        })
    availability = pd.DataFrame(availability_rows)
    availability.to_csv(TABLES / "table_component_availability_by_label_v0_4_2.csv", index=False)

    # Coverage distribution by primary populations.
    tier = df.get("tev_priority_tier", pd.Series("Unknown", index=df.index)).astype(str)
    groups = {
        "parent_all": pd.Series(True, index=df.index),
        "known_TeV": known,
        "nonTeV": ~known,
        "Gold_all": tier.eq("Gold"),
        "Gold_nonTeV": tier.eq("Gold") & ~known,
        "Gold_Silver_all": tier.isin(["Gold", "Silver"]),
    }
    group_rows = []
    for group, mask in groups.items():
        ncomp = df.loc[mask, "n_components_v0_4_2"]
        aw = df.loc[mask, "available_weight_v0_4_2"]
        group_rows.append({
            "group": group,
            "N": int(mask.sum()),
            "median_components": float(ncomp.median()) if len(ncomp) else np.nan,
            "p16_components": float(ncomp.quantile(0.16)) if len(ncomp) else np.nan,
            "p84_components": float(ncomp.quantile(0.84)) if len(ncomp) else np.nan,
            "median_available_weight": float(aw.median()) if len(aw) else np.nan,
            "fraction_with_7plus_components": float((ncomp >= 7).mean()) if len(ncomp) else np.nan,
            "fraction_with_all_8_components": float((ncomp == 8).mean()) if len(ncomp) else np.nan,
        })
    pd.DataFrame(group_rows).to_csv(TABLES / "table_component_coverage_group_summary_v0_4_2.csv", index=False)

    count_rows = []
    for ncomp in range(1, 9):
        mask = df["n_components_v0_4_2"].eq(ncomp)
        count_rows.append({
            "components_available_N": ncomp,
            "sources_N": int(mask.sum()),
            "source_fraction": float(mask.mean()),
            "known_TeV_N": int((mask & known).sum()),
            "known_TeV_fraction_within_bin": float(known[mask].mean()) if mask.any() else np.nan,
            "median_full_score": float(df.loc[mask, "score_full_v0_4_2"].median()) if mask.any() else np.nan,
            "Gold_N": int((mask & tier.eq("Gold")).sum()),
            "Gold_fraction_within_bin": float(tier[mask].eq("Gold").mean()) if mask.any() else np.nan,
        })
    count_table = pd.DataFrame(count_rows)
    count_table.to_csv(TABLES / "table_component_count_distribution_v0_4_2.csv", index=False)

    # Coverage-only discrimination and correlation with score.
    rho_count, p_count, n_count = safe_spearman(df["score_full_v0_4_2"], df["n_components_v0_4_2"])
    rho_weight, p_weight, n_weight = safe_spearman(df["score_full_v0_4_2"], df["available_weight_v0_4_2"])
    known_count = df.loc[known, "n_components_v0_4_2"]
    other_count = df.loc[~known, "n_components_v0_4_2"]
    mw_count = mannwhitneyu(known_count, other_count, alternative="greater")
    known_weight = df.loc[known, "available_weight_v0_4_2"]
    other_weight = df.loc[~known, "available_weight_v0_4_2"]
    mw_weight = mannwhitneyu(known_weight, other_weight, alternative="greater")
    diagnostic = pd.DataFrame([
        {
            "quantity": "AUROC coverage count for known-TeV label",
            "estimate": auroc(known, df["n_components_v0_4_2"]),
            "p_value": float(mw_count.pvalue),
            "N": len(df),
            "interpretation": "historical multiwavelength coverage is strongly associated with TeVCat membership",
        },
        {
            "quantity": "AUROC available weight for known-TeV label",
            "estimate": auroc(known, df["available_weight_v0_4_2"]),
            "p_value": float(mw_weight.pvalue),
            "N": len(df),
            "interpretation": "available score weight is itself a selection-history proxy",
        },
        {
            "quantity": "Spearman full score vs component count",
            "estimate": rho_count,
            "p_value": p_count,
            "N": n_count,
            "interpretation": "positive but not dominant score-coverage association",
        },
        {
            "quantity": "Spearman full score vs available weight",
            "estimate": rho_weight,
            "p_value": p_weight,
            "N": n_weight,
            "interpretation": "positive but not dominant score-coverage association",
        },
    ])
    diagnostic.to_csv(TABLES / "table_component_coverage_diagnostics_v0_4_2.csv", index=False)

    # Re-tier each restricted population so that Gold and Gold+Silver remain fixed fractions.
    sensitivity_rows = []
    for minimum in range(1, 9):
        subset_mask = df["n_components_v0_4_2"] >= minimum
        for variant, scores_all in variants.items():
            scores = numeric(scores_all[subset_mask])
            labels = known[subset_mask]
            finite = scores.notna()
            scores = scores[finite]
            labels = labels[finite]
            tiers = fixed_fraction_tiers(scores)
            gold = tiers.eq("Gold")
            gold_silver = tiers.isin(["Gold", "Silver"])
            n_pos = int(labels.sum())
            sensitivity_rows.append({
                "minimum_components_required": minimum,
                "score_variant": variant,
                "analysis_N": len(scores),
                "known_TeV_N": n_pos,
                "known_TeV_retained_fraction": float(n_pos / int(known.sum())),
                "AUROC": auroc(labels, scores),
                "Gold_N": int(gold.sum()),
                "Gold_known_TeV_N": int((gold & labels).sum()),
                "Gold_recovery_fraction": float((gold & labels).sum() / n_pos) if n_pos else np.nan,
                "Gold_Silver_N": int(gold_silver.sum()),
                "Gold_Silver_known_TeV_N": int((gold_silver & labels).sum()),
                "Gold_Silver_recovery_fraction": float((gold_silver & labels).sum() / n_pos) if n_pos else np.nan,
                "tier_definition": "reranked within restricted coverage population at fixed 5/15 per cent fractions",
            })
    sensitivity = pd.DataFrame(sensitivity_rows)
    sensitivity.to_csv(TABLES / "table_minimum_component_sensitivity_v0_4_2.csv", index=False)

    # Exact high-coverage strata isolate score discrimination from broad coverage differences.
    exact_rows = []
    for exact_count in [7, 8]:
        mask = df["n_components_v0_4_2"].eq(exact_count)
        for variant, scores in variants.items():
            exact_rows.append({
                "exact_components_available": exact_count,
                "score_variant": variant,
                "analysis_N": int(mask.sum()),
                "known_TeV_N": int((mask & known).sum()),
                "AUROC": auroc(known[mask], numeric(scores[mask])),
            })
    exact = pd.DataFrame(exact_rows)
    exact.to_csv(TABLES / "table_exact_coverage_stratum_auroc_v0_4_2.csv", index=False)

    compact = sensitivity.loc[
        sensitivity["minimum_components_required"].isin([1, 5, 7, 8])
        & sensitivity["score_variant"].isin(["full", "xray_only", "no_xray"]),
        ["minimum_components_required", "score_variant", "analysis_N", "known_TeV_N", "AUROC", "Gold_recovery_fraction", "Gold_Silver_recovery_fraction"],
    ]
    latex = compact.to_latex(
        index=False,
        escape=True,
        float_format=lambda x: f"{x:.3f}",
        caption=("Sensitivity to minimum multiwavelength component coverage. Tiers are redefined "
                 "within each restricted population at the same fixed 5 and 15 per cent fractions. "
                 "The strong coverage--TeVCat association is treated as a historical-selection audit, "
                 "not as an astrophysical classifier."),
        label="tab:component_coverage_sensitivity_v042",
    )
    (DOCS / "latex_component_coverage_audit_v0_4_2.tex").write_text(latex, encoding="utf-8")

    print("v0.4.2 component-coverage audit complete.")
    print(f"Known TeV component counts: {known_count.value_counts().sort_index().to_dict()}")
    print(diagnostic.to_string(index=False))
    print("\nHigh-coverage sensitivity:")
    print(compact.to_string(index=False))


if __name__ == "__main__":
    main()
