#!/usr/bin/env python
from __future__ import annotations
import numpy as np
import pandas as pd
from scipy.stats import fisher_exact, mannwhitneyu
from _v044_helpers import *


def hsp_variants(df):
    method=df.get("log_nu_peak_proxy_method",pd.Series(pd.NA,index=df.index)).astype(str); lognu=numeric(df["log_nu_peak_proxy"])
    peak_no=robust_zscore(lognu.where(~method.eq("HSP_CATALOGUE_FLAG")))
    continuous=method.isin(["LAC_LE_FREQ","ALPHA_RX_PROXY"]); peak_cont=robust_zscore(lognu.where(continuous))
    df["S_active_no_HSP_flag_v0_4_4"]=score_from_components(df,peak_override=peak_no)
    df["S_active_continuous_peak_v0_4_4"]=score_from_components(df,peak_override=peak_cont)
    df["S_active_no_peak_v0_4_4"]=score_from_components(df,exclude={"synchrotron_peak_proxy"})
    variants={"baseline_active":"S_TeV_branch_active_v0_4_4","no_HSP_catalogue_flag":"S_active_no_HSP_flag_v0_4_4","continuous_peak_only":"S_active_continuous_peak_v0_4_4","no_peak_component":"S_active_no_peak_v0_4_4"}
    for label,col in variants.items():
        df[f"tier_{label}_v0_4_4"]=assign_tier(df[col]); df[f"percentile_{label}_v0_4_4"]=percentile_rank(df[col])
    basegold=set(df.index[df["tier_baseline_active_v0_4_4"].eq("Gold")]); names=source_name(df); non=~df["is_known_tev"]; base30=set(names.loc[numeric(df.loc[non,"S_TeV_branch_active_v0_4_4"]).sort_values(ascending=False).head(30).index]); rows=[]
    for label,col in variants.items():
        valid=numeric(df[col]).notna(); y=df.loc[valid,"is_known_tev"]; gold=df.loc[valid,f"tier_{label}_v0_4_4"].eq("Gold"); gs=df.loc[valid,f"tier_{label}_v0_4_4"].isin(["Gold","Silver"]); idx=set(df.loc[valid].index[gold]); current30=set(names.loc[numeric(df.loc[non,col]).sort_values(ascending=False).head(30).index]); r,p,n=safe_spearman(df[col],df["S_TeV_branch_active_v0_4_4"]); pr,pp,pn=partial_spearman(df[col],df["log_nu_peak_proxy"],df.get("redshift_adopted_clean",df.get("redshift_adopted")))
        rows.append({"score_variant":label,"N_score":int(valid.sum()),"known_TeV_N":int(y.sum()),"Gold_N":int(gold.sum()),"Gold_known_TeV_N":int((gold&y).sum()),"Gold_recovery":float((gold&y).sum()/y.sum()),"Gold_Silver_N":int(gs.sum()),"Gold_Silver_known_TeV_N":int((gs&y).sum()),"Gold_Silver_recovery":float((gs&y).sum()/y.sum()),"AUROC":auc_rank(y.to_numpy(),numeric(df.loc[valid,col]).to_numpy()),"spearman_vs_active":r,"Gold_Jaccard_vs_active":len(idx&basegold)/len(idx|basegold),"top30_nonTeV_overlap_N":len(current30&base30),"partial_rho_score_peak_control_z":pr,"partial_rho_p":pp,"partial_rho_N":pn})
    tab=pd.DataFrame(rows); tab.to_csv(TABLES/"table_active_hsp_circularity_v0_4_4.csv",index=False)
    return df,tab


def evidence_stratum(row,list_name):
    z=row["redshift"]; secure=bool(row["redshift_secure"]); cont=str(row["continuous_peak_tier"])
    if not np.isfinite(z): return "unknown_redshift"
    if z>.5: return "attenuation_caution_z_gt_0p5"
    if not secure: return "redshift_quality_caution"
    if list_name=="B" and cont not in {"Gold","Silver"}: return "peak_proxy_sensitivity_caution"
    return "core_low_z_stable"


def safe_median(s):
    x=numeric(s).dropna()
    return float(x.median()) if len(x) else np.nan

def candidate_lists(df):
    fulltier=df["tier_active_v0_4_4"].astype(str); xraytier=assign_tier(df["S_xray_only_v0_1_8"]); xraypct=percentile_rank(df["S_xray_only_v0_1_8"]); fullpct=df["percentile_active_v0_4_4"]; contpct=df["percentile_continuous_peak_only_v0_4_4"]; conttier=df["tier_continuous_peak_only_v0_4_4"]; peakpct=percentile_rank(df["log_nu_peak_proxy"]); z=numeric(df.get("redshift_adopted_clean",df.get("redshift_adopted"))); secure=as_bool(df.get("redshift_secure",pd.Series(False,index=df.index))); pz=(100*(1-z.clip(0,1))).where(z.notna(),50.)
    A=(~df["is_known_tev"])&fulltier.isin(["Gold","Silver"])&xraytier.eq("Gold")
    B=(~df["is_known_tev"])&fulltier.eq("Gold")&~xraytier.eq("Gold")
    results=[]
    for lname,mask in [("A",A),("B",B)]:
        d=df.loc[mask].copy(); out=pd.DataFrame(index=d.index); out["source_name"]=source_name(d); out["ra_deg"]=numeric(d.get("ra_deg",d.get("RAJ2000"))); out["dec_deg"]=numeric(d.get("dec_deg",d.get("DECJ2000"))); out["redshift"]=z.loc[d.index]; out["redshift_secure"]=secure.loc[d.index]; out["log_nu_peak_proxy"]=numeric(d["log_nu_peak_proxy"]); out["full_score"]=numeric(d["S_TeV_branch_active_v0_4_4"]); out["full_percentile"]=fullpct.loc[d.index]; out["full_tier"]=fulltier.loc[d.index]; out["xray_score"]=numeric(d["S_xray_only_v0_1_8"]); out["xray_percentile"]=xraypct.loc[d.index]; out["xray_tier"]=xraytier.loc[d.index]; out["continuous_peak_percentile"]=contpct.loc[d.index]; out["continuous_peak_tier"]=conttier.loc[d.index]; out["peak_percentile"]=peakpct.loc[d.index]; out["nearest_known_TeV_distance"]=numeric(d.get("nearest_known_TeV_distance_active_v0_4_4",pd.Series(np.nan,index=d.index)))
        out["evidence_stratum"]=[evidence_stratum(r,lname) for _,r in out.iterrows()]
        if lname=="A": out["priority_index"]=.40*out["full_percentile"]+.35*out["xray_percentile"]+.15*out["continuous_peak_percentile"].fillna(50)+.10*pz.loc[d.index]
        else: out["priority_index"]=.45*out["full_percentile"]+.25*out["continuous_peak_percentile"].fillna(50)+.20*out["peak_percentile"].fillna(50)+.10*pz.loc[d.index]
        out["scope_note"]="X-ray-prioritized follow-up list; not a calibrated detection probability." if lname=="A" else "HSP-branch-frontier list; identity remains conditional on peak-proxy construction and score architecture."
        out=out.sort_values(["evidence_stratum","priority_index"],ascending=[True,False]); longname="A_xray_prioritized" if lname=="A" else "B_HSP_branch_frontier"; out.to_csv(TABLES/f"candidate_list_{longname}_active_primary_all_v0_4_4.csv",index=False); out[out["evidence_stratum"].eq("core_low_z_stable")].sort_values("priority_index",ascending=False).head(20).to_csv(TABLES/f"candidate_list_{longname}_active_primary_core_top20_v0_4_4.csv",index=False)
        for stratum,g in out.groupby("evidence_stratum"):
            results.append({"followup_list":longname,"evidence_stratum":stratum,"N":len(g),"median_full_percentile":float(g["full_percentile"].median()),"median_xray_percentile":float(g["xray_percentile"].median()),"median_redshift":safe_median(g["redshift"]),"median_log_nu_peak":safe_median(g["log_nu_peak_proxy"]),"median_nearest_known_distance":safe_median(g["nearest_known_TeV_distance"])})
    summary=pd.DataFrame(results); summary.to_csv(TABLES/"table_active_candidate_list_summary_v0_4_4.csv",index=False); return summary


def attach_fields(matches,df):
    lookup=df.copy(); lookup["source_name_v044"]=source_name(lookup); fields=["source_name_v044","S_TeV_branch_active_v0_4_4","tier_active_v0_4_4","percentile_active_v0_4_4","S_xray_only_v0_1_8","S_no_xray_v0_1_8","S_active_continuous_peak_v0_4_4","tier_continuous_peak_only_v0_4_4","percentile_continuous_peak_only_v0_4_4"]
    lookup["xray_tier_active_v0_4_4"]=assign_tier(lookup["S_xray_only_v0_1_8"]); lookup["xray_percentile_active_v0_4_4"]=percentile_rank(lookup["S_xray_only_v0_1_8"]); lookup["no_xray_tier_active_v0_4_4"]=assign_tier(lookup["S_no_xray_v0_1_8"])
    fields += ["xray_tier_active_v0_4_4","xray_percentile_active_v0_4_4","no_xray_tier_active_v0_4_4"]
    for c in fields: matches[f"matched_{c}"]=matches["catalogue_row_id"].map(lookup[c])
    return matches


def time_split(df):
    p=EXTERNAL/"iact_discovery_history_v0_3_2.csv"; hist=pd.read_csv(p); matched=attach_fields(coordinate_crossmatch(hist,df,180),df); matched.to_csv(TABLES/"table_active_iact_discovery_crossmatch_v0_4_4.csv",index=False)
    for c in ["public_report_date","event_date"]:
        if c in matched: matched[c]=pd.to_datetime(matched[c],errors="coerce")
    rows=[]
    for axis in [c for c in ["public_report_date","event_date"] if c in matched]:
        for freeze in [pd.Timestamp("2018-12-31"),pd.Timestamp("2020-12-31")]:
            e=matched[matched[axis].notna()&(matched[axis]>freeze)]; nall=len(e); nmatch=int(e["catalogue_matched"].sum())
            variants={"active_full":"matched_tier_active_v0_4_4","xray_only":"matched_xray_tier_active_v0_4_4","no_xray":"matched_no_xray_tier_active_v0_4_4","continuous_peak_only":"matched_tier_continuous_peak_only_v0_4_4"}
            for label,tcol in variants.items():
                sub=e[e["catalogue_matched"]&e[tcol].notna()]; n=len(sub)
                for ts,allowed,expected in [("Gold",{"Gold"},.05),("Gold+Silver",{"Gold","Silver"},.15)]:
                    k=int(sub[tcol].astype(str).isin(allowed).sum()); lo,hi=wilson_interval(k,n); rows.append({"date_axis":axis,"freeze_date":freeze.date().isoformat(),"score_variant":label,"tier_set":ts,"postfreeze_detection_rows":nall,"matched_detection_rows":nmatch,"variant_usable_N":n,"recovered_N":k,"recovery_fraction":k/n if n else np.nan,"wilson95_low":lo,"wilson95_high":hi,"random_tier_fraction":expected,"random_tier_reference_probability":float(binomtest(k,n,expected,alternative="greater").pvalue) if n else np.nan,"strict_feature_time_blind":False,"validation_class":"quasi_prospective_label_time_split"})
    tab=pd.DataFrame(rows); tab.to_csv(TABLES/"table_active_time_split_iact_v0_4_4.csv",index=False); return tab,matched


def observed_control(df):
    obs=pd.read_csv(EXTERNAL/"iact_observed_outcomes_v0_3_3.csv"); obs["candidate_program_eligible"]=obs["candidate_program_eligible"].astype(str).str.lower().isin({"true","1","yes"}); obs["firm_detection"]=obs["outcome"].astype(str).eq("firm_detection"); matched=attach_fields(coordinate_crossmatch(obs,df,180),df); matched.to_csv(TABLES/"table_active_iact_observed_crossmatch_v0_4_4.csv",index=False); primary=matched[matched["candidate_program_eligible"]&matched["catalogue_matched"]]
    agg=[]
    for rid,g in primary.groupby("catalogue_row_id"):
        best=g.sort_values("significance_sigma",ascending=False).iloc[0].to_dict(); best["observation_rows_aggregated"]=len(g); best["firm_detection"]=bool(g["firm_detection"].any()); best["outcome_aggregate"]="firm_detection" if best["firm_detection"] else "nonfirm_observed_control"; agg.append(best)
    unique=pd.DataFrame(agg); unique.to_csv(TABLES/"table_active_iact_observed_unique_v0_4_4.csv",index=False); metrics=[]; fish=[]
    if not unique.empty and unique["firm_detection"].nunique()==2:
        y=unique["firm_detection"].to_numpy(bool); variants={"active_full":"matched_S_TeV_branch_active_v0_4_4","xray_only":"matched_S_xray_only_v0_1_8","no_xray":"matched_S_no_xray_v0_1_8","continuous_peak_only":"matched_S_active_continuous_peak_v0_4_4"}
        tiers={"active_full":"matched_tier_active_v0_4_4","xray_only":"matched_xray_tier_active_v0_4_4","no_xray":"matched_no_xray_tier_active_v0_4_4","continuous_peak_only":"matched_tier_continuous_peak_only_v0_4_4"}
        for label,col in variants.items():
            sc=numeric(unique[col]).to_numpy(); res=exact_permutation_auc(y,sc); fv=sc[y&np.isfinite(sc)]; nv=sc[(~y)&np.isfinite(sc)]; mw=mannwhitneyu(fv,nv,alternative="two-sided").pvalue if len(fv) and len(nv) else np.nan; metrics.append({"score_variant":label,"unique_matched_N":int(np.isfinite(sc).sum()),"firm_detection_N":int((y&np.isfinite(sc)).sum()),"nonfirm_control_N":int(((~y)&np.isfinite(sc)).sum()),"AUROC_firm_vs_nonfirm":res["auc"],"permutation_p_two_sided":res["p_two_sided"],"permutation_exact":res["exact"],"n_permutations":res["n_permutations"],"median_firm":float(np.median(fv)),"median_nonfirm":float(np.median(nv)),"mannwhitney_p_two_sided":float(mw)})
            high=unique[tiers[label]].astype(str).isin(["Gold","Silver"]); firm=unique["firm_detection"].astype(bool); arr=np.array([[int((firm&high).sum()),int((firm&~high).sum())],[int((~firm&high).sum()),int((~firm&~high).sum())]]); odds,p=fisher_exact(arr); fish.append({"score_variant":label,"firm_high_N":arr[0,0],"firm_not_high_N":arr[0,1],"nonfirm_high_N":arr[1,0],"nonfirm_not_high_N":arr[1,1],"fisher_odds_ratio":odds,"fisher_p_two_sided":p})
    mt=pd.DataFrame(metrics); ft=pd.DataFrame(fish); mt.to_csv(TABLES/"table_active_iact_observed_metrics_v0_4_4.csv",index=False); ft.to_csv(TABLES/"table_active_iact_observed_fisher_v0_4_4.csv",index=False); return unique,mt,ft


def main():
    df,src=load_active_catalogue(require_interpretability=True); df=add_primary_columns(df); df,hsp=hsp_variants(df); cand=candidate_lists(df); ts,history=time_split(df); unique,metrics,fish=observed_control(df); out=PROCESSED/"tev_evolution_score_catalog_v0_4_4_active_final.csv"; df.to_csv(out,index=False)
    print("v0.4.4 active candidate and IACT propagation complete.")
    print("\nHSP sensitivity:"); print(hsp.to_string(index=False))
    print("\nCandidate strata:"); print(cand.to_string(index=False))
    print("\nPublic-report-date split:"); print(ts[ts["date_axis"].eq("public_report_date")].to_string(index=False))
    print("\nObserved-control metrics:"); print(metrics.to_string(index=False))

if __name__=="__main__": main()
