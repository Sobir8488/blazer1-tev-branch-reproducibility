#!/usr/bin/env python
from __future__ import annotations

from pathlib import Path
import json
import pandas as pd
from astropy.table import Table

OUT = Path("data/raw/tevcat/tevcat.csv")
LOG = Path("metadata/tevcat_fetch_log.json")


def clean_bytes(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    for c in out.columns:
        if out[c].dtype == object:
            out[c] = out[c].map(lambda x: x.decode("utf-8", errors="ignore") if isinstance(x, (bytes, bytearray)) else x)
    return out


def standardize_minimal(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    lower = {c.lower(): c for c in out.columns}
    ra = lower.get("ra") or lower.get("raj2000") or lower.get("ra_deg")
    dec = lower.get("dec") or lower.get("dej2000") or lower.get("dec_deg")
    name = lower.get("name") or lower.get("source_name") or lower.get("tevcat_name")
    if ra is None or dec is None:
        raise KeyError(f"Could not identify RA/Dec in TeVCat columns: {list(out.columns)}")
    out["ra_deg"] = pd.to_numeric(out[ra], errors="coerce")
    out["dec_deg"] = pd.to_numeric(out[dec], errors="coerce")
    if name is not None and "name" not in out.columns:
        out["name"] = out[name]
    return out


def fetch_with_astroquery() -> tuple[pd.DataFrame, str]:
    from astroquery.heasarc import Heasarc

    # Preferred HEASARC all-sky query. This is usually enough for the compact TeVCat table.
    try:
        tab = Heasarc.query_region(catalog="tevcat", spatial="all-sky", columns="*")
        return tab.to_pandas(), "astroquery.heasarc.query_region(spatial='all-sky')"
    except Exception as exc1:
        # TAP fallback.
        try:
            result = Heasarc.query_tap("SELECT * FROM tevcat")
            tab = result.to_table() if hasattr(result, "to_table") else result
            return tab.to_pandas(), "astroquery.heasarc.query_tap(SELECT * FROM tevcat)"
        except Exception as exc2:
            raise RuntimeError(f"HEASARC astroquery failed: {exc1!r}; TAP fallback failed: {exc2!r}")


def main() -> None:
    OUT.parent.mkdir(parents=True, exist_ok=True)
    LOG.parent.mkdir(parents=True, exist_ok=True)
    df, method = fetch_with_astroquery()
    df = clean_bytes(df)
    df = standardize_minimal(df)
    df.to_csv(OUT, index=False)
    log = {
        "ok": True,
        "method": method,
        "output": str(OUT),
        "rows": int(len(df)),
        "columns": list(df.columns),
    }
    LOG.write_text(json.dumps(log, indent=2), encoding="utf-8")
    print(f"[OK] TeVCat -> {OUT} rows={len(df)} cols={len(df.columns)}")
    print(f"[OK] wrote {LOG}")


if __name__ == "__main__":
    main()
