from pathlib import Path
import math
import numpy as np
import pandas as pd

try:
    from scipy.stats import hypergeom, mannwhitneyu, ks_2samp
except Exception:
    hypergeom = None
    mannwhitneyu = None
    ks_2samp = None

ROOT = Path('.')
SCORE_PATH = ROOT / 'data' / 'processed' / 'tev_evolution_score_catalog.csv'
KNOWN_PATH = ROOT / 'data' / 'processed' / 'known_tev_validation_sample.csv'
OUTDIR = ROOT / 'tables'
OUTDIR.mkdir(exist_ok=True, parents=True)


def clean_bytes(x):
    if pd.isna(x):
        return x
    s = str(x)
    if s.startswith("b'") and s.endswith("'"):
        return s[2:-1]
    if s.startswith('b"') and s.endswith('"'):
        return s[2:-1]
    return s


def auc_rank(y_true, score):
    y = np.asarray(y_true).astype(int)
    s = np.asarray(score).astype(float)
    mask = np.isfinite(s)
    y = y[mask]
    s = s[mask]
    n_pos = int(y.sum())
    n_neg = int(len(y) - n_pos)
    if n_pos == 0 or n_neg == 0:
        return np.nan
    ranks = pd.Series(s).rank(method='average').to_numpy()
    rank_sum_pos = ranks[y == 1].sum()
    return (rank_sum_pos - n_pos * (n_pos + 1) / 2) / (n_pos * n_neg)


def hypergeom_sf(N, K, n, k):
    if hypergeom is not None:
        return float(hypergeom.sf(k - 1, N, K, n))
    # fallback: sum exact probabilities in log-space
    def logcomb(a, b):
        if b < 0 or b > a:
            return -np.inf
        return math.lgamma(a + 1) - math.lgamma(b + 1) - math.lgamma(a - b + 1)
    denom = logcomb(N, n)
    vals = []
    for i in range(k, min(K, n) + 1):
        vals.append(math.exp(logcomb(K, i) + logcomb(N - K, n - i) - denom))
    return float(sum(vals))


def main():
    if not SCORE_PATH.exists():
        raise FileNotFoundError(SCORE_PATH)
    if not KNOWN_PATH.exists():
        raise FileNotFoundError(KNOWN_PATH)

    score = pd.read_csv(SCORE_PATH, low_memory=False)
    known = pd.read_csv(KNOWN_PATH, low_memory=False)

    for df in (score, known):
        for col in ['SRC_NAME', 'tevcat_name', 'BLAZAR_CLASS', 'fermi_CLASS1']:
            if col in df.columns:
                df[col] = df[col].map(clean_bytes)

    score['is_known_tev'] = False
    if 'tevcat_matched' in score.columns:
        score['is_known_tev'] = score['tevcat_matched'].fillna(False).astype(bool)
    elif 'tevcat_name' in score.columns:
        score['is_known_tev'] = score['tevcat_name'].notna()

    N = len(score)
    K = int(score['is_known_tev'].sum())
    rows = []
    tier_order = ['Gold', 'Silver', 'Bronze', 'Low-priority']
    for tier in tier_order:
        tier_mask = score['tev_priority_tier'].eq(tier)
        n_tier = int(tier_mask.sum())
        k_tier = int((tier_mask & score['is_known_tev']).sum())
        rows.append({
            'metric': f'{tier}_tier',
            'sample_size_N': N,
            'known_tev_total_K': K,
            'tier_size_n': n_tier,
            'known_tev_in_tier_k': k_tier,
            'tier_fraction_all': n_tier / N if N else np.nan,
            'known_tev_fraction_in_tier': k_tier / K if K else np.nan,
            'enrichment_vs_random': (k_tier / K) / (n_tier / N) if K and n_tier else np.nan,
            'hypergeom_p_ge_k': hypergeom_sf(N, K, n_tier, k_tier) if K and n_tier else np.nan,
        })

    cumulative_defs = [
        ('Gold', ['Gold']),
        ('Gold+Silver', ['Gold', 'Silver']),
        ('Gold+Silver+Bronze', ['Gold', 'Silver', 'Bronze']),
    ]
    for name, tiers in cumulative_defs:
        mask = score['tev_priority_tier'].isin(tiers)
        n_sel = int(mask.sum())
        k_sel = int((mask & score['is_known_tev']).sum())
        rows.append({
            'metric': name,
            'sample_size_N': N,
            'known_tev_total_K': K,
            'tier_size_n': n_sel,
            'known_tev_in_tier_k': k_sel,
            'tier_fraction_all': n_sel / N if N else np.nan,
            'known_tev_fraction_in_tier': k_sel / K if K else np.nan,
            'enrichment_vs_random': (k_sel / K) / (n_sel / N) if K and n_sel else np.nan,
            'hypergeom_p_ge_k': hypergeom_sf(N, K, n_sel, k_sel) if K and n_sel else np.nan,
        })

    # rank-based AUROC and two-sample tests
    valid = score[['is_known_tev', 'S_TeV_evo']].dropna()
    auroc = auc_rank(valid['is_known_tev'].astype(int), valid['S_TeV_evo'])
    known_scores = valid.loc[valid['is_known_tev'], 'S_TeV_evo'].astype(float)
    other_scores = valid.loc[~valid['is_known_tev'], 'S_TeV_evo'].astype(float)
    mw_p = np.nan
    ks_p = np.nan
    if len(known_scores) and len(other_scores) and mannwhitneyu is not None:
        mw_p = float(mannwhitneyu(known_scores, other_scores, alternative='greater').pvalue)
    if len(known_scores) and len(other_scores) and ks_2samp is not None:
        ks_p = float(ks_2samp(known_scores, other_scores, alternative='greater').pvalue)

    rows.append({
        'metric': 'AUROC_knownTeV_vs_other',
        'sample_size_N': N,
        'known_tev_total_K': K,
        'tier_size_n': len(valid),
        'known_tev_in_tier_k': K,
        'tier_fraction_all': np.nan,
        'known_tev_fraction_in_tier': np.nan,
        'enrichment_vs_random': auroc,
        'hypergeom_p_ge_k': np.nan,
        'mannwhitney_p_greater': mw_p,
        'ks_p_greater': ks_p,
    })

    summary = pd.DataFrame(rows)
    summary.to_csv(OUTDIR / 'validation_summary_v0_1_3.csv', index=False)

    known_cols = [c for c in [
        'SRC_NAME','ra_deg','dec_deg','BLAZAR_CLASS','fermi_CLASS1','tevcat_name',
        'tevcat_sep_arcsec','S_TeV_evo','tev_priority_tier','redshift_adopted',
        'log_nu_peak_proxy','S_X','S_gamma_hard','S_IR','S_R','S_EBL_proxy'
    ] if c in known.columns]
    known_out = known[known_cols].copy()
    known_out.to_csv(OUTDIR / 'known_tev_tier_recovery_v0_1_3.csv', index=False)

    print('Validation summary written: tables/validation_summary_v0_1_3.csv')
    print('Known-TeV recovery table written: tables/known_tev_tier_recovery_v0_1_3.csv')
    print('\nKey metrics:')
    print(summary.to_string(index=False))


if __name__ == '__main__':
    main()
