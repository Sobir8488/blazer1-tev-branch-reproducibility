from __future__ import annotations

import sys
from pathlib import Path
sys.path.append(str(Path(__file__).resolve().parent))

import numpy as np
import pandas as pd

from _v043_helpers import (
    PROCESSED, TABLES, numeric, percentile_rank, fixed_fraction_tiers,
    source_name, jaccard, classify_stratum,
)


def secure_redshift(df: pd.DataFrame) -> pd.Series:
    if "redshift_secure" in df.columns:
        return df["redshift_secure"].astype(str).str.lower().isin({"true", "1", "yes"})
    src = df.get("redshift_adopted_source_clean", df.get("redshift_adopted_source", pd.Series("", index=df.index))).astype(str).str.lower()
    return ~src.str.contains("photo", na=False) & src.ne("")


def main() -> None:
    path = PROCESSED / "tev_evolution_score_catalog_v0_4_3_score_architecture_augmented.csv"
    if not path.exists():
        raise FileNotFoundError("Run scripts/50_score_architecture_variants_v0_4_3.py first.")
    df = pd.read_csv(path, low_memory=False)
    df["is_known_tev"] = df["is_known_tev"].astype(str).str.lower().isin({"true", "1", "yes"})
    known = df["is_known_tev"]

    hsp_path = TABLES / "table_hsp_circularity_variant_assignments_v0_3_0.csv"
    if hsp_path.exists():
        hsp = pd.read_csv(hsp_path, low_memory=False)
        hsp = hsp[[c for c in ["row_id", "score_continuous_peak_only", "tier_continuous_peak_only", "percentile_continuous_peak_only"] if c in hsp.columns]]
        df["row_id_v043"] = np.arange(len(df), dtype=int)
        df = df.merge(hsp, left_on="row_id_v043", right_on="row_id", how="left", suffixes=("", "_hsp"))
    else:
        df["score_continuous_peak_only"] = np.nan
        df["tier_continuous_peak_only"] = "Unknown"
        df["percentile_continuous_peak_only"] = np.nan

    variants = {
        "published_available": numeric(df["S_arch_published_available_v0_4_3"]),
        "active_available": numeric(df["S_arch_active_available_v0_4_3"]),
        "fixed_active_weight": numeric(df["S_arch_fixed_active_weight_v0_4_3"]),
    }
    xray = numeric(df["S_xray_only_v0_1_8"])
    xray_tier = fixed_fraction_tiers(xray)
    xray_pct = percentile_rank(xray)
    names = source_name(df)

    base_gold = set(df.index[fixed_fraction_tiers(variants["published_available"]).eq("Gold")])
    base_top30_idx = numeric(variants["published_available"][~known]).sort_values(ascending=False).head(30).index
    base_top30 = set(names.loc[base_top30_idx])

    z = numeric(df["redshift_adopted_clean"] if "redshift_adopted_clean" in df.columns else df["redshift_adopted"])
    secure = secure_redshift(df)
    cont_stable = df["tier_continuous_peak_only"].astype(str).isin(["Gold", "Silver"])
    strata = pd.Series(
        [classify_stratum(float(zz) if np.isfinite(zz) else np.nan, bool(ss), bool(cc)) for zz, ss, cc in zip(z, secure, cont_stable)],
        index=df.index,
    )
    z_favour = (100.0 * (1.0 - np.minimum(z.fillna(0.5), 1.0))).clip(0, 100)
    peak_pct = percentile_rank(df["log_nu_peak_proxy"])
    cont_pct = numeric(df["percentile_continuous_peak_only"]).fillna(50)

    summary_rows = []
    list_rows = []
    assignment = pd.DataFrame({
        "row_id": np.arange(len(df), dtype=int),
        "source_name": names,
        "is_known_tev": known,
        "redshift": z,
        "evidence_stratum": strata,
        "xray_percentile": xray_pct,
        "xray_tier": xray_tier,
    })

    baseline_sets = {}
    variant_sets = {}
    for name, s in variants.items():
        tier = fixed_fraction_tiers(s)
        pct = percentile_rank(s)
        gold = set(df.index[tier.eq("Gold")])
        top30_idx = numeric(s[~known]).sort_values(ascending=False).head(30).index
        top30 = set(names.loc[top30_idx])
        list_a_mask = (~known) & tier.isin(["Gold", "Silver"]) & xray_tier.eq("Gold")
        list_b_mask = (~known) & tier.eq("Gold") & ~xray_tier.eq("Gold")
        list_a = set(df.index[list_a_mask]); list_b = set(df.index[list_b_mask])
        variant_sets[(name, "A")] = list_a
        variant_sets[(name, "B")] = list_b
        if name == "published_available":
            baseline_sets["A"] = list_a; baseline_sets["B"] = list_b

        summary_rows.append({
            "score_variant": name,
            "Gold_N": len(gold),
            "Gold_Jaccard_vs_published": jaccard(gold, base_gold),
            "Gold_overlap_N": len(gold & base_gold),
            "top30_nonTeV_overlap_N": len(top30 & base_top30),
            "List_A_N": len(list_a),
            "List_B_N": len(list_b),
        })
        assignment[f"score_{name}"] = s
        assignment[f"percentile_{name}"] = pct
        assignment[f"tier_{name}"] = tier
        assignment[f"in_List_A_{name}"] = list_a_mask
        assignment[f"in_List_B_{name}"] = list_b_mask

        # Release architecture-specific lists using the same claim gates as v0.3.1.
        for list_label, mask in [("A_xray_prioritized", list_a_mask), ("B_HSP_branch_frontier", list_b_mask)]:
            d = pd.DataFrame({
                "source_name": names[mask],
                "redshift": z[mask],
                "redshift_secure": secure[mask],
                "log_nu_peak_proxy": numeric(df.loc[mask, "log_nu_peak_proxy"]),
                "full_score_variant": name,
                "full_score": s[mask],
                "full_percentile": pct[mask],
                "full_tier": tier[mask],
                "xray_score": xray[mask],
                "xray_percentile": xray_pct[mask],
                "xray_tier": xray_tier[mask],
                "continuous_peak_percentile": cont_pct[mask],
                "continuous_peak_tier": df.loc[mask, "tier_continuous_peak_only"].astype(str),
                "evidence_stratum": strata[mask],
            })
            if list_label.startswith("A_"):
                d["priority_index"] = 0.40*d["full_percentile"] + 0.35*d["xray_percentile"] + 0.15*d["continuous_peak_percentile"] + 0.10*z_favour[mask]
                d["scope_note"] = "X-ray-prioritized follow-up list; not a calibrated detection probability."
            else:
                d["priority_index"] = 0.45*d["full_percentile"] + 0.25*d["continuous_peak_percentile"] + 0.20*peak_pct[mask].fillna(50) + 0.10*z_favour[mask]
                d["scope_note"] = "HSP-branch-frontier list; identity remains conditional on peak-proxy construction."
            d = d.sort_values(["evidence_stratum", "priority_index"], ascending=[True, False])
            d.to_csv(TABLES / f"candidate_list_{list_label}_{name}_all_v0_4_3.csv", index=False)
            core = d[d["evidence_stratum"].eq("core_low_z_stable")].sort_values("priority_index", ascending=False)
            core.head(20).to_csv(TABLES / f"candidate_list_{list_label}_{name}_core_top20_v0_4_3.csv", index=False)
            for stratum, g in d.groupby("evidence_stratum", dropna=False):
                list_rows.append({
                    "score_variant": name,
                    "followup_list": list_label,
                    "evidence_stratum": stratum,
                    "N": len(g),
                    "median_full_percentile": float(g["full_percentile"].median()),
                    "median_xray_percentile": float(g["xray_percentile"].median()),
                    "median_redshift": float(numeric(g["redshift"]).median()) if numeric(g["redshift"]).notna().any() else np.nan,
                })

    summary = pd.DataFrame(summary_rows)
    for i, row in summary.iterrows():
        name = row["score_variant"]
        summary.loc[i, "List_A_Jaccard_vs_published"] = jaccard(variant_sets[(name, "A")], baseline_sets["A"])
        summary.loc[i, "List_A_overlap_N"] = len(variant_sets[(name, "A")] & baseline_sets["A"])
        summary.loc[i, "List_B_Jaccard_vs_published"] = jaccard(variant_sets[(name, "B")], baseline_sets["B"])
        summary.loc[i, "List_B_overlap_N"] = len(variant_sets[(name, "B")] & baseline_sets["B"])
    summary.to_csv(TABLES / "table_candidate_architecture_stability_v0_4_3.csv", index=False)
    pd.DataFrame(list_rows).to_csv(TABLES / "table_followup_list_architecture_strata_v0_4_3.csv", index=False)
    assignment.to_csv(TABLES / "table_candidate_architecture_assignments_v0_4_3.csv", index=False)

    print("v0.4.3 candidate and follow-up-list stability complete.")
    print(summary.to_string(index=False))


if __name__ == "__main__":
    main()
