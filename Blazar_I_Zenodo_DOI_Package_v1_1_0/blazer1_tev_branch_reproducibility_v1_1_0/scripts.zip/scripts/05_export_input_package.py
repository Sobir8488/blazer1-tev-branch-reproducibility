#!/usr/bin/env python
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import yaml
import pandas as pd


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--config", default="configs/config.yaml")
    args = p.parse_args()
    cfg = yaml.safe_load(Path(args.config).read_text())
    processed = Path(cfg["paths"]["processed"])
    metadata = Path(cfg["paths"]["metadata"])
    tables = Path(cfg["paths"]["tables"])
    tables.mkdir(parents=True, exist_ok=True)
    metadata.mkdir(parents=True, exist_ok=True)

    checksums = {}
    for path in list(processed.glob("*.csv")) + list(tables.glob("*.csv")):
        checksums[str(path)] = sha256(path)
    (metadata / "checksums_sha256.json").write_text(json.dumps(checksums, indent=2))

    score_path = Path(cfg["outputs"]["score_catalogue"])
    if score_path.exists():
        df = pd.read_csv(score_path)
        summary = {
            "n_rows": int(len(df)),
            "n_gold": int((df.get("tev_priority_tier") == "Gold").sum()),
            "n_silver": int((df.get("tev_priority_tier") == "Silver").sum()),
            "n_bronze": int((df.get("tev_priority_tier") == "Bronze").sum()),
        }
        (metadata / "provenance.json").write_text(json.dumps(summary, indent=2))
    print("[OK] exported metadata checksums and provenance")


if __name__ == "__main__":
    main()
