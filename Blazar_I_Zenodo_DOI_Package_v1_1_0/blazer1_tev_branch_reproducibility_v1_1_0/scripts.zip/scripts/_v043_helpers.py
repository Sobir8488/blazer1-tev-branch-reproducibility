from __future__ import annotations

from pathlib import Path
import math
import os
from typing import Iterable

import numpy as np
import pandas as pd
from scipy.stats import mannwhitneyu, norm, rankdata, spearmanr

ROOT = Path(__file__).resolve().parents[1]
PROCESSED = ROOT / "data" / "processed"
TABLES = ROOT / "tables"
FIGURES = ROOT / "figures"
DOCS = ROOT / "docs"
METADATA = ROOT / "metadata"
for _p in (PROCESSED, TABLES, FIGURES, DOCS, METADATA):
    _p.mkdir(parents=True, exist_ok=True)

COMPONENTS = [
    {"key": "xray_brightness", "column": "S_X", "label": "X-ray brightness", "weight": 1.00, "sign": +1},
    {"key": "gamma_hardness", "column": "S_gamma_hard", "label": "Gamma-ray hardness", "weight": 1.00, "sign": +1},
    {"key": "gamma_variability", "column": "S_gamma_var", "label": "Gamma-ray variability", "weight": 0.35, "sign": +1},
    {"key": "wise_hsp_locus", "column": "S_IR", "label": "WISE/HSP-locus proxy", "weight": 0.75, "sign": +1},
    {"key": "radio_compactness", "column": "S_R", "label": "Radio-compactness proxy", "weight": 0.75, "sign": +1},
    {"key": "synchrotron_peak_proxy", "column": "S_nu_peak", "label": "Synchrotron-peak proxy", "weight": 1.00, "sign": +1},
    {"key": "compton_dominance_penalty", "column": "S_CD_penalty", "label": "Compton-dominance penalty", "weight": 0.60, "sign": -1},
    {"key": "ebl_penalty", "column": "S_EBL_proxy", "label": "Redshift/EBL penalty", "weight": 0.80, "sign": -1},
]


def numeric(s: pd.Series | np.ndarray) -> pd.Series:
    if isinstance(s, pd.Series):
        return pd.to_numeric(s, errors="coerce").replace([np.inf, -np.inf], np.nan)
    return pd.Series(np.asarray(s)).pipe(pd.to_numeric, errors="coerce").replace([np.inf, -np.inf], np.nan)


def as_bool(s: pd.Series) -> pd.Series:
    if s.dtype == bool:
        return s.fillna(False)
    return s.astype(str).str.strip().str.lower().isin({"1", "true", "t", "yes", "y"})


def load_frozen_catalogue() -> tuple[pd.DataFrame, Path]:
    candidates = [
        PROCESSED / "tev_evolution_score_catalog_v0_1_8_xray_control_augmented.csv",
        PROCESSED / "tev_evolution_score_catalog_v0_1_8_interpretability_augmented.csv",
        PROCESSED / "tev_evolution_score_catalog_v0_1_6_branch_augmented.csv",
    ]
    for path in candidates:
        if path.exists():
            df = pd.read_csv(path, low_memory=False)
            if "is_known_tev" in df.columns:
                df["is_known_tev"] = as_bool(df["is_known_tev"])
            elif "tevcat_matched" in df.columns:
                df["is_known_tev"] = as_bool(df["tevcat_matched"])
            else:
                raise KeyError("No TeV validation label found in frozen catalogue.")
            return df, path
    raise FileNotFoundError(
        "Missing frozen score catalogue. Run v0.1.8 interpretability/X-ray-control scripts first."
    )


def source_name(df: pd.DataFrame) -> pd.Series:
    for col in ["source_name_v031", "source_name", "SRC_NAME", "IAUNAME", "FGL_SRC_NAME", "NAME"]:
        if col in df.columns:
            out = df[col].astype(str).replace({"nan": "", "None": ""})
            if out.str.len().gt(0).any():
                return out
    return pd.Series([f"row_{i}" for i in range(len(df))], index=df.index)


def component_activity(df: pd.DataFrame, tol: float = 1e-12) -> pd.DataFrame:
    rows = []
    for meta in COMPONENTS:
        x = numeric(df[meta["column"]]) if meta["column"] in df.columns else pd.Series(np.nan, index=df.index)
        finite = x.dropna()
        std = float(finite.std(ddof=0)) if len(finite) else np.nan
        span = float(finite.max() - finite.min()) if len(finite) else np.nan
        active = bool(len(finite) > 1 and np.isfinite(std) and np.isfinite(span) and std > tol and span > tol)
        rows.append({
            "component_key": meta["key"],
            "component_column": meta["column"],
            "component_label": meta["label"],
            "fixed_weight": meta["weight"],
            "sign": meta["sign"],
            "available_N": int(x.notna().sum()),
            "numeric_std": std,
            "numeric_span": span,
            "active_for_denominator": active,
        })
    return pd.DataFrame(rows)


def compute_architecture_scores(df: pd.DataFrame, tol: float = 1e-12) -> tuple[dict[str, pd.Series], pd.DataFrame]:
    activity = component_activity(df, tol=tol)
    active_keys = set(activity.loc[activity["active_for_denominator"], "component_key"])

    total_all = pd.Series(0.0, index=df.index, dtype=float)
    denom_available_all = pd.Series(0.0, index=df.index, dtype=float)
    total_active = pd.Series(0.0, index=df.index, dtype=float)
    denom_available_active = pd.Series(0.0, index=df.index, dtype=float)

    for meta in COMPONENTS:
        x = numeric(df[meta["column"]])
        valid = x.notna()
        signed = meta["sign"] * meta["weight"] * x
        total_all.loc[valid] += signed.loc[valid]
        denom_available_all.loc[valid] += abs(meta["weight"])
        if meta["key"] in active_keys:
            total_active.loc[valid] += signed.loc[valid]
            denom_available_active.loc[valid] += abs(meta["weight"])

    fixed_all = float(sum(abs(m["weight"]) for m in COMPONENTS))
    fixed_active = float(sum(abs(m["weight"]) for m in COMPONENTS if m["key"] in active_keys))

    published = numeric(df["S_TeV_evo"]) if "S_TeV_evo" in df.columns else total_all / denom_available_all.replace(0, np.nan)
    scores = {
        "published_available": published,
        "radio_free_available": total_active / denom_available_active.replace(0, np.nan),
        "active_available": total_active / denom_available_active.replace(0, np.nan),
        "fixed_all_weight": total_all / fixed_all,
        "fixed_active_weight": total_active / fixed_active,
    }
    if "S_xray_only_v0_1_8" in df.columns:
        scores["xray_only"] = numeric(df["S_xray_only_v0_1_8"])
    else:
        scores["xray_only"] = numeric(df["S_X"])
    if "S_no_xray_v0_1_8" in df.columns:
        scores["no_xray"] = numeric(df["S_no_xray_v0_1_8"])

    return scores, activity


def availability_pattern(df: pd.DataFrame) -> pd.Series:
    bits = df[[m["column"] for m in COMPONENTS]].notna().to_numpy(dtype=bool)
    values = ["".join("1" if v else "0" for v in row) for row in bits]
    return pd.Series(values, index=df.index, dtype="object")


def component_count(df: pd.DataFrame) -> pd.Series:
    return df[[m["column"] for m in COMPONENTS]].notna().sum(axis=1)


def available_weight(df: pd.DataFrame, active_only: bool = False, activity: pd.DataFrame | None = None) -> pd.Series:
    if activity is None:
        activity = component_activity(df)
    active_keys = set(activity.loc[activity["active_for_denominator"], "component_key"])
    out = pd.Series(0.0, index=df.index, dtype=float)
    for meta in COMPONENTS:
        if active_only and meta["key"] not in active_keys:
            continue
        out += df[meta["column"]].notna().astype(float) * abs(meta["weight"])
    return out


def percentile_rank(scores: pd.Series) -> pd.Series:
    return numeric(scores).rank(method="average", pct=True) * 100.0


def fixed_fraction_tiers(scores: pd.Series) -> pd.Series:
    s = numeric(scores)
    out = pd.Series("Low", index=s.index, dtype="object")
    valid = s.dropna()
    if valid.empty:
        return out
    q70, q85, q95 = np.nanpercentile(valid, [70, 85, 95])
    out.loc[s >= q70] = "Bronze"
    out.loc[s >= q85] = "Silver"
    out.loc[s >= q95] = "Gold"
    return out


def auroc(y_true: pd.Series | np.ndarray, scores: pd.Series | np.ndarray) -> float:
    y = np.asarray(y_true, dtype=bool)
    s = np.asarray(scores, dtype=float)
    valid = np.isfinite(s)
    y, s = y[valid], s[valid]
    n_pos, n_neg = int(y.sum()), int((~y).sum())
    if n_pos == 0 or n_neg == 0:
        return np.nan
    u = mannwhitneyu(s[y], s[~y], alternative="greater").statistic
    return float(u / (n_pos * n_neg))


def safe_spearman(a: pd.Series | np.ndarray, b: pd.Series | np.ndarray) -> tuple[float, float, int]:
    aa = np.asarray(a, dtype=float)
    bb = np.asarray(b, dtype=float)
    valid = np.isfinite(aa) & np.isfinite(bb)
    if int(valid.sum()) < 3:
        return np.nan, np.nan, int(valid.sum())
    rho, p = spearmanr(aa[valid], bb[valid])
    return float(rho), float(p), int(valid.sum())


def top_n_non_tev_names(df: pd.DataFrame, score: pd.Series, n: int = 30) -> set[str]:
    mask = ~df["is_known_tev"].astype(bool) & numeric(score).notna()
    idx = numeric(score[mask]).sort_values(ascending=False).head(n).index
    return set(source_name(df).loc[idx])


def jaccard(a: Iterable, b: Iterable) -> float:
    aa, bb = set(a), set(b)
    if not aa and not bb:
        return 1.0
    return float(len(aa & bb) / len(aa | bb))


def _midrank(x: np.ndarray) -> np.ndarray:
    order = np.argsort(x)
    sx = x[order]
    out = np.empty(len(x), dtype=float)
    i = 0
    while i < len(x):
        j = i + 1
        while j < len(x) and sx[j] == sx[i]:
            j += 1
        out[i:j] = 0.5 * (i + j - 1) + 1.0
        i = j
    ans = np.empty(len(x), dtype=float)
    ans[order] = out
    return ans


def delong_pair(y_true: pd.Series | np.ndarray, a: pd.Series | np.ndarray, b: pd.Series | np.ndarray) -> dict:
    y = np.asarray(y_true, dtype=bool)
    aa = np.asarray(a, dtype=float)
    bb = np.asarray(b, dtype=float)
    valid = np.isfinite(aa) & np.isfinite(bb)
    y, aa, bb = y[valid], aa[valid], bb[valid]
    order = np.argsort(~y)
    preds = np.vstack([aa[order], bb[order]])
    m = int(y.sum())
    n = len(y) - m
    if m < 2 or n < 2:
        return {"auc_a": np.nan, "auc_b": np.nan, "delta_auc": np.nan, "p_two_sided": np.nan, "N": len(y), "N_pos": m}
    pos = preds[:, :m]
    neg = preds[:, m:]
    k = preds.shape[0]
    tx = np.empty((k, m)); ty = np.empty((k, n)); tz = np.empty((k, m+n))
    for r in range(k):
        tx[r] = _midrank(pos[r]); ty[r] = _midrank(neg[r]); tz[r] = _midrank(preds[r])
    aucs = tz[:, :m].sum(axis=1)/(m*n) - (m+1.0)/(2.0*n)
    v01 = (tz[:, :m] - tx)/n
    v10 = 1.0 - (tz[:, m:] - ty)/m
    sx = np.atleast_2d(np.cov(v01, bias=False)); sy = np.atleast_2d(np.cov(v10, bias=False))
    cov = sx/m + sy/n
    contrast = np.array([1.0, -1.0])
    var = float(contrast @ cov @ contrast.T)
    se = math.sqrt(max(var, 0.0))
    delta = float(aucs[0] - aucs[1])
    z = delta/se if se > 0 else np.nan
    p = 2*norm.sf(abs(z)) if np.isfinite(z) else np.nan
    return {"auc_a": float(aucs[0]), "auc_b": float(aucs[1]), "delta_auc": delta, "se_delta": se, "z": z, "p_two_sided": float(p), "N": len(y), "N_pos": m}


def paired_bootstrap_deltas(
    y_true: pd.Series | np.ndarray,
    scores: dict[str, pd.Series | np.ndarray],
    comparisons: list[tuple[str, str]],
    n_boot: int,
    seed: int,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    y = np.asarray(y_true, dtype=bool)
    arrays = {k: np.asarray(v, dtype=float) for k, v in scores.items()}
    common = np.ones(len(y), dtype=bool)
    for arr in arrays.values():
        common &= np.isfinite(arr)
    y = y[common]
    arrays = {k: v[common] for k, v in arrays.items()}
    pos = np.flatnonzero(y); neg = np.flatnonzero(~y)
    rng = np.random.default_rng(seed)
    rows = []
    for draw in range(n_boot):
        idx = np.concatenate([rng.choice(pos, len(pos), replace=True), rng.choice(neg, len(neg), replace=True)])
        yy = y[idx]
        vals = {k: auroc(yy, v[idx]) for k, v in arrays.items()}
        row = {"draw": draw, **{f"auc_{k}": v for k, v in vals.items()}}
        for a, b in comparisons:
            row[f"delta_{a}_minus_{b}"] = vals[a] - vals[b]
        rows.append(row)
    draws = pd.DataFrame(rows)
    summaries = []
    for a, b in comparisons:
        col = f"delta_{a}_minus_{b}"
        vals = draws[col].to_numpy(dtype=float)
        p_lo = (np.sum(vals <= 0) + 1)/(len(vals)+1)
        p_hi = (np.sum(vals >= 0) + 1)/(len(vals)+1)
        summaries.append({
            "model_a": a,
            "model_b": b,
            "delta_auc": auroc(y, arrays[a]) - auroc(y, arrays[b]),
            "bootstrap_median": float(np.nanmedian(vals)),
            "ci95_low": float(np.nanpercentile(vals, 2.5)),
            "ci95_high": float(np.nanpercentile(vals, 97.5)),
            "bootstrap_p_two_sided": float(min(1.0, 2*min(p_lo, p_hi))),
            "N": len(y),
            "N_pos": int(y.sum()),
            "n_boot": n_boot,
        })
    return draws, pd.DataFrame(summaries)


def within_pattern_percentile(scores: pd.Series, patterns: pd.Series, eligible: pd.Series | None = None) -> pd.Series:
    s = numeric(scores)
    out = pd.Series(np.nan, index=s.index, dtype=float)
    if eligible is None:
        eligible = pd.Series(True, index=s.index)
    for pattern, idx in patterns[eligible].groupby(patterns[eligible]).groups.items():
        vals = s.loc[idx]
        out.loc[idx] = vals.rank(method="average", pct=True)
    return out


def classify_stratum(z: float, secure: bool, continuous_stable: bool) -> str:
    if not np.isfinite(z):
        return "unknown_redshift"
    if z > 0.5:
        return "attenuation_caution_z_gt_0p5"
    if not secure:
        return "redshift_quality_caution"
    if not continuous_stable:
        return "peak_proxy_sensitivity_caution"
    return "core_low_z_stable"
