from __future__ import annotations

import sys
from pathlib import Path
sys.path.append(str(Path(__file__).resolve().parent))

import numpy as np
import pandas as pd
from scipy.stats import fisher_exact, mannwhitneyu

from _v030_helpers import TABLES, DOCS
from _v031_v033_helpers import (
    EXTERNAL, load_frozen, coordinate_crossmatch, attach_catalogue_fields,
    exact_permutation_auc,
)


def main() -> None:
    df, frozen_path = load_frozen()
    obs_path = EXTERNAL / "iact_observed_outcomes_v0_3_3.csv"
    if not obs_path.exists():
        raise FileNotFoundError(f"Missing seeded observed-outcome file: {obs_path}")
    obs = pd.read_csv(obs_path, low_memory=False)
    obs["candidate_program_eligible"] = obs["candidate_program_eligible"].astype(str).str.lower().isin({"true","1","yes"})
    obs["firm_detection"] = obs["outcome"].astype(str).eq("firm_detection")

    matched = coordinate_crossmatch(obs, df, radius_arcsec=180.0)
    matched = attach_catalogue_fields(matched, df)
    matched["control_scope"] = "homogeneous_MAGIC_extreme_blazar_program_pilot"
    matched.to_csv(TABLES / "table_iact_observed_outcomes_crossmatch_v0_3_3.csv", index=False)
    matched[matched["catalogue_matched"].astype(bool)].to_csv(TABLES / "table_iact_observed_outcomes_matched_v0_3_3.csv", index=False)
    matched[~matched["catalogue_matched"].astype(bool)].to_csv(TABLES / "table_iact_observed_outcomes_unmatched_v0_3_3.csv", index=False)

    primary = matched[matched["candidate_program_eligible"] & matched["catalogue_matched"].astype(bool)].copy()
    # Aggregate repeated programme observations by matched catalogue source.
    agg_rows = []
    for rid, g in primary.groupby("catalogue_row_id"):
        best = g.sort_values("significance_sigma", ascending=False).iloc[0].to_dict()
        best["observation_rows_aggregated"] = len(g)
        best["firm_detection"] = bool(g["firm_detection"].any())
        best["outcome_aggregate"] = "firm_detection" if best["firm_detection"] else "nonfirm_observed_control"
        best["program_ids"] = ";".join(sorted(set(g["program_id"].astype(str))))
        agg_rows.append(best)
    unique = pd.DataFrame(agg_rows)
    unique.to_csv(TABLES / "table_iact_observed_control_unique_sources_v0_3_3.csv", index=False)

    score_cols = {
        "full": "matched_full_score_v031",
        "xray_only": "matched_xray_only_score_v031",
        "no_xray": "matched_no_xray_score_v031",
        "continuous_peak_only": "matched_score_continuous_peak_only",
    }
    metric_rows = []
    if not unique.empty and unique["firm_detection"].nunique() == 2:
        y = unique["firm_detection"].to_numpy(dtype=bool)
        for label, col in score_cols.items():
            score = pd.to_numeric(unique[col], errors="coerce").to_numpy(dtype=float)
            res = exact_permutation_auc(y, score)
            firm_vals = score[y & np.isfinite(score)]
            non_vals = score[(~y) & np.isfinite(score)]
            try:
                mw_p = float(mannwhitneyu(firm_vals, non_vals, alternative="two-sided").pvalue) if len(firm_vals) and len(non_vals) else np.nan
            except Exception:
                mw_p = np.nan
            metric_rows.append({
                "score_variant": label,
                "unique_matched_N": int(np.isfinite(score).sum()),
                "firm_detection_N": int((y & np.isfinite(score)).sum()),
                "nonfirm_control_N": int(((~y) & np.isfinite(score)).sum()),
                "AUROC_firm_vs_nonfirm": res["auc"],
                "permutation_p_two_sided": res["p_two_sided"],
                "permutation_exact": res["exact"],
                "n_permutations": res["n_permutations"],
                "median_firm": float(np.nanmedian(firm_vals)) if len(firm_vals) else np.nan,
                "median_nonfirm": float(np.nanmedian(non_vals)) if len(non_vals) else np.nan,
                "mannwhitney_p_two_sided": mw_p,
            })
    metrics = pd.DataFrame(metric_rows)
    metrics.to_csv(TABLES / "table_iact_observed_control_score_metrics_v0_3_3.csv", index=False)

    fisher_rows = []
    if not unique.empty and unique["firm_detection"].nunique() == 2:
        for label, tier_col in {
            "full": "matched_full_tier_v031",
            "xray_only": "matched_xray_only_tier_v031",
            "no_xray": "matched_no_xray_tier_v031",
            "continuous_peak_only": "matched_tier_continuous_peak_only",
        }.items():
            high = unique[tier_col].astype(str).isin(["Gold", "Silver"])
            firm = unique["firm_detection"].astype(bool)
            table = np.array([
                [int((firm & high).sum()), int((firm & ~high).sum())],
                [int((~firm & high).sum()), int((~firm & ~high).sum())],
            ])
            odds, p = fisher_exact(table, alternative="two-sided")
            fisher_rows.append({
                "score_variant": label,
                "firm_high_N": table[0,0], "firm_not_high_N": table[0,1],
                "nonfirm_high_N": table[1,0], "nonfirm_not_high_N": table[1,1],
                "fisher_odds_ratio": odds, "fisher_p_two_sided": p,
            })
    fisher = pd.DataFrame(fisher_rows)
    fisher.to_csv(TABLES / "table_iact_observed_control_tier_fisher_v0_3_3.csv", index=False)

    report = [
        "# v0.3.3 IACT observed-but-not-detected control pilot", "",
        f"Frozen catalogue: `{frozen_path}`", "",
        "The control sample is seeded from two homogeneous MAGIC extreme-blazar programmes. Historically known VHE sources are excluded from the primary candidate-outcome comparison.", "",
        f"Observation rows={len(obs)}; coordinate matches={int(matched['catalogue_matched'].sum())}; primary eligible matched rows={len(primary)}; unique matched sources={len(unique)}.", "",
        "Because BlazEr1 overlap is small, all inference is exploratory and exact/permutation tests are reported.", "",
        "## Score metrics", "", metrics.to_markdown(index=False) if not metrics.empty else "No two-class matched sample was available.", "",
        "## Gold+Silver Fisher tests", "", fisher.to_markdown(index=False) if not fisher.empty else "No two-class matched sample was available.",
    ]
    (DOCS / "iact_observed_control_report_v0_3_3.md").write_text("\n".join(report), encoding="utf-8")
    print("v0.3.3 IACT observed-control pilot complete.")
    print(f"Observation rows={len(obs)}; matched={int(matched['catalogue_matched'].sum())}; primary unique matched={len(unique)}")
    if not metrics.empty:
        print(metrics.to_string(index=False))
    if not fisher.empty:
        print("\nTier Fisher tests:")
        print(fisher.to_string(index=False))


if __name__ == "__main__":
    main()
