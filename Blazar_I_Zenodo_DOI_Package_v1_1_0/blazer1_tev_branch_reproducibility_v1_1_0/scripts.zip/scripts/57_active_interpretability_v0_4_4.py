#!/usr/bin/env python
from __future__ import annotations
import numpy as np
import pandas as pd
from scipy.stats import ks_2samp
from _v044_helpers import *


def contribution_table(df):
    den=pd.Series(0.,index=df.index)
    for _,(c,_,w,_) in ACTIVE_COMPONENTS.items(): den += numeric(df[c]).notna().astype(float)*abs(w)
    contrib={}
    for k,(c,sign,w,label) in ACTIVE_COMPONENTS.items(): contrib[k]=sign*w*numeric(df[c])/den.replace(0,np.nan)
    groups={
        "known_TeV":df["is_known_tev"],
        "Gold_all":df["tier_active_v0_4_4"].eq("Gold"),
        "Gold_non_TeV":df["tier_active_v0_4_4"].eq("Gold")&~df["is_known_tev"],
        "BL_Lac_like":df.get("broad_class",pd.Series("",index=df.index)).astype(str).eq("BL Lac-like"),
        "HSP_like":df.get("sed_class_proxy",pd.Series("",index=df.index)).astype(str).eq("HSP-like"),
    }
    rows=[]
    for g,m in groups.items():
        abs_sums={k:float(contrib[k][m].abs().sum(skipna=True)) for k in contrib}; total=sum(abs_sums.values())
        for k,(c,sign,w,label) in ACTIVE_COMPONENTS.items():
            rows.append({"sample":g,"component_key":k,"component_label":label,"N_sample":int(m.sum()),"available_fraction":float(numeric(df.loc[m,c]).notna().mean()) if m.sum() else np.nan,"mean_signed_contribution":float(contrib[k][m].mean()),"mean_absolute_contribution":float(contrib[k][m].abs().mean()),"fraction_of_abs_contribution":abs_sums[k]/total if total else np.nan,"contribution_percent":100*abs_sums[k]/total if total else np.nan})
            df[f"contribution_active_{k}_v0_4_4"]=contrib[k]
    tab=pd.DataFrame(rows); tab.to_csv(TABLES/"table_active_component_contributions_v0_4_4.csv",index=False); return df,tab


def pca_active(df):
    cols=[v[0] for v in ACTIVE_COMPONENTS.values()]; labels=[v[3] for v in ACTIVE_COMPONENTS.values()]
    X=np.column_stack([numeric(df[c]).to_numpy() for c in cols])
    med=np.nanmedian(X,axis=0); inds=np.where(~np.isfinite(X)); X[inds]=np.take(med,inds[1]); mu=X.mean(axis=0); sd=X.std(axis=0,ddof=1); sd[sd==0]=1; Z=(X-mu)/sd
    U,S,Vt=np.linalg.svd(Z,full_matrices=False); scores=U*S; ev=(S*S)/(len(Z)-1); frac=ev/ev.sum()
    active=numeric(df["S_TeV_branch_active_v0_4_4"]).to_numpy(); m=np.isfinite(active)
    if spearmanr(scores[m,0],active[m]).statistic<0: scores[:,0]*=-1; Vt[0]*=-1
    for i in range(min(5,scores.shape[1])): df[f"PC{i+1}_active_v0_4_4"]=scores[:,i]
    pd.DataFrame({"PC":[f"PC{i+1}" for i in range(len(frac))],"explained_variance_fraction":frac}).to_csv(TABLES/"table_active_pca_explained_variance_v0_4_4.csv",index=False)
    load=[]
    for j,(c,label) in enumerate(zip(cols,labels)):
        row={"feature_column":c,"feature_label":label,"missing_fraction_before_imputation":float(np.mean(~np.isfinite(np.column_stack([numeric(df[x]).to_numpy() for x in cols])[:,j])))}
        for i in range(min(5,Vt.shape[0])): row[f"PC{i+1}_loading"]=float(Vt[i,j])
        load.append(row)
    pd.DataFrame(load).to_csv(TABLES/"table_active_pca_loadings_v0_4_4.csv",index=False)
    z=numeric(df.get("redshift_adopted_clean",df.get("redshift_adopted"))); rel=[]
    for label,x in [("PC1_vs_active_score",df["S_TeV_branch_active_v0_4_4"]),("PC1_vs_redshift",z),("PC1_vs_log_nu_peak",df["log_nu_peak_proxy"]),("PC1_vs_branch_stage",df.get("branch_stage_rank_active_v0_4_4",df.get("branch_stage_rank")))]:
        r,p,n=safe_spearman(df["PC1_active_v0_4_4"],x); rel.append({"relation":label,"N":n,"spearman_rho":r,"p_value":p})
    rel.append({"relation":"PC1_known_TeV_AUROC","N":len(df),"spearman_rho":auc_rank(df["is_known_tev"].to_numpy(),numeric(df["PC1_active_v0_4_4"]).to_numpy()),"p_value":np.nan})
    tab=pd.DataFrame(rel); tab.to_csv(TABLES/"table_active_pca_validation_v0_4_4.csv",index=False); return df,tab


def similarity(df):
    gold_non=df["tier_active_v0_4_4"].eq("Gold")&~df["is_known_tev"]; known=df["is_known_tev"]
    features=[("redshift",df.get("redshift_adopted_clean",df.get("redshift_adopted"))),("log_nu_peak",df["log_nu_peak_proxy"]),("active_score",df["S_TeV_branch_active_v0_4_4"]),("X_ray_component",df["S_X"]),("gamma_hardness",df["S_gamma_hard"]),("gamma_variability",df["S_gamma_var"]),("WISE_HSP",df["S_IR"]),("redshift_EBL_component",df["S_EBL_proxy"]),("Compton_dominance_penalty",df["S_CD_penalty"]),("PCA_branch_axis",df["PC1_active_v0_4_4"])]
    rows=[]
    for label,s in features:
        a=numeric(s[known]).dropna(); b=numeric(s[gold_non]).dropna(); p=ks_2samp(a,b,alternative="two-sided").pvalue if len(a) and len(b) else np.nan
        rows.append({"feature":label,"known_TeV_N":len(a),"Gold_nonTeV_N":len(b),"known_TeV_median":float(a.median()) if len(a) else np.nan,"Gold_nonTeV_median":float(b.median()) if len(b) else np.nan,"KS_p_two_sided":float(p)})
    tab=pd.DataFrame(rows); tab.to_csv(TABLES/"table_active_gold_vs_known_TeV_v0_4_4.csv",index=False)

    cols=[v[0] for v in ACTIVE_COMPONENTS.values()]; X=np.column_stack([numeric(df[c]).to_numpy() for c in cols]); med=np.nanmedian(X,axis=0); bad=~np.isfinite(X); X[bad]=np.take(med,np.where(bad)[1]); mu=np.mean(X,axis=0); sd=np.std(X,axis=0,ddof=1); sd[sd==0]=1; Z=(X-mu)/sd
    kz=np.flatnonzero(known.to_numpy()); nz=np.flatnonzero(~known.to_numpy()); dist=np.full(len(df),np.nan)
    block=500
    for start in range(0,len(nz),block):
        ids=nz[start:start+block]; D=np.sqrt(((Z[ids,None,:]-Z[kz][None,:,:])**2).sum(axis=2)); dist[ids]=D.min(axis=1)
    df["nearest_known_TeV_distance_active_v0_4_4"]=dist
    summaries=[]
    for label,m in [("Gold_nonTeV",gold_non),("nonGold_nonTeV",~known&~df["tier_active_v0_4_4"].eq("Gold"))]:
        v=pd.Series(dist,index=df.index)[m].dropna(); summaries.append({"comparison_group":label,"N":len(v),"median_nearest_known_TeV_distance":float(v.median()),"p16_distance":float(v.quantile(.16)),"p84_distance":float(v.quantile(.84))})
    pd.DataFrame(summaries).to_csv(TABLES/"table_active_nearest_known_TeV_distance_v0_4_4.csv",index=False)
    top=df.loc[gold_non].copy().sort_values(["nearest_known_TeV_distance_active_v0_4_4","S_TeV_branch_active_v0_4_4"],ascending=[True,False]).head(50)
    keep=[c for c in ["source_name_v044","ra_deg","dec_deg","redshift_adopted_clean","log_nu_peak_proxy","S_TeV_branch_active_v0_4_4","tier_active_v0_4_4","nearest_known_TeV_distance_active_v0_4_4"] if c in top]
    top[keep].to_csv(TABLES/"table_active_top_gold_nonTeV_analogues_v0_4_4.csv",index=False)
    return df,tab


def main():
    df,src=load_active_catalogue(); df=add_primary_columns(df)
    if "branch_stage_rank_active_v0_4_4" not in df:
        df["branch_stage_rank_active_v0_4_4"]=df.get("branch_stage",pd.Series("",index=df.index)).map({s:i for i,s in enumerate(STAGE_ORDER)})
    df,cont=contribution_table(df); df,pca=pca_active(df); df,sim=similarity(df)
    out=PROCESSED/"tev_evolution_score_catalog_v0_4_4_active_interpretability.csv"; df.to_csv(out,index=False)
    print("v0.4.4 active interpretability analyses complete.")
    print(f"Augmented catalogue: {out}")
    print("\nContribution summary (known TeV and Gold non-TeV):")
    print(cont[cont["sample"].isin(["known_TeV","Gold_non_TeV"])][["sample","component_label","contribution_percent"]].to_string(index=False))
    print("\nPCA validation:"); print(pca.to_string(index=False))
    print("\nGold vs known TeV:"); print(sim.to_string(index=False))

if __name__=="__main__": main()
