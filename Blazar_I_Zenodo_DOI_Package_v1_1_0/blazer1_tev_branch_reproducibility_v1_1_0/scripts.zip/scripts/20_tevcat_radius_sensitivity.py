#!/usr/bin/env python
"""
v0.1.7 TeVCat cross-match radius sensitivity.

Purpose
-------
Reviewer-facing robustness test: repeat the independent known-TeV validation
for several TeVCat matching radii (default: 60, 90, 120, 180 arcsec).
The score is not recomputed. Only the external validation label is recomputed
from the TeVCat positions.

Outputs
-------
- tables/table_tevcat_radius_sensitivity_v0_1_7.csv
- tables/table_tevcat_radius_sensitivity_v0_1_7.tex
- figures/Fig_tevcat_radius_sensitivity_v0_1_7.{png,pdf}
- data/processed/tevcat_nearest_match_audit_v0_1_7.csv
"""
from __future__ import annotations

import math
from pathlib import Path
from typing import Iterable

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

try:
    from scipy.stats import hypergeom, mannwhitneyu
except Exception as exc:  # pragma: no cover
    raise SystemExit("scipy is required for v0.1.7 validation statistics") from exc

ROOT = Path(__file__).resolve().parents[1]
TABLES = ROOT / "tables"
FIGURES = ROOT / "figures"
PROCESSED = ROOT / "data" / "processed"
INTERIM = ROOT / "data" / "interim"
RAW = ROOT / "data" / "raw"

RADII_ARCSEC = [60.0, 90.0, 120.0, 180.0]
TIER_SETS = {
    "Gold": {"Gold"},
    "Gold+Silver": {"Gold", "Silver"},
    "Gold+Silver+Bronze": {"Gold", "Silver", "Bronze"},
}


def read_first_existing(paths: Iterable[Path]) -> pd.DataFrame:
    for p in paths:
        if p.exists():
            return pd.read_csv(p, low_memory=False)
    raise FileNotFoundError("None of these files exists: " + ", ".join(str(p) for p in paths))


def clean_str(x):
    if pd.isna(x):
        return np.nan
    s = str(x).strip()
    if s.startswith("b'") and s.endswith("'"):
        s = s[2:-1]
    if s.startswith('b"') and s.endswith('"'):
        s = s[2:-1]
    if s in {"", "-", "nan", "NaN", "None", "NONE", "b'-'", "b'nan'"}:
        return np.nan
    return s


def bool_series(df: pd.DataFrame, col: str) -> pd.Series:
    if col not in df.columns:
        return pd.Series(False, index=df.index)
    s = df[col]
    if s.dtype == bool:
        return s.fillna(False)
    return s.astype(str).str.strip().str.lower().isin(["true", "1", "yes", "y", "t"])


def pick_col(df: pd.DataFrame, candidates: list[str]) -> str:
    for c in candidates:
        if c in df.columns:
            return c
    raise KeyError(f"None of candidate columns found: {candidates}")


def sph_to_cart(ra_deg, dec_deg):
    ra = np.deg2rad(np.asarray(ra_deg, dtype=float))
    dec = np.deg2rad(np.asarray(dec_deg, dtype=float))
    cosd = np.cos(dec)
    return np.column_stack([cosd*np.cos(ra), cosd*np.sin(ra), np.sin(dec)])


def nearest_angular_separation(src_ra, src_dec, cat_ra, cat_dec):
    """Return nearest catalogue index and separation in arcsec.

    The TeVCat table has only a few hundred rows, so a dense dot-product matrix
    is simple, deterministic, and dependency-light.
    """
    src = sph_to_cart(src_ra, src_dec)
    cat = sph_to_cart(cat_ra, cat_dec)
    dots = np.clip(src @ cat.T, -1.0, 1.0)
    idx = np.argmax(dots, axis=1)
    maxdot = dots[np.arange(len(src)), idx]
    sep_rad = np.arccos(np.clip(maxdot, -1.0, 1.0))
    sep_arcsec = np.rad2deg(sep_rad) * 3600.0
    return idx, sep_arcsec


def auc_from_scores(scores: pd.Series, labels: pd.Series) -> tuple[float, float]:
    m = scores.notna() & labels.notna()
    s = scores[m].astype(float)
    y = labels[m].astype(bool)
    n1 = int(y.sum())
    n0 = int((~y).sum())
    if n1 < 1 or n0 < 1:
        return np.nan, np.nan
    u, p = mannwhitneyu(s[y], s[~y], alternative="greater")
    return float(u / (n1 * n0)), float(p)


def tier_metrics(df: pd.DataFrame, label_col: str, radius_arcsec: float) -> list[dict]:
    score_col = "S_TeV_evo" if "S_TeV_evo" in df.columns else "score_clean"
    labels = df[label_col].fillna(False).astype(bool)
    scores = pd.to_numeric(df[score_col], errors="coerce")
    tiers = df.get("tev_priority_tier", pd.Series("", index=df.index)).map(clean_str)
    auc, mwp = auc_from_scores(scores, labels)
    rows = []
    N = len(df)
    K = int(labels.sum())
    for tier_name, allowed in TIER_SETS.items():
        in_tier = tiers.isin(allowed)
        n = int(in_tier.sum())
        k = int((in_tier & labels).sum())
        rows.append({
            "radius_arcsec": radius_arcsec,
            "tier_set": tier_name,
            "N": N,
            "known_TeV_N": K,
            "tier_size_N": n,
            "known_TeV_in_tier_N": k,
            "tier_fraction_all": n / N if N else np.nan,
            "known_TeV_recovery_fraction": k / K if K else np.nan,
            "enrichment_vs_random": (k / K) / (n / N) if K and n else np.nan,
            "hypergeom_p_ge_k": float(hypergeom.sf(k - 1, N, K, n)) if K and n and k > 0 else (1.0 if K and n else np.nan),
            "AUROC_knownTeV_vs_other": auc,
            "mannwhitney_p_greater": mwp,
        })
    return rows


def dataframe_to_latex_simple(df: pd.DataFrame, caption: str, label: str, out_path: Path):
    cols = [
        "radius_arcsec", "tier_set", "known_TeV_N", "tier_size_N",
        "known_TeV_in_tier_N", "known_TeV_recovery_fraction",
        "enrichment_vs_random", "hypergeom_p_ge_k", "AUROC_knownTeV_vs_other",
    ]
    fmt = df[cols].copy()
    for c in ["known_TeV_recovery_fraction", "enrichment_vs_random", "AUROC_knownTeV_vs_other"]:
        fmt[c] = fmt[c].map(lambda x: "--" if pd.isna(x) else f"{x:.3f}")
    fmt["hypergeom_p_ge_k"] = fmt["hypergeom_p_ge_k"].map(lambda x: "--" if pd.isna(x) else f"{x:.2e}")
    fmt["radius_arcsec"] = fmt["radius_arcsec"].map(lambda x: f"{x:.0f}")
    fmt = fmt.rename(columns={
        "radius_arcsec": "Radius", "tier_set": "Tier", "known_TeV_N": "$K$",
        "tier_size_N": "$n$", "known_TeV_in_tier_N": "$k$",
        "known_TeV_recovery_fraction": "Recovery", "enrichment_vs_random": "Enrich.",
        "hypergeom_p_ge_k": "$p_{\\rm hyper}$", "AUROC_knownTeV_vs_other": "AUROC",
    })
    latex = fmt.to_latex(index=False, escape=False, column_format="rlrrrrrrr")
    text = "\\begin{table*}\n\\centering\n" + latex + (
        f"\\caption{{{caption}}}\n\\label{{{label}}}\n\\end{{table*}}\n"
    )
    out_path.write_text(text, encoding="utf-8")


def main():
    TABLES.mkdir(exist_ok=True, parents=True)
    FIGURES.mkdir(exist_ok=True, parents=True)
    PROCESSED.mkdir(exist_ok=True, parents=True)

    score = read_first_existing([
        PROCESSED / "tev_evolution_score_catalog_v0_1_6_branch_augmented.csv",
        PROCESSED / "tev_evolution_score_catalog_v0_1_5_augmented.csv",
        PROCESSED / "tev_evolution_score_catalog.csv",
    ]).copy()
    tev = read_first_existing([
        INTERIM / "tevcat_standardized.csv",
        RAW / "tevcat" / "tevcat.csv",
    ]).copy()

    src_ra_col = pick_col(score, ["RAJ2000", "ra_deg", "RA", "RA_RAW"])
    src_dec_col = pick_col(score, ["DECJ2000", "dec_deg", "DEC", "DEC_RAW"])
    tev_ra_col = pick_col(tev, ["ra_deg", "ra", "RA"])
    tev_dec_col = pick_col(tev, ["dec_deg", "dec", "DEC"])

    src_ra = pd.to_numeric(score[src_ra_col], errors="coerce")
    src_dec = pd.to_numeric(score[src_dec_col], errors="coerce")
    tev_ra = pd.to_numeric(tev[tev_ra_col], errors="coerce")
    tev_dec = pd.to_numeric(tev[tev_dec_col], errors="coerce")

    valid_src = src_ra.notna() & src_dec.notna()
    valid_tev = tev_ra.notna() & tev_dec.notna()
    work = score.loc[valid_src].copy()
    src_ra = src_ra.loc[valid_src].to_numpy()
    src_dec = src_dec.loc[valid_src].to_numpy()
    tev_valid = tev.loc[valid_tev].reset_index(drop=True).copy()
    tev_ra = tev_ra.loc[valid_tev].to_numpy()
    tev_dec = tev_dec.loc[valid_tev].to_numpy()

    idx, sep = nearest_angular_separation(src_ra, src_dec, tev_ra, tev_dec)
    name_col = "name" if "name" in tev_valid.columns else None
    alt_col = "alt_name" if "alt_name" in tev_valid.columns else None
    work["nearest_tevcat_sep_arcsec_v0_1_7"] = sep
    work["nearest_tevcat_index_v0_1_7"] = idx
    if name_col:
        work["nearest_tevcat_name_v0_1_7"] = tev_valid.loc[idx, name_col].values
    if alt_col:
        work["nearest_tevcat_alt_name_v0_1_7"] = tev_valid.loc[idx, alt_col].values
    for r in RADII_ARCSEC:
        work[f"known_TeV_radius_{int(r)}arcsec_v0_1_7"] = sep <= r

    audit_cols = [c for c in work.columns if c.endswith("v0_1_7") or c.startswith("known_TeV_radius_")]
    id_cols = [c for c in ["SRC_NAME", "RAJ2000", "DECJ2000", "S_TeV_evo", "tev_priority_tier"] if c in work.columns]
    work[id_cols + audit_cols].to_csv(PROCESSED / "tevcat_nearest_match_audit_v0_1_7.csv", index=False)

    rows = []
    for r in RADII_ARCSEC:
        label_col = f"known_TeV_radius_{int(r)}arcsec_v0_1_7"
        rows.extend(tier_metrics(work, label_col, r))
    out = pd.DataFrame(rows)
    out.to_csv(TABLES / "table_tevcat_radius_sensitivity_v0_1_7.csv", index=False)
    dataframe_to_latex_simple(
        out,
        caption=("TeVCat cross-match radius sensitivity. The score is held fixed; "
                 "only the external validation label is recomputed at each radius."),
        label="tab:tevcat_radius_sensitivity",
        out_path=TABLES / "table_tevcat_radius_sensitivity_v0_1_7.tex",
    )

    # Figure: Gold and Gold+Silver recovery and enrichment versus radius.
    fig_df = out[out["tier_set"].isin(["Gold", "Gold+Silver"])].copy()
    fig, ax1 = plt.subplots(figsize=(7.5, 4.6))
    for tier in ["Gold", "Gold+Silver"]:
        sub = fig_df[fig_df["tier_set"] == tier]
        ax1.plot(sub["radius_arcsec"], sub["known_TeV_recovery_fraction"], marker="o", label=f"{tier} recovery")
    ax1.set_xlabel("TeVCat match radius (arcsec)")
    ax1.set_ylabel("Known-TeV recovery fraction")
    ax1.set_ylim(0, 1.05)
    ax1.grid(True, alpha=0.25)
    ax2 = ax1.twinx()
    for tier in ["Gold", "Gold+Silver"]:
        sub = fig_df[fig_df["tier_set"] == tier]
        ax2.plot(sub["radius_arcsec"], sub["enrichment_vs_random"], marker="s", linestyle="--", label=f"{tier} enrichment")
    ax2.set_ylabel("Enrichment vs random")
    lines, labels = ax1.get_legend_handles_labels()
    lines2, labels2 = ax2.get_legend_handles_labels()
    ax1.legend(lines + lines2, labels + labels2, loc="best", fontsize=8)
    ax1.set_title("TeVCat validation sensitivity to match radius")
    fig.tight_layout()
    fig.savefig(FIGURES / "Fig_tevcat_radius_sensitivity_v0_1_7.png", dpi=200)
    fig.savefig(FIGURES / "Fig_tevcat_radius_sensitivity_v0_1_7.pdf")
    plt.close(fig)

    print("v0.1.7 TeVCat radius sensitivity complete.")
    print(out.to_string(index=False))


if __name__ == "__main__":
    main()
