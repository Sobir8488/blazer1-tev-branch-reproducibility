from __future__ import annotations

import sys
from pathlib import Path
sys.path.append(str(Path(__file__).resolve().parent))

import pandas as pd

from _v043_helpers import TABLES, DOCS


def main() -> None:
    arch = pd.read_csv(TABLES / "table_score_architecture_variants_v0_4_3.csv")
    activity = pd.read_csv(TABLES / "table_score_component_activity_v0_4_3.csv")
    cond = pd.read_csv(TABLES / "table_pattern_conditioned_validation_v0_4_3.csv")
    case = pd.read_csv(TABLES / "table_exact_pattern_case_concordance_summary_v0_4_3.csv")
    stability = pd.read_csv(TABLES / "table_candidate_architecture_stability_v0_4_3.csv")
    decision = pd.read_csv(TABLES / "table_primary_score_decision_v0_4_3.csv")
    radio = pd.read_csv(TABLES / "table_radio_denominator_effect_v0_4_3.csv")

    selected = arch[arch["score_variant"].isin(["published_available", "active_available", "fixed_active_weight"])]
    selected_cond = cond[cond["score_variant"].isin(["published_available", "active_available", "fixed_active_weight", "xray_only", "no_xray"])]

    report = [
        "# v0.4.3 score-architecture hardening", "",
        "## Architectural finding", "",
        "The frozen radio-compactness component is numerically constant where available. The released available-weight score therefore allows radio metadata availability to change the denominator without adding a signed radio signal.", "",
        "The architecture decision is made from this numerical property before consulting TeVCat performance. The corrected active-component score removes globally zero-variance components from both numerator and denominator. The published score remains a frozen legacy reference.", "",
        "## Component activity", "", activity.to_markdown(index=False), "",
        "## Score variants", "", selected.to_markdown(index=False), "",
        "## Exact availability-pattern conditioning", "", selected_cond.to_markdown(index=False), "",
        "## Exact-pattern case concordance", "", case.to_markdown(index=False), "",
        "## Candidate stability", "", stability.to_markdown(index=False), "",
        "## Radio denominator effect", "", radio.to_markdown(index=False), "",
        "## Primary-score decision", "", decision.to_markdown(index=False), "",
        "## Claim gate", "",
        "Unrestricted TeVCat AUROC combines branch physics with characterization history. Exact-pattern-conditioned AUROC is the preferred coverage-controlled validation. Fixed-denominator variants are sensitivity tests, not evidence of improved intrinsic discrimination.", "",
    ]
    (DOCS / "score_architecture_hardening_report_v0_4_3.md").write_text("\n".join(report), encoding="utf-8")

    tex = r"""
\subsection{Score-architecture and exact-coverage audit}
\label{sec:score_architecture_v043}

The exact reconstruction audit identified a numerically constant radio-compactness component in the frozen catalogue.  Where radio metadata are present, the published available-component formulation therefore adds the nominal radio weight to the denominator while adding zero to the numerator.  Because this issue is defined by the score architecture rather than by TeVCat performance, we introduce an active-component branch coordinate in which globally zero-variance components are excluded from both numerator and denominator.  The published coordinate is retained unchanged as a frozen legacy reference, while fixed-denominator formulations are treated only as coverage-penalizing sensitivity tests.

The active-component coordinate remains highly correlated with the published score, but the strict Gold membership is not identical.  This difference is reported rather than hidden because source-level follow-up lists are more sensitive to denominator architecture than aggregate rank statistics.  All architecture variants are therefore compared through AUROC, tier recovery, Gold-set overlap, top-30 overlap, and the stability of the two claim-gated follow-up lists.

Multiwavelength completeness is itself strongly associated with historical TeV membership.  We consequently condition the validation on the exact eight-bit availability pattern of the score components.  Only availability patterns represented among known TeV sources enter this comparison.  Scores are converted to percentile ranks within each exact pattern, and the TeV-label significance is evaluated by permutations that preserve the number of known TeV objects within every pattern.  This removes between-pattern score offsets and prevents characterization completeness from acting as an implicit classifier.

The corrected active-component score is adopted as the primary physical branch coordinate because a zero-variance component cannot carry physical leverage and should not modify the denominator.  This decision does not use the direction or significance of the TeVCat result.  The published score remains the reproducibility reference for all previously frozen tables, and both are reported wherever source identity is relevant.
""".strip()
    (DOCS / "latex_score_architecture_hardening_v0_4_3.tex").write_text(tex + "\n", encoding="utf-8")

    compact = selected[[
        "score_variant", "AUROC", "Gold_known_TeV_N", "Gold_Silver_known_TeV_N",
        "spearman_vs_published", "Gold_Jaccard_vs_published", "top30_nonTeV_overlap_N",
    ]].copy()
    latex_table = compact.to_latex(
        index=False,
        escape=True,
        float_format=lambda x: f"{x:.3f}",
        caption=("Score-architecture sensitivity. The active-component score removes globally zero-variance components from both numerator and denominator. Fixed-denominator scores are retained only as coverage sensitivities."),
        label="tab:score_architecture_v043",
    )
    (DOCS / "latex_score_architecture_table_v0_4_3.tex").write_text(latex_table, encoding="utf-8")

    print("Wrote docs/score_architecture_hardening_report_v0_4_3.md")
    print("Wrote docs/latex_score_architecture_hardening_v0_4_3.tex")
    print("\nCore architecture summary:")
    print(selected.to_string(index=False))
    print("\nPattern-conditioned validation:")
    print(selected_cond.to_string(index=False))


if __name__ == "__main__":
    main()
